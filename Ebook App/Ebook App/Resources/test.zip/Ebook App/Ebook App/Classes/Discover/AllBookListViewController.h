//
//  AllBookListViewController.h
//  Ebook App
//
//  Created by macmini3 on 08/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AllBookTableViewCell.h"
#import "AllListPaginator.h"
#import "AllBookCollectiionViewCell.h"
@interface AllBookListViewController : UIViewController<UITableViewDataSource, UITableViewDelegate,NMPaginatorDelegate, UIScrollViewDelegate>{

}
@property (nonatomic, strong) AllListPaginator *Paginator;
@property (nonatomic, strong) UILabel *footerLabel;
@property (nonatomic, strong) UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionview;
@property (retain, nonatomic) NSString *identifier;
@property (assign, nonatomic) BOOL is_genre;
@property (assign, nonatomic) BOOL is_language;
@property (assign, nonatomic) BOOL is_featured;
- (IBAction)goBack:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_back;
@property (retain, nonatomic) NSString *backbtntitle;
@property (weak, nonatomic) IBOutlet UIButton *btn_nowplaying;
- (IBAction)goNowPlaying:(id)sender;
@end
