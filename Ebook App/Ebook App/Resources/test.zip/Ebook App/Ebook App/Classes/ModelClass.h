//
//  ModelClass.h
//  APITest
//
//  Created by Evgeny Kalashnikov on 03.12.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "DarckWaitView.h"

@class DarckWaitView;
@class DarckWaitView_pad;
@interface ModelClass : NSObject {
  
    DarckWaitView *drkSignUp;

}
- (void)GetViewOf:(NSString *)view page:(NSString *)page success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)Getmenuofgenre:(NSString *)menu success:(void (^)(id))result error:(void (^)(NSError *))error;
-(void)Getgenrebooks:(NSString *)genre page:(NSString *)page success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)Getbooksforlanguage:(NSString *)language page:(NSString *)page success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)Getsearchresultfor:(NSString *)text  success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)GetbookDetail:(NSString *)bookUrl success:(void (^)(id))result error:(void (^)(NSError *))error;
@end
