//
//  TopChartsViewController.m
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "TopChartsViewController.h"

@interface TopChartsViewController ()

@end

@implementation TopChartsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    

    [self setupTableViewFooter];
    _collectionview.hidden = YES;
    // set up the paginator
    self.Paginator = [[AllListPaginator alloc] initWithPageSize:pagelimit delegate:self];
    [self.Paginator fetchFirstPagewithidentifier:@"top" is_genre:NO is_featured:YES is_language:NO];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [_collectionview registerNib:[UINib nibWithNibName:@"TopChartCollectionCell" bundle:nil]
      forCellWithReuseIdentifier:@"TopChartCollectionCell"];
    
    [_collectionview registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"header"];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    if (!DELEGATE.playDict) {
        _btn_nowplaying.hidden = YES;
    }else{
        _btn_nowplaying.hidden = NO;
    }
}

- (void)fetchNextPage
{
    [self.Paginator fetchNextPageidentifier:@"top" is_genre:NO is_featured:YES is_language:YES];
    [self.activityIndicator startAnimating];
}

- (void)setupTableViewFooter
{
    // set up label
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    footerView.backgroundColor = [UIColor clearColor];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    label.font = [UIFont boldSystemFontOfSize:16];
    label.textColor = [UIColor lightGrayColor];
    label.textAlignment = NSTextAlignmentCenter;
    
    self.footerLabel = label;
    [footerView addSubview:label];
    
    // set up activity indicator
    UIActivityIndicatorView *activityIndicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    activityIndicatorView.center = CGPointMake(160, 22);
    activityIndicatorView.hidesWhenStopped = YES;
    
    self.activityIndicator = activityIndicatorView;
    [footerView addSubview:activityIndicatorView];
    
    _tableview.tableFooterView = footerView;
}

- (void)updateTableViewFooter
{
    if ([self.Paginator.results count] != 0)
    {
     //   self.footerLabel.text = [NSString stringWithFormat:@"%lu results out of %ld", (unsigned long)[self.Paginator.results count], (long)self.Paginator.total];
        self.footerLabel.text = @"";
    } else
    {
        self.footerLabel.text = @"";
    }
    
    [self.footerLabel setNeedsDisplay];
}


#pragma mark - Paginator delegate methods

- (void)paginator:(id)paginator didReceiveResults:(NSArray *)results title:(NSString *)title
{
    // update tableview footer
    _collectionview.hidden = NO;
    [self updateTableViewFooter];
    [self.activityIndicator stopAnimating];
    
    // update tableview content
    // easy way : call [tableView reloadData];
    
    [_tableview reloadData];
    [_collectionview reloadData];
    // nicer way : use insertRowsAtIndexPaths:withAnimation:
//    NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
//    NSInteger i = [self.Paginator.results count] - [results count];
//    
//    for (int j = 0; j < [results count]; j++) {
//        [indexPaths addObject:[NSIndexPath indexPathForRow:i inSection:0]];
//        i++;
//    }
//    
//    
//    [_tableview beginUpdates];
//    [_tableview insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationMiddle];
//    [_tableview endUpdates];
}

- (void)paginatorDidReset:(id)paginator
{
    [_tableview reloadData];
    [_collectionview reloadData];
    [self updateTableViewFooter];
}

- (void)paginatorDidFailToRespond:(id)paginator
{
    // Todo
}


-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    
    return [self.Paginator.results count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"TopChartCell";
    AllBookTableViewCell *cell = (AllBookTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell= (AllBookTableViewCell *)[arrNib objectAtIndex:0];
        //cell.backgroundColor =[UIColor clearColor];
        
    }
    cell.tag = indexPath.row +1 ;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    [cell populateResult:[self.Paginator.results objectAtIndex:indexPath.row]];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    BookDetailViewController *detail = [[BookDetailViewController alloc]initWithNibName:@"BookDetailViewController" bundle:nil];
    detail.booksarray = [NSMutableArray arrayWithArray:self.Paginator.results];
    detail.pageindex = indexPath.row;
    detail.backbtntitle = @"Top Charts";
    [self.navigationController pushViewController:detail animated:YES];

   // NSLog(@"-->%@",[self.Paginator.results objectAtIndex:indexPath.row]);
    
}
#pragma mark - UICollectionView Datasource
// 1
- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section {
    return [self.Paginator.results count];
}
// 2
- (NSInteger)numberOfSectionsInCollectionView: (UICollectionView *)collectionView {
    return 1;
}
// 3
- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
    AllBookCollectiionViewCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"TopChartCollectionCell" forIndexPath:indexPath];
    cell.layer.shouldRasterize = YES;
    cell.layer.rasterizationScale = [UIScreen mainScreen].scale;
    cell.tag = indexPath.row +1 ;
    [cell populateResult:[self.Paginator.results objectAtIndex:indexPath.row]];
    
    return cell;
    
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    BookDetailViewController *detail = [[BookDetailViewController alloc]initWithNibName:@"BookDetailViewController" bundle:nil];
    detail.booksarray = [NSMutableArray arrayWithArray:self.Paginator.results];
    detail.pageindex = indexPath.row;
    detail.backbtntitle = @"Top Charts";
    [self addChildViewController: detail];
    [self.view addSubview: detail.view];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(removeChild:)];
    [detail.tapableview addGestureRecognizer:tap];
    
}
-(void)removeChild:(UITapGestureRecognizer *)sender{
    UIViewController *vc = [self.childViewControllers lastObject];
    [vc willMoveToParentViewController:nil];
    [vc.view removeFromSuperview];
    [vc removeFromParentViewController];

}
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *reusableview = nil;
    
    if (kind == UICollectionElementKindSectionFooter) {
        reusableview = [_collectionview dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"header" forIndexPath:indexPath];
        
        if (reusableview==nil) {
            reusableview=[[UICollectionReusableView alloc] initWithFrame:CGRectMake(0, 0, _collectionview.frame.size.width, 44)];
        }
        
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _collectionview.frame.size.width, 44)];
        footerView.backgroundColor = [UIColor whiteColor];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _collectionview.frame.size.width, 44)];
        label.font = [UIFont boldSystemFontOfSize:16];
        label.textColor = [UIColor lightGrayColor];
        label.textAlignment = NSTextAlignmentCenter;
        
        self.footerLabel = label;
        [footerView addSubview:label];
        
        UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, _collectionview.frame.size.width, 1)];
        [img setImage:[UIImage imageNamed:@"seprator"]];
        [footerView addSubview:img];
        
        
        // set up activity indicator
        UIActivityIndicatorView *activityIndicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        activityIndicatorView.center = CGPointMake(_collectionview.frame.size.width/2, 22);
        activityIndicatorView.hidesWhenStopped = YES;
        
        self.activityIndicator = activityIndicatorView;
        [footerView addSubview:activityIndicatorView];
        [reusableview addSubview:footerView];
    }
    return reusableview;
}

#pragma mark - UIScrollViewDelegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    // when reaching bottom, load a new page
    
   
    
    if (scrollView.contentOffset.y == scrollView.contentSize.height - scrollView.bounds.size.height)
    {
        // ask next page only if we haven't reached last page
        if(![self.Paginator reachedLastPage])
        {
            // fetch next page of results
            [self fetchNextPage];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)goNowPlaying:(id)sender {
    MyBookDetailViewController *godetail = [[MyBookDetailViewController alloc]initWithNibName:@"MyBookDetailViewController" bundle:nil];
    godetail.myBookDict = DELEGATE.playDict;
    FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
    item.title = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"title"];
    item.url = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"file"];
    item.number = DELEGATE.playingIndex;
    godetail.selectedPlaylistItem = item;
    [self.navigationController pushViewController:godetail animated:YES];
}
@end
