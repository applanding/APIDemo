//
//  SleepTimerTableViewCell.h
//  Ebook App
//
//  Created by macmini3 on 04/10/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SleepTimerTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@end
