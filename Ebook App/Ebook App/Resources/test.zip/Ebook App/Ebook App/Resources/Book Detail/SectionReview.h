//
//  SectionReview.h
//  Ebook App
//
//  Created by macmini3 on 17/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SectionReview : UIView
@property (weak, nonatomic) IBOutlet UILabel *lbl_ratingcount;
@property (weak, nonatomic) IBOutlet UIProgressView *progress1;
@property (weak, nonatomic) IBOutlet UIProgressView *progress2;
@property (weak, nonatomic) IBOutlet UIProgressView *pregress3;
@property (weak, nonatomic) IBOutlet UIProgressView *progress4;
@property (weak, nonatomic) IBOutlet UIProgressView *progress5;
- (IBAction)writereview:(id)sender;
@property (retain, nonatomic) NSString *bookUrl;
-(void)PopulateResult:(NSMutableArray *)dict;
@end
