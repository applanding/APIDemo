//
//  SearchViewController.h
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController<UISearchBarDelegate,UITableViewDataSource, UITableViewDelegate>{
    NSMutableArray *resultArr;
    GADBannerView *admobBannerView;
}

@property (weak, nonatomic) IBOutlet UISearchBar *txt_search;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionview;
@end
