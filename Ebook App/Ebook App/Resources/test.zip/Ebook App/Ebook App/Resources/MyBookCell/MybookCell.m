//
//  MybookCell.m
//  Ebook App
//
//  Created by macmini3 on 19/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "MybookCell.h"

@implementation MybookCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void)PopulateResult:(NSMutableDictionary *)dict{
    if (![dict isEqual:[NSNull null]]) {
        
        if (!_is_edit) {
            _btn_delete.hidden = YES;
        }
        
     //   NSLog(@"--->%@",dict);
        [_imgview setImageWithURL:[NSURL URLWithString:[dict valueForKeyPath:@"details.image"]] placeholderImage:[UIImage imageNamed:@"Book_placeholder"]];
        
        
        if (![[dict valueForKeyPath:@"details.author"]isEqual:[NSNull null]]) {
            
            _lbl_author.text = [NSString stringWithFormat:@"%@",[dict valueForKeyPath:@"details.author"]];
        }
        if (![[dict valueForKeyPath:@"details.title"]isEqual:[NSNull null]]) {
            
            _lbl_title.text = [NSString stringWithFormat:@"%@",[dict valueForKeyPath:@"details.title"]];
        }
        
        for(UIView *view in self.subviews){
            if ([view isKindOfClass:[TQStarRatingView class]]) {
                [view removeFromSuperview];
            }
        }
         if (![[dict valueForKeyPath:@"details.rating"]isEqual:[NSNull null]]) {
            TQStarRatingView   *starRatingView = [[TQStarRatingView alloc] initWithCustomeFrame:CGRectMake(_lbl_author.frame.origin.x, _lbl_author.frame.origin.y + _lbl_author.frame.size.height + 3, 60, 12)
                                                                     numberOfStar:kNUMBER_OF_STAR];
        
            [starRatingView setScore:[[dict valueForKeyPath:@"details.rating"]floatValue]/5.0 withAnimation:NO];
            starRatingView.userInteractionEnabled = NO;
            [self addSubview:starRatingView];
         }
        }
        
        
    
    
}
- (IBAction)goDelete:(UIButton *)sender {
    if ([self.delgate respondsToSelector:@selector(didTouchDelete:)]) {
        [self.delgate didTouchDelete:sender.tag];
    }

}
@end
