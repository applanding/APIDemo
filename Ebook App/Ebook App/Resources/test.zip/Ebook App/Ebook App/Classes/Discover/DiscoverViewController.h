//
//  DiscoverViewController.h
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BookCommon.h"
#import "AllBookListViewController.h"
@interface DiscoverViewController : UIViewController<BookDelegate>
{
    NSMutableArray *resultArr;
    
}
@property (strong, nonatomic) IBOutlet UIScrollView *scrollview;

@property (weak, nonatomic) IBOutlet UIButton *btn_nowplaying;
- (IBAction)goNowPlaying:(id)sender;
@end
