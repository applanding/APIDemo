//
//  ChapterTableViewCell.m
//  Ebook App
//
//  Created by macmini3 on 17/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "ChapterTableViewCell.h"

@implementation ChapterTableViewCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)populateResult:(NSMutableDictionary *)dict{
    
    if(dict){
        
        if (![[dict valueForKey:@"title"]isEqual:[NSNull null]]) {
            _lbl_title.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"title"]];
        }
        if (![[dict valueForKey:@"length"]isEqual:[NSNull null]]) {
            _lbl_time.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"length"]];
        }
        _lbl_index.text = [NSString stringWithFormat:@"%ld",(long)self.tag];
        

        
    }
}
@end
