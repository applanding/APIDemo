//
//  ReviewTableViewCell.h
//  Ebook App
//
//  Created by macmini3 on 17/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReviewTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UILabel *lbl_time;
@property (weak, nonatomic) IBOutlet UITextView *txt_review;
-(void)populateResult:(NSMutableDictionary *)dict;
@end
