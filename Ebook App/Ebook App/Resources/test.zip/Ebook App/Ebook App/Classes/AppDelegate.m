//
//  AppDelegate.m
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
//    NSArray *fontFamilies = [UIFont familyNames];
//    
//    for (int i = 0; i < [fontFamilies count]; i++)
//    {
//        NSString *fontFamily = [fontFamilies objectAtIndex:i];
//        NSArray *fontNames = [UIFont fontNamesForFamilyName:[fontFamilies objectAtIndex:i]];
//        NSLog (@"%@: %@", fontFamily, fontNames);
//    }
    
    [[AFNetworkActivityIndicatorManager sharedManager] setEnabled:YES];
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [self openDatabase];
    
   [Flurry setCrashReportingEnabled:YES];
    // Replace YOUR_API_KEY with the api key in the downloaded package
    [Flurry startSession:@"S2JPJB95Z2WQQJ7732CR"];
    
    
    //Here we declare a shared NSURLCache with 2mb of memory and 100mb of disk space
    NSURLCache *sharedCache = [[NSURLCache alloc] initWithMemoryCapacity:4 * 1024 * 1024
                                                            diskCapacity:100 * 1024 * 1024
                                                                diskPath:nil];
    [NSURLCache setSharedURLCache:sharedCache];
    
    
    _audioController = [[FSAudioController alloc]init];
    _playingRate = 1.005;
    _sleepindex = 0;
    
    _RemoveAllAds = NO;
    _RemovePlaybackAds = NO;
    _inApp=[[IAPHelper alloc]initWithProductIdentifiers:[NSSet setWithObjects:RemoveALLAds,RemovePLAYBACKAds, nil]];
    [_inApp setDeleget:self];
    if (_inApp.products == nil) {
        
        [_inApp requestProducts];
    }
   
    _window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    _tabBarController = [[UITabBarController alloc]init];
    _tabBarController.delegate=self;
    
   // _tabBarController.tabBar.translucent = YES;
    
    MyBooksViewController *vc1 = [[MyBooksViewController alloc]initWithNibName:@"MyBooksViewController" bundle:nil];
     DiscoverViewController *vc2 = [[DiscoverViewController alloc]initWithNibName:@"DiscoverViewController" bundle:nil];
    GenresViewController *vc3 = [[GenresViewController alloc]initWithNibName:@"GenresViewController" bundle:nil];

    TopChartsViewController *vc4 = [[TopChartsViewController alloc]initWithNibName:@"TopChartsViewController" bundle:nil];

    SearchViewController *vc5 = [[SearchViewController alloc]initWithNibName:@"SearchViewController" bundle:nil];
  
    UINavigationController *navController1=[[UINavigationController alloc]initWithRootViewController:vc1];
    [navController1.navigationBar setHidden:YES];
    if ([navController1 respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        navController1.interactivePopGestureRecognizer.enabled = NO;
    }
    
    UINavigationController *navController2=[[UINavigationController alloc]initWithRootViewController:vc2];
    [navController2.navigationBar setHidden:YES];
    if ([navController2 respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        navController2.interactivePopGestureRecognizer.enabled = NO;
    }
    UINavigationController *navController3=[[UINavigationController alloc]initWithRootViewController:vc3];
    [navController3.navigationBar setHidden:YES];
    if ([navController3 respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        navController3.interactivePopGestureRecognizer.enabled = NO;
    }
    UINavigationController *navController4=[[UINavigationController alloc]initWithRootViewController:vc4];
    [navController4.navigationBar setHidden:YES];
    if ([navController4 respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        navController4.interactivePopGestureRecognizer.enabled = NO;
    }
    UINavigationController *navController5=[[UINavigationController alloc]initWithRootViewController:vc5];
    [navController5.navigationBar setHidden:YES];
    if ([navController5 respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        navController5.interactivePopGestureRecognizer.enabled = NO;
    }
    
    NSArray *tabArrays = [NSArray arrayWithObjects: navController1, navController2,navController3,navController4,navController5, nil];
    
    _tabBarController.viewControllers = tabArrays ;
    [[_tabBarController.tabBar.items objectAtIndex:0]setTitle:@"My Books"];
    [[_tabBarController.tabBar.items objectAtIndex:1]setTitle:@"Discover"];
    [[_tabBarController.tabBar.items objectAtIndex:2]setTitle:@"Genres"];
    [[_tabBarController.tabBar.items objectAtIndex:3]setTitle:@"Top Charts"];
    [[_tabBarController.tabBar.items objectAtIndex:4]setTitle:@"Search"];
    
    [[_tabBarController.tabBar.items objectAtIndex:0]setFinishedSelectedImage:[UIImage imageNamed:@"book_select"] withFinishedUnselectedImage:[UIImage imageNamed:@"book"]];
     [[_tabBarController.tabBar.items objectAtIndex:1]setFinishedSelectedImage:[UIImage imageNamed:@"discover_select"] withFinishedUnselectedImage:[UIImage imageNamed:@"discover"]];
     [[_tabBarController.tabBar.items objectAtIndex:2]setFinishedSelectedImage:[UIImage imageNamed:@"genre_select"] withFinishedUnselectedImage:[UIImage imageNamed:@"genre"]];
     [[_tabBarController.tabBar.items objectAtIndex:3]setFinishedSelectedImage:[UIImage imageNamed:@"topchart_select"] withFinishedUnselectedImage:[UIImage imageNamed:@"topchart"]];
     [[_tabBarController.tabBar.items objectAtIndex:4]setFinishedSelectedImage:[UIImage imageNamed:@"search_select"] withFinishedUnselectedImage:[UIImage imageNamed:@"search"]];
    
     
   _window.backgroundColor = [UIColor whiteColor];
   _window.rootViewController = _tabBarController;
    
    if ([MyBooks count] ==0 ) {
        [_window makeKeyAndVisible];
        _tabBarController.view.hidden = YES;
       [self performSelector:@selector(gotodiscover) withObject:nil afterDelay:0.3];
    }
    else{
        [_window makeKeyAndVisible];
    }
    
    
    //prevent automatic prompt
    [iRate sharedInstance].promptAtLaunch = NO;
    [[UIApplication sharedApplication]setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    
    return YES;
}
-(void)gotodiscover{
    _tabBarController.view.hidden = NO;;
    _tabBarController.selectedIndex = 1;
    [_window makeKeyAndVisible];
}
- (void)productsRequestdelegete:(NSArray*)product{
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
   
    for (NSString *product in _inApp.purchasedProducts){
        if ([product isEqualToString:RemoveALLAds]) {
            _RemoveAllAds = YES;
            _RemovePlaybackAds = YES;
        }
        if ([product isEqualToString:RemovePLAYBACKAds]) {
            _RemovePlaybackAds = YES;
        }
    }
    
   
  //  NSLog(@"-->%@  %@", _inApp.productIdentifiers ,_inApp.purchasedProducts);
    
    
}
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
    
    if (_playingImage) {
        FSStreamPosition cur = DELEGATE.audioController.stream.currentTimePlayed;
        
        MPMediaItemArtwork *artwork = [[MPMediaItemArtwork alloc]initWithImage:_playingImage];
        [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = [NSDictionary dictionaryWithObjectsAndKeys:[[[_playDict valueForKey:@"mp3"]objectAtIndex:_playingIndex]valueForKey:@"title"], MPMediaItemPropertyTitle, [_playDict valueForKeyPath:@"details.author"], MPMediaItemPropertyArtist, artwork, MPMediaItemPropertyArtwork,  [NSNumber numberWithInt:1], MPNowPlayingInfoPropertyPlaybackRate,[NSNumber numberWithInt:[self minuteToSecondConvert:[[[_playDict valueForKey:@"mp3"]objectAtIndex:_playingIndex]valueForKey:@"length"]]],MPMediaItemPropertyPlaybackDuration,[NSNumber numberWithInt:[DELEGATE minuteToSecondConvert:[NSString stringWithFormat:@"%i:%02i",cur.minute, cur.second]]],MPNowPlayingInfoPropertyElapsedPlaybackTime, nil];
        
    }
   
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
-(void)downloadBookwithUrl:(NSString *)UrlStr{
   
    if ([AFNetworkReachabilityManager sharedManager].reachableViaWiFi) {
        
    
      NSURL *url = [NSURL URLWithString:[[NSString stringWithFormat:@"%@",UrlStr]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    [[NSFileManager defaultManager]removeItemAtPath:[[self applicationDocumentsDirectory]stringByAppendingPathComponent:[url lastPathComponent] ] error:nil];
      
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:_tabBarController.selectedViewController.view animated:YES];
        hud.mode = MBProgressHUDModeAnnularDeterminate;
        hud.labelText = @"Loading";
        
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    NSString *fullPath = [NSTemporaryDirectory() stringByAppendingPathComponent:[url lastPathComponent]];
    [operation setOutputStream:[NSOutputStream outputStreamToFileAtPath:fullPath append:NO]];
    [operation setDownloadProgressBlock:^(NSUInteger bytesRead, long long totalBytesRead, long long totalBytesExpectedToRead) {
        
            hud.progress = ((float)totalBytesRead/(float)totalBytesExpectedToRead);
//  NSLog(@"bytesRead: %u, totalBytesRead: %lld, totalBytesExpectedToRead: %lld", bytesRead, totalBytesRead, totalBytesExpectedToRead);
        if ([self.delgate respondsToSelector:@selector(downloadprogress: forURL:)]) {
            [self.delgate downloadprogress:((float)totalBytesRead/(float)totalBytesExpectedToRead)*100 forURL:UrlStr];
        }
    }];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //      NSLog(@"RES: %@", [[[operation response] allHeaderFields] description]);
        
        
        NSError *error;
        [[NSFileManager defaultManager]moveItemAtPath:fullPath toPath:[[self applicationDocumentsDirectory]stringByAppendingPathComponent:[url lastPathComponent]] error:&error];
        if (error) {
            NSLog(@"ERR: %@", [error description]);
        } else {
            
            [DELEGATE installEPub:[url lastPathComponent]];
            
          
        }
      
        [hud hide:YES];
     
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"ERR: %@", [error description]);
        [hud hide:YES];
    }];
    [operation start];
    }
    else{
    [[[UIAlertView alloc] initWithTitle:@"" message:@"Book can be download via WIFI only" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
    }
   
}


- (NSString *)applicationDocumentsDirectory {
 //   NSLog(@"-->%@",[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]);
    return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
}

//---------------------------Ebook Reader Code-------------------------------------//
// Database Routines
-(BOOL)openDatabase {
    
    NSLog(@"openDatabase");
    NSString *documentsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *dbPath = [documentsDirectory stringByAppendingPathComponent:@"books.sqlite"];
    if (sqlite3_open([dbPath UTF8String], &database) != SQLITE_OK) {
        sqlite3_close(database);
        return NO;
    }
    BOOL res = [self createDatabase];
//    if ([self getSettingCount]==0) {
//        [self executeSQL:@"INSERT INTO Setting(BookCode,FontName,FontSize,LineSpacing,Foreground,Background,Theme,Brightness,TransitionType,LockRotation,DoublePaged,Allow3G,GlobalPagination) VALUES(0,'Book Fonts',2,-1,-1,-1,0,1,3,1,1,0,0)"];
//    }
    return res;
}
-(BOOL)createDatabase {
    NSString *ddlPath = [[NSBundle mainBundle] pathForResource:@"/Books" ofType:@"sql"];
    NSString *ddl = [NSString stringWithContentsOfFile:ddlPath encoding:NSUTF8StringEncoding error:NULL];
    if (sqlite3_exec(database, [ddl UTF8String], nil,nil,nil) != SQLITE_OK) {
        sqlite3_close(database);
        return NO;
    }
    return YES;
}

//-(int)getSettingCount {
//    int count = 0;
//    const char* sqlStatement = "SELECT COUNT(*) FROM Setting";
//    sqlite3_stmt *statement;
//    
//    if( sqlite3_prepare_v2(database, sqlStatement, -1, &statement, NULL) == SQLITE_OK ) {
//        //Loop through all the returned rows (should be just one)
//        while( sqlite3_step(statement) == SQLITE_ROW ) {
//            count = sqlite3_column_int(statement, 0);
//        }
//    }else  {
//        NSLog( @"Failed from sqlite3_prepare_v2. Error is:  %s", sqlite3_errmsg(database) );
//    }
//    
//    // Finalize and close database.
//    sqlite3_finalize(statement);
//    return count;
//}
-(BOOL)executeSQL:(NSString*)sql {
    sqlite3_stmt *statement;
    if (sqlite3_prepare_v2(database,[sql UTF8String],-1,&statement,NULL) == SQLITE_OK) {
        if (sqlite3_step(statement) != SQLITE_DONE) {
            return NO;
        }
    }
    return YES;
}

-(BOOL)installEPub:(NSString*)URL {
	BOOL res;
   
    
	res = [self unzipEPub:[URL lastPathComponent]];
	if (!res) {
		NSLog(@"Failed to unzip");
		return NO;
	}
   
    BookInformation* bi= [[BookInformation alloc]initWithBookName:[URL lastPathComponent] baseDirectory:[self getBooksDirectory] contentProviderClass:[FileProvider self]];
    bi.fileName = [URL lastPathComponent];
    [self insertBook:bi];
    if ([self.delgate respondsToSelector:@selector(DownloadCompletedforURL:)]) {
        [self.delgate DownloadCompletedforURL:URL];
    }
	return YES;
}

-(BOOL)unzipEPub:(NSString*)fileName {
	NSString *filePath;
	filePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:fileName];
	
	ZipArchive *z = [[ZipArchive alloc] init];
	
	[z UnzipOpenFile:filePath];
	BOOL res = [z UnzipFileTo:[self getinstalledEPubDirectory:fileName] overWrite:YES];;
	[z UnzipCloseFile];
	  [[NSFileManager defaultManager]removeItemAtPath:[[self applicationDocumentsDirectory]stringByAppendingPathComponent:fileName ] error:nil];
    
    
	return res;
}
-(void)createBooksDirectory {
	NSString *docPath = [self applicationDocumentsDirectory];
	NSString *booksDir = [docPath stringByAppendingFormat:@"/books"];
	NSFileManager *fm =[NSFileManager defaultManager];
	NSError *error;
	if (![fm fileExistsAtPath:booksDir]) {
		[fm createDirectoryAtPath:booksDir withIntermediateDirectories:NO attributes:nil error:&error];
		
	}
}
-(NSString*)getBooksDirectory {
	[self createBooksDirectory];
	NSString *docPath = [self applicationDocumentsDirectory];
	NSString *booksDir = [docPath stringByAppendingFormat:@"/books"];
	
	return booksDir;
}
-(NSString*)getinstalledEPubDirectory:(NSString*)fileName {
	NSString *pureName = [fileName stringByDeletingPathExtension];
	NSString *booksDir = [self getBooksDirectory];
	NSString *ePubDir = [booksDir stringByAppendingPathComponent:pureName];
	return ePubDir;
}

-(void)createMp3Directory {
	NSString *docPath = [self applicationDocumentsDirectory];
	NSString *booksDir = [docPath stringByAppendingFormat:@"/mp3"];
	NSFileManager *fm =[NSFileManager defaultManager];
	NSError *error;
	if (![fm fileExistsAtPath:booksDir]) {
		[fm createDirectoryAtPath:booksDir withIntermediateDirectories:NO attributes:nil error:&error];
		
	}
}
-(NSString*)getmp3Directory {
	[self createBooksDirectory];
	NSString *docPath = [self applicationDocumentsDirectory];
	NSString *booksDir = [docPath stringByAppendingFormat:@"/mp3"];
	
	return booksDir;
}
-(NSString*)getinstalledMp3Directory:(NSString*)fileName {
	NSString *pureName = [fileName stringByDeletingPathExtension];
	NSString *booksDir = [self getmp3Directory];
	NSString *ePubDir = [booksDir stringByAppendingPathComponent:pureName];
	return ePubDir;
}



// insert is 1 based
-(void)insertBook:(BookInformation *)bi {
    sqlite3_stmt *statement;
    char *sql = "INSERT INTO Book (Title,Author,Publisher,Subject,Type,Date,Language,Filename,IsFixedLayout,IsRTL,Position,Spread) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
    if (sqlite3_prepare_v2(database,sql,-1,&statement,NULL) == SQLITE_OK) {
        sqlite3_bind_text(statement,1,[bi.title UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement,2,[bi.creator UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement,3,[bi.publisher UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement,4,[bi.subject UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement,5,[bi.type UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement,6,[bi.date UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement,7,[bi.language UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement,8,[bi.fileName UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_int(statement,9, bi.isFixedLayout);
        sqlite3_bind_int(statement,10, bi.isRTL);
        double position = 0.0f;
        if (bi.isRTL) position = 1.0f;
        sqlite3_bind_double(statement,11, position);
        sqlite3_bind_int(statement,12, bi.spread);
        if (sqlite3_step(statement) != SQLITE_DONE) {
            NSLog(@"Error");
        }
    }
    sqlite3_finalize(statement);
}
-(BookInformation *)fetchBookInformations:(NSString *)title {
    NSLog(@"fetchBIS");
   
   
    NSString* condition =  [NSString stringWithFormat:@"WHERE Title like '%%%@%%'",title];
     BookInformation* bi = [[BookInformation alloc]init];
    
    sqlite3_stmt *selectStatement;
    NSString* baseSql = @"SELECT * FROM Book";
    NSString* sql = [NSString stringWithFormat:@"%@ %@",baseSql,condition];
    if (sqlite3_prepare_v2(database, [sql UTF8String], -1, &selectStatement, NULL) == SQLITE_OK) {
        while (sqlite3_step(selectStatement)==SQLITE_ROW) {
            
            bi.bookCode = sqlite3_column_int(selectStatement, 0);
            bi.title =      [self getColumnText:selectStatement columnIndex:1];
            bi.creator =    [self getColumnText:selectStatement columnIndex:2];
            bi.publisher =  [self getColumnText:selectStatement columnIndex:3];
            bi.subject =    [self getColumnText:selectStatement columnIndex:4];
            bi.type =       [self getColumnText:selectStatement columnIndex:5];
            bi.date =       [self getColumnText:selectStatement columnIndex:6];
            bi.language =   [self getColumnText:selectStatement columnIndex:7];
            bi.fileName =   [self getColumnText:selectStatement columnIndex:8];
            
           
            
            bi.position =   sqlite3_column_double(selectStatement, 9);
            bi.isFixedLayout = sqlite3_column_int(selectStatement, 10);
            bi.isGlobalPagination = sqlite3_column_int(selectStatement, 11);
            bi.isDownloaded = sqlite3_column_int(selectStatement, 12);
            bi.fileSize = sqlite3_column_int(selectStatement, 13);
            bi.customOrder = sqlite3_column_int(selectStatement, 14);
            bi.url = [self getColumnText:selectStatement columnIndex:15];
            bi.coverUrl = [self getColumnText:selectStatement columnIndex:16];
            bi.downSize = sqlite3_column_int(selectStatement, 17);
            bi.isRead = sqlite3_column_int(selectStatement, 18);
            bi.lastRead = [self getColumnText:selectStatement columnIndex:19];
            bi.isRTL = sqlite3_column_int(selectStatement, 20);
            bi.isVerticalWriting = sqlite3_column_int(selectStatement, 21);
            bi.spread = sqlite3_column_int(selectStatement, 22);
            
        }
    }
    sqlite3_finalize(selectStatement);
    return bi;
}
-(NSString *)getColumnText:(sqlite3_stmt*) statement columnIndex:(int)columnIndex {
    char *raw = (char *)sqlite3_column_text(statement,columnIndex);
    if (raw==NULL) return nil;
    else return  [NSString stringWithUTF8String:raw];
}
-(NSMutableArray *)fetchAllBookmarks:(int)bookCode{
    NSMutableArray *results = [[NSMutableArray alloc]init];
    sqlite3_stmt *selectStatement;
    NSString* sql = [NSString stringWithFormat:@"SELECT * FROM Bookmark where BookCode=%d ORDER BY ChapterIndex,PagePositionInBook",bookCode];
    if (sqlite3_prepare_v2(database, [sql UTF8String], -1, &selectStatement, NULL) == SQLITE_OK) {
        while (sqlite3_step(selectStatement)==SQLITE_ROW) {
            PageInformation* pageInformation = [[PageInformation alloc]init];
            pageInformation.bookCode = bookCode;
            pageInformation.code = sqlite3_column_int(selectStatement, 1);
            pageInformation.chapterIndex = sqlite3_column_int(selectStatement, 2);
            pageInformation.pagePositionInChapter = sqlite3_column_double(selectStatement, 3);
            pageInformation.pagePositionInBook = sqlite3_column_double(selectStatement, 4);
            pageInformation.pageDescription = [self getColumnText:selectStatement columnIndex:6];
            [results addObject:pageInformation];
        }
    }
    sqlite3_finalize(selectStatement);
    return results;
}
-(void)toggleBookmark:(PageInformation*)pi{
    int code = [self getBookmarkCode:pi];
    if (code == -1) { // if not exist
        [self insertBookmark:pi];
    }else {
        [self deleteBookmarkByCode:code]; // if exist, delete it
    }
}
-(int)getBookmarkCode:(PageInformation*)pi{
    sqlite3_stmt *selectStatement;
    double pageDelta = 1.0f/pi.numberOfPagesInChapter;
    double target = pi.pagePositionInChapter;
    int bookCode = pi.bookCode;
    NSString* selectSql = [NSString stringWithFormat:@"SELECT Code,PagePositionInChapter from Bookmark where BookCode=%d and ChapterIndex=%d",bookCode,pi.chapterIndex];
    if (sqlite3_prepare_v2(database, [selectSql UTF8String], -1, &selectStatement, NULL) == SQLITE_OK) {
        while (sqlite3_step(selectStatement)==SQLITE_ROW) {
            double ppc = sqlite3_column_double(selectStatement, 1);
            int code = sqlite3_column_int(selectStatement, 0);
            if (target>=(ppc-pageDelta/2) && target<=(ppc+pageDelta/2.0f)) {
                return code;
            }
        }
    }
    sqlite3_finalize(selectStatement);
    return -1;
}
// Bookmark routines
-(void)insertBookmark:(PageInformation *)pi{
    double ppb = pi.pagePositionInBook;
    double ppc = pi.pagePositionInChapter;
    int ci = pi.chapterIndex;
    int bc = pi.bookCode;
    
    NSDate* currentDate = [NSDate date];
    NSString* dateInString = [currentDate descriptionWithLocale:[NSLocale currentLocale]];
    NSString* sql = [NSString stringWithFormat:@"INSERT INTO Bookmark (BookCode,ChapterIndex,PagePositionInChapter,PagePositionInBook,CreatedDate) VALUES(%d,%d,%f,%f,'%@')",bc,ci,ppc,ppb,dateInString];
    [self executeSQL:sql];
}

-(void)deleteBookmarkByCode:(int)code{
    NSString* sql = [NSString stringWithFormat:@"DELETE FROM Bookmark where Code = %d",code];
    [self executeSQL:sql];
}
-(void)deleteBookmark:(PageInformation*)pi {
    int code = pi.code;
    [self deleteBookmarkByCode:code];
}

-(BOOL)isBookmarked:(PageInformation*)pageInformation{
    int code = [self getBookmarkCode:pageInformation];
    if (code==-1) {
        return NO;
    }else {
        return YES;
    }
}
// Highlight Routines

// fetch is 0 based
-(NSMutableArray *)fetchHighlights:(int)bookCode chapterIndex:(int)chapterIndex {
    NSMutableArray *results = [[NSMutableArray alloc]init];
    sqlite3_stmt *selectStatement;
    NSString* sql = [NSString stringWithFormat:@"SELECT * FROM Highlight where BookCode=%d and ChapterIndex=%d",bookCode,chapterIndex];
    if (sqlite3_prepare_v2(database, [sql UTF8String], -1, &selectStatement, NULL) == SQLITE_OK) {
        while (sqlite3_step(selectStatement)==SQLITE_ROW) {
            Highlight* highlight = [[Highlight alloc]init];
            highlight.bookCode = bookCode;
            highlight.code = sqlite3_column_int(selectStatement, 1);
            highlight.chapterIndex = chapterIndex;
            highlight.startIndex    = sqlite3_column_int(selectStatement, 3);
            highlight.startOffset   = sqlite3_column_int(selectStatement, 4);
            highlight.endIndex      = sqlite3_column_int(selectStatement, 5);
            highlight.endOffset     = sqlite3_column_int(selectStatement, 6);
            highlight.highlightColor= sqlite3_column_int(selectStatement, 7);
            highlight.text =        [self getColumnText:selectStatement columnIndex:8];
            highlight.note =        [self getColumnText:selectStatement columnIndex:9];
            highlight.isNote =      sqlite3_column_int(selectStatement, 10);
            highlight.datetime =      [self getColumnText:selectStatement columnIndex:11];
            [results addObject:highlight];
        }
    }
    sqlite3_finalize(selectStatement);
    return results;
}
-(NSMutableArray *)fetchAllHighlights:(int)bookCode{
    NSMutableArray *results = [[NSMutableArray alloc]init];
    sqlite3_stmt *selectStatement;
    NSString* sql = [NSString stringWithFormat:@"SELECT * FROM Highlight where BookCode=%d ORDER BY ChapterIndex,StartIndex,StartOffset,EndIndex,EndOffset",bookCode];
    if (sqlite3_prepare_v2(database, [sql UTF8String], -1, &selectStatement, NULL) == SQLITE_OK) {
        while (sqlite3_step(selectStatement)==SQLITE_ROW) {
            Highlight* highlight = [[Highlight alloc]init];
            highlight.bookCode = bookCode;
            highlight.code = sqlite3_column_int(selectStatement, 1);
            highlight.chapterIndex =  sqlite3_column_int(selectStatement, 2);
            highlight.startIndex    = sqlite3_column_int(selectStatement, 3);
            highlight.startOffset   = sqlite3_column_int(selectStatement, 4);
            highlight.endIndex      = sqlite3_column_int(selectStatement, 5);
            highlight.endOffset     = sqlite3_column_int(selectStatement, 6);
            highlight.highlightColor= sqlite3_column_int(selectStatement, 7);
            highlight.text =        [self getColumnText:selectStatement columnIndex:8];
            highlight.note =        [self getColumnText:selectStatement columnIndex:9];
            highlight.isNote =      sqlite3_column_int(selectStatement, 10);
            highlight.datetime =      [self getColumnText:selectStatement columnIndex:11];
            [results addObject:highlight];
        }
    }
    sqlite3_finalize(selectStatement);
    return results;
}


// Insert is 1 based
-(void)insertHighlight:(Highlight*)highlight {
    sqlite3_stmt *statement;
    char *sql = "INSERT INTO Highlight (BookCode,ChapterIndex,StartIndex,StartOffset,EndIndex,EndOffset,Color,Text,Note,IsNote,CreatedDate) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
    if (sqlite3_prepare_v2(database,sql,-1,&statement,NULL) == SQLITE_OK) {
        sqlite3_bind_int(statement,1, highlight.bookCode);
        sqlite3_bind_int(statement,2, highlight.chapterIndex);
        sqlite3_bind_int(statement,3, highlight.startIndex);
        sqlite3_bind_int(statement,4, highlight.startOffset);
        sqlite3_bind_int(statement,5, highlight.endIndex);
        sqlite3_bind_int(statement,6, highlight.endOffset);
        sqlite3_bind_int(statement,7, highlight.highlightColor);
        sqlite3_bind_text(statement,8,[highlight.text UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement,9,[highlight.note UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_int(statement,10, highlight.isNote);
        NSDate* currentDate = [NSDate date];
        NSString* dateInString = [currentDate descriptionWithLocale:[NSLocale currentLocale]];
        sqlite3_bind_text(statement,11,[dateInString UTF8String],-1, SQLITE_TRANSIENT);
        if (sqlite3_step(statement) != SQLITE_DONE) {
            NSLog(@"Error");
        }
    }
    sqlite3_finalize(statement);
}

-(void)deleteHighlight:(Highlight*)highlight {
    NSString *sql = [NSString stringWithFormat:@"DELETE FROM Highlight where BookCode=%d and ChapterIndex=%d and StartIndex=%d and StartOffset=%d and EndIndex=%d and EndOffset=%d",highlight.bookCode,highlight.chapterIndex,highlight.startIndex,highlight.startOffset,highlight.endIndex,highlight.endOffset];
    [self executeSQL:sql];
}

// Update is 1 Based
-(void)updateHighlight:(Highlight*)highlight {
    sqlite3_stmt *statement;
    char *sql = "UPDATE Highlight SET StartIndex=?,StartOffset=?,EndIndex=?,EndOffset=?,Color=?,Text=?,Note=?,IsNote=?,CreatedDate=? where BookCode=? and ChapterIndex=? and StartIndex=? and StartOffset=? and EndIndex=? and EndOffset=?";
    if (sqlite3_prepare_v2(database,sql,-1,&statement,NULL) == SQLITE_OK) {
        sqlite3_bind_int(statement,1, highlight.startIndex);
        sqlite3_bind_int(statement,2, highlight.startOffset);
        sqlite3_bind_int(statement,3, highlight.endIndex);
        sqlite3_bind_int(statement,4, highlight.endOffset);
        sqlite3_bind_int(statement,5, highlight.highlightColor);
        sqlite3_bind_text(statement,6,[highlight.text UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement,7,[highlight.note UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_int(statement,8, highlight.isNote);
        NSDate* currentDate = [NSDate date];
        NSString* dateInString = [currentDate descriptionWithLocale:[NSLocale currentLocale]];
        sqlite3_bind_text(statement,9,[dateInString UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_int(statement,10, highlight.bookCode);
        sqlite3_bind_int(statement,11, highlight.chapterIndex);
        sqlite3_bind_int(statement,12, highlight.startIndex);
        sqlite3_bind_int(statement,13, highlight.startOffset);
        sqlite3_bind_int(statement,14, highlight.endIndex);
        sqlite3_bind_int(statement,15, highlight.endOffset);
        
        if (sqlite3_step(statement) != SQLITE_DONE) {
            NSLog(@"Error");
        }
    }
    sqlite3_finalize(statement);
}
-(PagingInformation*)fetchPagingInformation:(PagingInformation*)pgi {
    sqlite3_stmt *selectStatement;
    PagingInformation *pg = NULL;
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM Paging WHERE BookCode=%d AND ChapterIndex=%d AND FontName='%@' AND FontSize=%d AND LineSpacing=%d AND Width=%d AND Height=%d AND HorizontalGapRatio=%f AND VerticalGapRatio=%f AND IsPortrait=%d AND IsDoublePagedForLandscape=%d",
                     pgi.bookCode,	pgi.chapterIndex,		pgi.fontName,		pgi.fontSize,		pgi.lineSpacing,	pgi.width,		pgi.height,		pgi.horizontalGapRatio,		pgi.verticalGapRatio,		pgi.isPortrait ? 1:0,	pgi.isDoublePagedForLandscape?1:0];
    if (sqlite3_prepare_v2(database, [sql UTF8String], -1, &selectStatement, NULL) == SQLITE_OK) {
        while (sqlite3_step(selectStatement)==SQLITE_ROW) {
            pg = [[PagingInformation alloc]init];
            pg.bookCode = sqlite3_column_int(selectStatement, 0);
            pg.code = sqlite3_column_int(selectStatement, 1);
            pg.chapterIndex = sqlite3_column_int(selectStatement, 2);
            pg.numberOfPagesInChapter = sqlite3_column_int(selectStatement, 3);
            pg.fontName = [self getColumnText:selectStatement columnIndex:4];
            pg.fontSize = sqlite3_column_int(selectStatement, 5);
            pg.lineSpacing = sqlite3_column_int(selectStatement, 6);
            pg.width = sqlite3_column_int(selectStatement, 7);
            pg.height = sqlite3_column_int(selectStatement, 8);
            pg.verticalGapRatio = sqlite3_column_double(selectStatement, 9);
            pg.horizontalGapRatio = sqlite3_column_double(selectStatement, 10);
            pg.isPortrait = sqlite3_column_int(selectStatement, 11);
            pg.isDoublePagedForLandscape =  sqlite3_column_int(selectStatement, 12);
        }
    }
    sqlite3_finalize(selectStatement);
    return pg;
}
-(void)deletePagingInformation:(PagingInformation*)pgi {
    NSString *sql = [NSString stringWithFormat:@"DELETE FROM Paging WHERE BookCode=%d AND ChapterIndex=%d AND FontName='%@' AND FontSize=%d AND LineSpacing=%d AND Width=%d AND Height=%d AND HorizontalGapRatio=%f AND VerticalGapRatio=%f AND IsPortrait=%d AND IsDoublePagedForLandscape=%d",pgi.bookCode,	pgi.chapterIndex,		pgi.fontName,		pgi.fontSize,		pgi.lineSpacing,	pgi.width,		pgi.height,		pgi.horizontalGapRatio,		pgi.verticalGapRatio,		pgi.isPortrait ? 1:0,	pgi.isDoublePagedForLandscape?1:0];
    [self executeSQL:sql];
}

-(void)insertPagingInformation:(PagingInformation *)pgi {
    PagingInformation* tgi = [self fetchPagingInformation:pgi];
    if (tgi!=NULL) {
        [self deletePagingInformation:tgi];
    }
    sqlite3_stmt *statement;
    char *sql = "INSERT INTO Paging (BookCode,ChapterIndex,NumberOfPagesInChapter,FontName,FontSize,LineSpacing,Width,height,VerticalGapRatio,HorizontalGapRatio,IsPortrait,IsDoublePagedForLandscape) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
    if (sqlite3_prepare_v2(database,sql,-1,&statement,NULL) == SQLITE_OK) {
        sqlite3_bind_int(statement,1,pgi.bookCode);
        sqlite3_bind_int(statement,2,pgi.chapterIndex);
        sqlite3_bind_int(statement,3,pgi.numberOfPagesInChapter);
        sqlite3_bind_text(statement,4,[pgi.fontName UTF8String],-1, SQLITE_TRANSIENT);
        sqlite3_bind_int(statement,5,pgi.fontSize);
        sqlite3_bind_int(statement,6,pgi.lineSpacing);
        sqlite3_bind_int(statement,7,pgi.width);
        sqlite3_bind_int(statement,8,pgi.height);
        sqlite3_bind_double(statement,9,pgi.verticalGapRatio);
        sqlite3_bind_double(statement,10,pgi.horizontalGapRatio);
        sqlite3_bind_int(statement,11,pgi.isPortrait);
        sqlite3_bind_int(statement,12,pgi.isDoublePagedForLandscape);
        if (sqlite3_step(statement) != SQLITE_DONE) {
            NSLog(@"Error");
        }
    }
    sqlite3_finalize(statement);
}
//// fetch is 0 based
//-(Setting*)fetchSetting {
//    NSLog(@"fetchSetting");
//    sqlite3_stmt *selectStatement;
//    Setting *aSetting;
//    char *selectSql = "SELECT * FROM Setting where BookCode=0";
//    if (sqlite3_prepare_v2(database, selectSql, -1, &selectStatement, NULL) == SQLITE_OK) {
//        while (sqlite3_step(selectStatement)==SQLITE_ROW) {
//            aSetting = [[Setting alloc]init];
//            aSetting.bookCode =      sqlite3_column_int(selectStatement, 0);
//            aSetting.fontName =      [self getColumnText:selectStatement columnIndex:1];
//            aSetting.fontSize =      sqlite3_column_int(selectStatement, 2);
//            aSetting.lineSpace=      sqlite3_column_int(selectStatement, 3);
//            aSetting.foreground=     sqlite3_column_int(selectStatement, 4);
//            aSetting.background=     sqlite3_column_int(selectStatement, 5);
//            aSetting.theme  =        sqlite3_column_int(selectStatement, 6);
//            aSetting.brightness =    sqlite3_column_double(selectStatement, 7);
//            aSetting.transitionType= sqlite3_column_int(selectStatement, 8);
//            aSetting.lockRotation =  sqlite3_column_int(selectStatement, 9);
//            aSetting.doublePaged  =  sqlite3_column_int(selectStatement, 10);
//            aSetting.allow3G  =      sqlite3_column_int(selectStatement, 11);
//            aSetting.globalPagination  =  sqlite3_column_int(selectStatement, 12);
//        }
//    }
//    sqlite3_finalize(selectStatement);
//    return aSetting;
//}
//
//-(void)updateSetting:(Setting*)aSetting {
//    NSString *sql = [NSString stringWithFormat:@"UPDATE Setting SET FontName='%@', FontSize=%d , LineSpacing=%d , Foreground=%d , Background=%d , Theme=%d , Brightness=%f, TransitionType=%d , LockRotation=%d , DoublePaged=%d,Allow3G=%d,GlobalPagination=%d where BookCode=0",aSetting.fontName,aSetting.fontSize,aSetting.lineSpace,aSetting.foreground,aSetting.background,aSetting.theme,aSetting.brightness,aSetting.transitionType,aSetting.lockRotation,aSetting.doublePaged,aSetting.allow3G,aSetting.globalPagination];
//    [self executeSQL:sql];
//}


-(void)setSleepTime:(NSInteger)time{
    [_sleeptimer invalidate], _sleeptimer = nil;
    
    _sleeptimer = [NSTimer scheduledTimerWithTimeInterval:time*60 target:self selector:@selector(StopPlayer) userInfo:nil repeats:NO];
    
}
-(void)invalidateTimer{
    [_sleeptimer invalidate], _sleeptimer = nil;
}
-(void)StopPlayer{
    NSLog(@"--Stopped--");
    [_audioController stop];
    _sleepindex = 0;
}
-(NSString *)getDurationForSeconds:(int)duration{
    int minutes = duration / 60;
    int seconds = duration % 60;
    
    return  [NSString stringWithFormat:@"%d:%02d", minutes, seconds];
}
-(int)getminuteForTotalSeconds:(int)duration{
    int minutes = duration / 60;
    
    
    return  minutes;
}
-(int)getsecondForTotalSeconds:(int)duration{
    
    int seconds = duration % 60;
    
    return  seconds;
}

- (float)minuteToSecondConvert:(NSString *)string {
    
    NSArray *components = [string componentsSeparatedByString:@":"];
    
    NSInteger minutes   = [[components objectAtIndex:0] integerValue];
    NSInteger seconds = [[components objectAtIndex:1] integerValue];
    
    
    return (minutes * 60) + seconds;
}
@end
