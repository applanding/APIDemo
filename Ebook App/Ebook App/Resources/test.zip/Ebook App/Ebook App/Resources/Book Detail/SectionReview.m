//
//  SectionReview.m
//  Ebook App
//
//  Created by macmini3 on 17/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "SectionReview.h"

@implementation SectionReview

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void)PopulateResult:(NSMutableArray *)result{
    
    if(result){
   
    _lbl_ratingcount.text = [NSString stringWithFormat:@"%lu Ratings",(unsigned long)[result count]];
    
    TQStarRatingView   *starRatingView = [[TQStarRatingView alloc] initWithCustomeFrame:CGRectMake(10, _lbl_ratingcount.frame.origin.y +(_lbl_ratingcount.frame.size.height/2.0)-6 , 60, 12)
                                                                           numberOfStar:kNUMBER_OF_STAR];
    starRatingView.userInteractionEnabled = NO;
    
        float sum = 0;
        for (int i = 0; i < [result count]; i++) {
            if (![[[result objectAtIndex:i]valueForKey:@"star"]isEqual:[NSNull null]]) {
            sum  += [[[result objectAtIndex:i]valueForKey:@"star"]intValue];
        }
        }
        [starRatingView setScore:(sum/([[NSString stringWithFormat:@"%lu",(unsigned long)result.count]intValue]*5.0)) withAnimation:NO];
	[self addSubview:starRatingView];

        float count1 = 0;
        float count2 = 0;
        float count3 = 0;
        float count4 = 0;
        float count5 = 0;
        
        for (int i = 0; i < [result count]; i++) {
            if (![[[result objectAtIndex:i]valueForKey:@"star"]isEqual:[NSNull null]]) {
            if ([[[result objectAtIndex:i]valueForKey:@"star"]intValue] == 5) {
                count1++;
            }
            if ([[[result objectAtIndex:i]valueForKey:@"star"]intValue] == 4) {
                count2++;
            }
            if ([[[result objectAtIndex:i]valueForKey:@"star"]intValue] == 3) {
                count3++;
            }
            if ([[[result objectAtIndex:i]valueForKey:@"star"]intValue] == 2) {
                count4++;
            }
            if ([[[result objectAtIndex:i]valueForKey:@"star"]intValue] == 1) {
                count5++;
            }
        }
        }
        [_progress1 setProgress:count1/[[NSString stringWithFormat:@"%lu",(unsigned long)result.count]floatValue]];
        [_progress2 setProgress:count2/[[NSString stringWithFormat:@"%lu",(unsigned long)result.count]floatValue]];
        [_pregress3 setProgress:count3/[[NSString stringWithFormat:@"%lu",(unsigned long)result.count]floatValue]];
        [_progress4 setProgress:count4/[[NSString stringWithFormat:@"%lu",(unsigned long)result.count]floatValue]];
        [_progress5 setProgress:count5/[[NSString stringWithFormat:@"%lu",(unsigned long)result.count]floatValue]];
        
        
        
    }
    TQStarRatingView   *starRatingView1 = [[TQStarRatingView alloc] initWithReviewFrame:CGRectMake(10, _progress1.frame.origin.y +(_progress1.frame.size.height/2.0)-6 , 60, 12)
                                                                           numberOfStar:kNUMBER_OF_STAR];
    starRatingView1.userInteractionEnabled = NO;
    [starRatingView1 setScore:5.0/5.0 withAnimation:NO];
    starRatingView1.transform = CGAffineTransformMakeScale(-1, 1);
    [self addSubview:starRatingView1];
    
    
    TQStarRatingView   *starRatingView2 = [[TQStarRatingView alloc] initWithReviewFrame:CGRectMake(10, _progress2.frame.origin.y +(_progress2.frame.size.height/2.0)-6 , 60, 12)
                                                                           numberOfStar:kNUMBER_OF_STAR];
    starRatingView2.userInteractionEnabled = NO;
    [starRatingView2 setScore:4.0/5.0 withAnimation:NO];
    starRatingView2.transform = CGAffineTransformMakeScale(-1, 1);
    [self addSubview:starRatingView2];
    
    
    TQStarRatingView   *starRatingView3 = [[TQStarRatingView alloc] initWithReviewFrame:CGRectMake(10, _pregress3.frame.origin.y +(_pregress3.frame.size.height/2.0)-6 , 60, 12)
                                                                           numberOfStar:kNUMBER_OF_STAR];
    starRatingView3.userInteractionEnabled = NO;
    [starRatingView3 setScore:3.0/5.0 withAnimation:NO];
    starRatingView3.transform = CGAffineTransformMakeScale(-1, 1);
    [self addSubview:starRatingView3];
    
    
    TQStarRatingView   *starRatingView4 = [[TQStarRatingView alloc] initWithReviewFrame:CGRectMake(10, _progress4.frame.origin.y +(_progress4.frame.size.height/2.0)-6 , 60, 12)
                                                                           numberOfStar:kNUMBER_OF_STAR];
    starRatingView4.userInteractionEnabled = NO;
    [starRatingView4 setScore:2.0/5.0 withAnimation:NO];
    starRatingView4.transform = CGAffineTransformMakeScale(-1, 1);
    [self addSubview:starRatingView4];
    
    TQStarRatingView   *starRatingView5 = [[TQStarRatingView alloc] initWithReviewFrame:CGRectMake(10, _progress5.frame.origin.y +(_progress5.frame.size.height/2.0)-6 , 60, 12)
                                                                           numberOfStar:kNUMBER_OF_STAR];
    starRatingView5.userInteractionEnabled = NO;
    [starRatingView5 setScore:1.0/5.0 withAnimation:NO];
    starRatingView5.transform = CGAffineTransformMakeScale(-1, 1);
    [self addSubview:starRatingView5];


}
- (IBAction)writereview:(id)sender {
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@#review",Review_Path,_bookUrl]]];
}
@end
