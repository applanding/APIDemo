//
//  ChapterTableViewCell.h
//  Ebook App
//
//  Created by macmini3 on 17/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface ChapterTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lbl_index;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UILabel *lbl_time;
-(void)populateResult:(NSMutableDictionary *)dict;
@end
