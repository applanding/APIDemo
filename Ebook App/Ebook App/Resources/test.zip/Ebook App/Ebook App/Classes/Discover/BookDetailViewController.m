//
//  BookDetailViewController.m
//  Ebook App
//
//  Created by macmini3 on 15/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "BookDetailViewController.h"

@interface BookDetailViewController ()

@end

@implementation BookDetailViewController
#define botttomheight 210
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [_btn_back setTitle:_backbtntitle forState:UIControlStateNormal];
    
    _swipeview.pagingEnabled = YES;
    [_swipeview scrollToItemAtIndex:_pageindex duration:0];
   
    bookdetaildict = [[NSMutableDictionary alloc]init];
    
    ModelClass *mc = [[ModelClass alloc]init];
    _view_middle.hidden = YES;
    _view_bottom1.hidden = YES;
    [mc GetbookDetail:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_pageindex]valueForKey:@"bookUrl"]] success:^(id result) {
        [bookdetaildict setValue:result forKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_pageindex]valueForKey:@"bookUrl"]]];
        [self ManipulateData];
         _view_middle.hidden = NO;
         _view_bottom1.hidden = NO;
        
   //     NSLog(@"-->%@",result);
       
    } error:^(NSError *error) {
        //  NSLog(@"-->%@",error.description);
        
    }];
    
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    if (!DELEGATE.playDict) {
        _btn_nowplaying.hidden = YES;
    }else{
        _btn_nowplaying.hidden = NO;
    }
    if (DELEGATE.RemoveAllAds) {
        for (UIView *view in _view_bottomrelated.subviews) {
            if ([view isKindOfClass:[UIView class]]){
                if ([view.accessibilityIdentifier isEqualToString:@"ads"]) {
                    [view removeFromSuperview];
                }
            }
        }
    }
}

#pragma mark -
#pragma mark iCarousel methods

- (NSInteger)numberOfItemsInSwipeView:(SwipeView *)swipeView
{
    //return the total number of items in the carousel
    return [_booksarray count];
}

- (UIView *)swipeView:(SwipeView *)swipeView viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
   
    BookCommon *item;
    //create new view if no view is available for recycling
    if (view == nil)
    {
        //don't do anything specific to the index within
        //this `if (view == nil) {...}` statement because the view will be
        //recycled and used with other index values later
        item = [[[NSBundle mainBundle] loadNibNamed:@"BookDetail" owner:self options:nil] lastObject];
        
        
    }
    else
    {
        //get a reference to the label in the recycled view
        item = (BookCommon *)view;
        
        
    }
    [item setAccessibilityIdentifier:@"BookDetail"];
    item.delgate = self;
    item.accessibilityHint = @"-1";
    [item PopulateResult:[_booksarray objectAtIndex:index] showstar:YES];

   
   return item;
    
    //set item label
    //remember to always set any properties of your carousel item
    //views outside of the `if (view == nil) {...}` check otherwise
    //you'll get weird issues with carousel item content appearing
    //in the wrong place in the carousel
   
    
    return view;
}
- (void)swipeViewDidEndDecelerating:(SwipeView *)swipeView{
    
    
    if (![bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]) {
        ModelClass *mc = [[ModelClass alloc]init];
        _view_middle.hidden = YES;
        _view_bottom1.hidden = YES;
        _view_bottomrelated.hidden = YES;
        [mc GetbookDetail:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]] success:^(id result) {
            [bookdetaildict setValue:result forKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]];
            
            _view_middle.hidden = NO;
            _view_bottom1.hidden = NO;
            [self ManipulateData];
        } error:^(NSError *error) {
            //  NSLog(@"-->%@",error.description);
            
        }];
        
    }else{
       
        [self ManipulateData];
   
    }
}

- (CGSize)swipeViewItemSize:(SwipeView *)swipeView
{
    if (IPHONE) {
        CGSize size = CGSizeMake(290, self.swipeview.bounds.size.height);
        return size;
    }else{
        CGSize size = CGSizeMake(630, self.swipeview.bounds.size.height);
        return size;
    }
    
}

-(void)ManipulateData{
    BookCommon *item = (BookCommon *)_swipeview.currentItemView;
    if ([[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"reviews"]count]!=0) {
        
        item.lbl_reviewcount.text = [NSString stringWithFormat:@"(%lu)",(unsigned long)[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"reviews"]count]];
    }
    [item.imgview_book setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"details"]valueForKey:@"image"]]] placeholderImage:item.imgview_book.image];
    if ([[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"mp3"]count] == 0) {
        item.btn_play.hidden = YES;
        item.btn_read.hidden = YES;
    }else{
        item.btn_play.hidden = NO;
        item.btn_read.hidden = NO;
    }
    
 //   [item PopulateResult:[_booksarray objectAtIndex:_swipeview.currentItemIndex] showstar:YES];
    for (UIView *view in _view_middle.subviews) {
        if ([view isKindOfClass:[DWTagList class]]) {
            [view removeFromSuperview];
        }
    }
   DWTagList *tagList = [[DWTagList alloc] initWithFrame:CGRectMake(20.0f, 10.0f, 280, 50.0f)];
    if (!IPHONE) {
        [tagList setFrame:CGRectMake(20.0f, 10.0f, 600.0f, 50.0f)];
    }
    [tagList setAutomaticResize:YES];
    [tagList display];
    [tagList setTags:[NSArray arrayWithArray:[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"genres"]]];
    [tagList setTagDelegate:self];
    
    // Customisation
 //   tagList.userInteractionEnabled = NO;
    [tagList setCornerRadius:10.0f];
    [tagList setBorderColor:[UIColor lightGrayColor].CGColor];
    [tagList setTextColor:[UIColor lightGrayColor]];
    [tagList setBackgroundColor:[UIColor clearColor]];
    [tagList setBorderWidth:1.0f];
    
    
//    _txt_description.text = [NSString stringWithFormat:@"%@",[self stripTags:[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"details"]valueForKey:@"description"]]] ;
//    [_txt_description sizeToFit];
    
   
    NSAttributedString *attributedString = [[NSAttributedString alloc] initWithData:[[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"details"]valueForKey:@"description"] dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
    _txt_description.attributedText = attributedString;
    [_txt_description sizeToFit];
    
   
    
    
    _view_bottomrelated.hidden = YES;
    _view_bottom1.hidden = NO;
    if ([[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"reviews"]count] == 0) {
        _segment.selectedSegmentIndex = 1;
    }else{
        _segment.selectedSegmentIndex = 0;
    }
    [_tableview reloadData];
    
    
    [UIView animateWithDuration:0.3 animations:^{
         [_view_middle addSubview:tagList];
        [_segment setFrame:CGRectMake(_segment.frame.origin.x, _txt_description.frame.origin.y + _txt_description.frame.size.height + 25 , _segment.frame.size.width, _segment.frame.size.height)];
        [_view_description setFrame:CGRectMake(_view_description.frame.origin.x, tagList.frame.origin.y+ tagList.frame.size.height + 5, _view_description.frame.size.width, _segment.frame.origin.y + _segment.frame.size.height + 15)];
        
        [_view_middle setFrame:CGRectMake(_view_middle.frame.origin.x, _view_middle.frame.origin.y , _view_middle.frame.size.width, _view_description.frame.origin.y+ _view_description.frame.size.height)];
        
        [_view_bottom1 setFrame:CGRectMake(_view_bottom1.frame.origin.x, _view_middle.frame.origin.y+_view_middle.frame.size.height, _view_bottom1.frame.size.width, [self tableViwHeight]+ _tableview.frame.origin.y)];
        [_tableview setFrame:CGRectMake(_tableview.frame.origin.x, _tableview.frame.origin.y, _tableview.frame.size.width, [self tableViwHeight])];
        
    } completion: ^(BOOL finished) {
        
         [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, _view_bottom1.frame.origin.y + _view_bottom1.frame.size.height)];
        
        
        [[_view_bottomrelated subviews]
         makeObjectsPerformSelector:@selector(removeFromSuperview)];
        
        UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, _view_bottomrelated.frame.size.width, 1)];
        [img setImage:[UIImage imageNamed:@"seprator"]];
        [_view_bottomrelated addSubview:img];
        
        is_displayed = NO;
        
        
        
    }];
    
   
  
}
- (void)selectedTag:(NSString *)tagName tagIndex:(NSInteger)tagIndex{
//    GenreShowcaseViewController *genre = [[GenreShowcaseViewController alloc]initWithNibName:@"GenreShowcaseViewController" bundle:nil];
//    genre.genreUrl = [NSString stringWithFormat:@"%@",tagName];
//    genre.genreTitle = [NSString stringWithFormat:@"%@",tagName];
//    genre.backbtntitle  = @"Details";
//    [self.navigationController pushViewController:genre animated:YES];
}
-(void)setupAds{
  
        // set up label
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, _view_bottomrelated.frame.size.height-1, _view_bottomrelated.frame.size.width, 70)];
        footerView.backgroundColor = [UIColor colorWithRed:248.0/255.0 green:248.0/255.0 blue:248.0/255.0 alpha:1.0];
     footerView.accessibilityIdentifier = @"ads";
    
    UIButton *button =[UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(80, 2,160, 18);
    [button.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
     [button setCenter:CGPointMake(footerView.frame.size.width/2, button.center.y)];
    [button setTitle:@"Remove Ads" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(removeAdtap:) forControlEvents:UIControlEventTouchUpInside];
    [footerView addSubview:button];
    
    
//        UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 20, 320, 50)];
//        [img setImage:[UIImage imageNamed:@"banner"]];
//        [footerView addSubview:img];
    
    
    admobBannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeSmartBannerPortrait] ;
    [admobBannerView setFrame:CGRectMake(admobBannerView.frame.origin.x, 20, admobBannerView.frame.size.width, admobBannerView.frame.size.height)];
    admobBannerView.adUnitID = AdMob_ID_Related;
    admobBannerView.rootViewController = self;
    [footerView addSubview:admobBannerView];
    [admobBannerView loadRequest:[GADRequest request]];
    
    [footerView setFrame:CGRectMake(0, _view_bottomrelated.frame.size.height-1, _view_bottomrelated.frame.size.width, admobBannerView.frame.size.height + 20)];

    
    
    [_view_bottomrelated addSubview:footerView];
    [_view_bottomrelated setFrame:CGRectMake(_view_bottomrelated.frame.origin.x, _view_middle.frame.origin.y+_view_middle.frame.size.height, _view_bottomrelated.frame.size.width, _view_bottomrelated.frame.size.height+footerView.frame.size.height)];
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;

}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (_segment.selectedSegmentIndex == 0) {
        if (IPHONE) {
            return 190;
        }else{
            return 160;
        }
        
    }
    else if (_segment.selectedSegmentIndex == 1) {
        return 44;
    }
    return 1;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
   
    if (_segment.selectedSegmentIndex == 0) {
        static NSString *CellIdentifier = @"SectionReview";
        SectionReview *cell = (SectionReview *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell==nil) {
            NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell= (SectionReview *)[arrNib objectAtIndex:0];
            
        }
        [cell setBookUrl:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_pageindex]valueForKey:@"bookUrl"]]];
        [cell PopulateResult:[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"reviews"]];
        return cell;
    }
    else if (_segment.selectedSegmentIndex == 1) {
        [view setFrame:CGRectMake(0, 0, _tableview.frame.size.width, 44)];
        [view setBackgroundColor:[UIColor colorWithRed:248.0/255.0 green:248.0/255.0 blue:248.0/255.0 alpha:1.0]];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 320, 44)];
        label.font = [UIFont boldSystemFontOfSize:16];
        label.textColor = [UIColor blackColor];
        label.textAlignment = NSTextAlignmentLeft;
        label.text = @"Chapters";
        [view addSubview:label];
        
        UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(15, 43, view.frame.size.width, 0.5)];
        [img setBackgroundColor:[UIColor colorWithRed:170.0/255.0 green:170.0/255.0 blue:170.0/255.0 alpha:0.5]];
        [view addSubview:img];
    }
    return view;
}
-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    if (_segment.selectedSegmentIndex == 0) {
        return [[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"reviews"]count];
    }
   else if (_segment.selectedSegmentIndex == 1) {
   return [[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"mp3"]count];
   
   }
    
    
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_segment.selectedSegmentIndex == 0) {
        
        NSString *str = [[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"reviews"]objectAtIndex:indexPath.row]valueForKey:@"review"];
        if (IPHONE){
        return [self textViewHeightText:str andWidth:301.0] + 60;
        }else{
            return [self textViewHeightText:str andWidth:610.0] + 60;
        }
    }
    else if (_segment.selectedSegmentIndex == 1) {
        return 44;
    }
    return 40;
}
- (CGFloat)textViewHeightText:(NSString *)text andWidth:(CGFloat)width
{
    UITextView *textView = [[UITextView alloc] init];
    [textView setFont:[UIFont systemFontOfSize:12]];
    [textView setText:text];
    CGSize size = [textView sizeThatFits:CGSizeMake(width, FLT_MAX)];
    return size.height;
}
-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    if (_segment.selectedSegmentIndex == 0) {
        static NSString *CellIdentifier = @"ReviewTableViewCell";
        ReviewTableViewCell *cell = (ReviewTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell==nil) {
            NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell= (ReviewTableViewCell *)[arrNib objectAtIndex:0];
            
        }
        cell.tag = indexPath.row+1;
        [cell populateResult:[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"reviews"]objectAtIndex:indexPath.row]];
        
        return cell;
    }
    else if (_segment.selectedSegmentIndex == 1) {
        static NSString *CellIdentifier = @"ChapterTableViewCell";
        ChapterTableViewCell *cell = (ChapterTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell==nil) {
            NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell= (ChapterTableViewCell *)[arrNib objectAtIndex:0];
            
        }
         cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.tag = indexPath.row+1;
        [cell populateResult:[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"mp3"]objectAtIndex:indexPath.row]];
        
        return cell;
    }
    
        static NSString *CellIdentifier = @"Cell";
        // add a placeholder cell while waiting on table data
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (_segment.selectedSegmentIndex == 0) {
       
    }
    else if (_segment.selectedSegmentIndex == 1) {
        
        MyBookDetailViewController *godetail = [[MyBookDetailViewController alloc]initWithNibName:@"MyBookDetailViewController" bundle:nil];
        godetail.myBookDict = [bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]];
    
            FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
            item.title = [[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]] valueForKey:@"mp3"]objectAtIndex:indexPath.row]valueForKey:@"title"];
            item.url = [[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]] valueForKey:@"mp3"]objectAtIndex:indexPath.row]valueForKey:@"file"];
            item.number = indexPath.row;
            DELEGATE.playingIndex = indexPath.row;
            godetail.selectedPlaylistItem = item;
            godetail.shouldStartPlaying = YES;
            godetail.hidesBottomBarWhenPushed = YES;
        DELEGATE.playDict = [NSMutableDictionary dictionaryWithDictionary:[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]];
        [self.navigationController pushViewController:godetail animated:YES];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
- (CGFloat)tableViwHeight
{
    [_tableview layoutIfNeeded];
    
    
    return [_tableview contentSize].height;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)selectOption:(id)sender {
    
    
    switch (_segment.selectedSegmentIndex) {
        case 0:
            _view_bottomrelated.hidden = YES;
            _view_bottom1.hidden = NO;
            [_tableview reloadData];
            
            [_view_bottom1 setFrame:CGRectMake(_view_bottom1.frame.origin.x, _view_middle.frame.origin.y+_view_middle.frame.size.height, _view_bottom1.frame.size.width, [self tableViwHeight]+ _tableview.frame.origin.y)];
            [_tableview setFrame:CGRectMake(_tableview.frame.origin.x, _tableview.frame.origin.y, _tableview.frame.size.width, [self tableViwHeight])];
            [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, _view_bottom1.frame.origin.y + _view_bottom1.frame.size.height)];
            break;
         case 1:
            _view_bottomrelated.hidden = YES;
            _view_bottom1.hidden = NO;
             [_tableview reloadData];
            [_view_bottom1 setFrame:CGRectMake(_view_bottom1.frame.origin.x, _view_middle.frame.origin.y+_view_middle.frame.size.height, _view_bottom1.frame.size.width, [self tableViwHeight]+ _tableview.frame.origin.y)];
            [_tableview setFrame:CGRectMake(_tableview.frame.origin.x, _tableview.frame.origin.y, _tableview.frame.size.width, [self tableViwHeight])];
            [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, _view_bottom1.frame.origin.y + _view_bottom1.frame.size.height)];
            break;
            
        case 2:
            if(is_displayed){
            
                _view_bottomrelated.hidden = NO;
                _view_bottom1.hidden = YES;
                [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, _view_bottomrelated.frame.origin.y + _view_bottomrelated.frame.size.height)];
                
            }else{
            
                dispatch_async(dispatch_get_main_queue(), ^{
                    is_displayed = YES;
                     [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        for (int i = 0; i < [[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"related"] count] ; i++) {
                            
                            [self setupNormal:[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"related"] objectAtIndex:i] yaxis:((i)*(botttomheight+35)+1) tag:i];
                            [_view_bottomrelated setFrame:CGRectMake(_view_bottomrelated.frame.origin.x, _view_middle.frame.origin.y+_view_middle.frame.size.height, _view_bottomrelated.frame.size.width, ((i)*(botttomheight+35)+botttomheight+35))];
                            
                        }
                        if (!DELEGATE.RemoveAllAds) {
                            [self setupAds];
                        }
                        
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                            _view_bottomrelated.hidden = NO;
                            _view_bottom1.hidden = YES;
                            [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, _view_bottomrelated.frame.origin.y + _view_bottomrelated.frame.size.height)];
                        });
                        
                        
                    });
                    
                });
                
            }
            
            
            break;
        default:
            break;
    }
    
    
    
}
- (void)setupNormal:(NSMutableDictionary *)result yaxis:(float)y tag:(int)tag {
    NSMutableArray *items = [NSMutableArray array];
    
    for (int i = 0; i<[[result valueForKey:@"books"]count]; i++) {
        BookCommon *item = [[[NSBundle mainBundle] loadNibNamed:@"BookNormal" owner:self options:nil] lastObject];
        [item setDelgate:self];
        [item setAccessibilityIdentifier:@"BookNormal"];
        item.tag = tag;
        [item setAccessibilityHint:[NSString stringWithFormat:@"%d",i]];
        [item PopulateResult:[[result valueForKey:@"books" ]objectAtIndex:i] showstar:YES];
        [items addObject:item];
    }
    
    
    
    ILSideScrollView *scroller1 = [[ILSideScrollView alloc] initWithFrame:
                                   CGRectMake(0,
                                              y,
                                              _scrollview.frame.size.width,
                                              botttomheight)];
    [scroller1 setBackgroundColor:[UIColor clearColor]];
    [scroller1 populateSideScrollViewWithItems:items];
    
    [_view_bottomrelated addSubview:scroller1];
    
    UILabel *lblName = [[UILabel alloc]initWithFrame:CGRectMake(10, y+20, 250, 20)];
    lblName.text = [NSString stringWithFormat:@"%@",[result valueForKey:@"title"]] ;
    [lblName setBackgroundColor:[UIColor clearColor]];
    [lblName setTextColor:[UIColor blackColor]];
    lblName.font =[UIFont systemFontOfSize:16];
    [_view_bottomrelated addSubview:lblName];
    
    if ([result valueForKey:@"genreUrl"]) {
        
    UILabel *seeall = [[UILabel alloc]initWithFrame:CGRectMake(_view_bottomrelated.frame.size.width - 60, y +20, 100, 20)];
    seeall.text = @"See All >" ;
    [seeall setBackgroundColor:[UIColor clearColor]];
    [seeall setTextColor:[UIColor lightGrayColor]];
    seeall.font =[UIFont systemFontOfSize:12];
    seeall.accessibilityIdentifier = [NSString stringWithFormat:@"%@",[result valueForKey:@"genreUrl"]];
    seeall.userInteractionEnabled = YES;
    [_view_bottomrelated addSubview:seeall];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didTouchseeallNormal:)];
        [seeall addGestureRecognizer:tap];
    }
    
   
    
    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, scroller1.frame.origin.y+ scroller1.frame.size.height, _view_bottomrelated.frame.size.width, 1)];
    [img setImage:[UIImage imageNamed:@"seprator"]];
  //  [img setBackgroundColor:[UIColor redColor]];
    [_view_bottomrelated addSubview:img];
    
    
    
}
-(void)didTouchBook:(NSMutableDictionary *)book{
    
    
    if (![[book valueForKey:@"index"]isEqualToString:@"-1"]) {
        
    BookDetailViewController *detail = [[BookDetailViewController alloc]initWithNibName:@"BookDetailViewController" bundle:nil];
    detail.booksarray = [NSMutableArray arrayWithArray:[[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex]valueForKey:@"bookUrl"]]]valueForKey:@"related"] objectAtIndex:[[book valueForKey:@"tag"]intValue]]valueForKey:@"books"]];
    detail.pageindex = [[book valueForKey:@"index"]intValue];
        detail.backbtntitle = @"Details";
        if(IPHONE)
        {
            [self.navigationController pushViewController:detail animated:YES];
        }else{
            
            [self addChildViewController: detail];
            [self.view addSubview: detail.view];
            
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(removeChild:)];
            [detail.tapableview addGestureRecognizer:tap];
        }
    }
    
    
}
-(void)removeChild:(UITapGestureRecognizer *)sender{
    UIViewController *vc = [self.childViewControllers lastObject];
    [vc willMoveToParentViewController:nil];
    [vc.view removeFromSuperview];
    [vc removeFromParentViewController];
   
    
}
-(void)didTouchseeallNormal:(UITapGestureRecognizer *)sender{
    UILabel *lbl = (UILabel *)sender.view;
    //  NSLog(@"--->%@",lbl.accessibilityIdentifier);
    
    AllBookListViewController *goseall = [[AllBookListViewController alloc]initWithNibName:@"AllBookListViewController" bundle:nil];
    goseall.identifier = [NSString stringWithFormat:@"%@",lbl.accessibilityIdentifier];
    goseall.is_genre = YES;
    goseall.backbtntitle = @"Details";
    [self.navigationController pushViewController:goseall animated:YES];
    
}

-(void)didTouchAddBook:(NSMutableDictionary *)book{
    
  //  NSLog(@"--->%@",book);
    if (!MyBooks) {
        
        NSArray *temp = [NSArray arrayWithObject:[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]]];
        NSData *personEncodedObject = [NSKeyedArchiver archivedDataWithRootObject:temp];
        [[NSUserDefaults standardUserDefaults]setObject:personEncodedObject  forKey:@"MyBooks"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }else{
        NSMutableArray *temp = [NSMutableArray arrayWithArray:MyBooks];
        [temp addObject:[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]]];
        NSData *personEncodedObject = [NSKeyedArchiver archivedDataWithRootObject:temp];
        [[NSUserDefaults standardUserDefaults]setObject:personEncodedObject  forKey:@"MyBooks"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    
 //   [[[UIAlertView alloc] initWithTitle:@"" message:@"Book added successfully." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
    
}
-(void)didTouchRemovebook:(NSMutableDictionary *)book{
    
    for (int i = 0; i < [MyBooks count]; i++) {
        if ([[[MyBooks objectAtIndex:i]valueForKeyPath:@"details.bookUrl"]isEqualToString:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]]) {
            NSMutableArray *temp = [NSMutableArray arrayWithArray:MyBooks];
            [[NSFileManager defaultManager]removeItemAtPath:[DELEGATE getinstalledEPubDirectory:[[[MyBooks objectAtIndex:i]valueForKeyPath:@"details.ePub"] lastPathComponent]] error:nil];
            
            [temp removeObjectAtIndex:i];
            NSData *personEncodedObject = [NSKeyedArchiver archivedDataWithRootObject:temp];
            [[NSUserDefaults standardUserDefaults]setObject:personEncodedObject  forKey:@"MyBooks"];
            [[NSUserDefaults standardUserDefaults]synchronize];
        }
    }
    
    
    
}
-(void)didTouchPlay:(NSMutableDictionary *)book{
    
    
    MyBookDetailViewController *godetail = [[MyBookDetailViewController alloc]initWithNibName:@"MyBookDetailViewController" bundle:nil];
    godetail.myBookDict = [bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]];
    
    if ([[DELEGATE.playDict valueForKeyPath:@"details.bookUrl"] isEqualToString:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]]) {
        FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
        item.title = [[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]] valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"title"];
        item.url = [[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]] valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"file"];
        item.number = DELEGATE.playingIndex;
        godetail.selectedPlaylistItem = item;
    }
    else if ([[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]] valueForKey:@"mp3"]count]> 0) {
        FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
        item.title = [[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]] valueForKey:@"mp3"]objectAtIndex:0]valueForKey:@"title"];
        item.url = [[[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]] valueForKey:@"mp3"]objectAtIndex:0]valueForKey:@"file"];
        item.number = 0;
        godetail.selectedPlaylistItem = item;
        DELEGATE.playingIndex = 0;
        godetail.shouldStartPlaying = YES;
    }
    godetail.hidesBottomBarWhenPushed = YES;
    DELEGATE.playDict = [NSMutableDictionary dictionaryWithDictionary:[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]]];
    [self.navigationController pushViewController:godetail animated:YES];
}

-(void)didTouchAddRead:(NSMutableDictionary *)book{
    NSLog(@"--->%@",book);
    
    
    
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:[DELEGATE getinstalledEPubDirectory:[[[NSString stringWithFormat:@"%@",[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]] valueForKeyPath:@"details.ePub"]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] lastPathComponent]]];
    if (fileExists){
        EpubReaderViewController *bvc = [[EpubReaderViewController alloc]initWithNibName:@"EpubReaderViewController" bundle:nil];
        //  bvc.setting = [DELEGATE fetchSetting];
        bvc.bookInformation = [DELEGATE fetchBookInformations:[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]] valueForKeyPath:@"details.title"]];
        bvc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:bvc animated:NO];
        
    }else{
        [DELEGATE setDelgate:self];
        [DELEGATE downloadBookwithUrl:[[NSString stringWithFormat:@"%@",[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[book valueForKey:@"bookUrl"]]] valueForKeyPath:@"details.ePub"]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    }
    
    
    
}
-(void)downloadprogress:(float)value forURL:(NSString *)url{
    
    
}
-(void)DownloadCompletedforURL:(NSString *)url{
   

        EpubReaderViewController *bvc = [[EpubReaderViewController alloc]initWithNibName:@"EpubReaderViewController" bundle:nil];
        //  bvc.setting = [DELEGATE fetchSetting];
        bvc.bookInformation = [DELEGATE fetchBookInformations:[[bookdetaildict valueForKey:[NSString stringWithFormat:@"%@",[[_booksarray objectAtIndex:_swipeview.currentItemIndex ] valueForKey:@"bookUrl"]]] valueForKeyPath:@"details.title"]];
        bvc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:bvc animated:NO];
        
   
}

-(void)removeAdtap:(UIButton *)sender{
    SettingsViewController *gosetting = [[SettingsViewController alloc]initWithNibName:@"SettingsViewController" bundle:nil];
    [self.navigationController pushViewController:gosetting animated:YES];

}
- (NSString *)stripTags:(NSString *)str
{
    NSMutableString *html = [NSMutableString stringWithCapacity:[str length]];
    
    NSScanner *scanner = [NSScanner scannerWithString:str];
    scanner.charactersToBeSkipped = NULL;
    NSString *tempText = nil;
    [scanner setCharactersToBeSkipped:nil];
    while (![scanner isAtEnd])
    {
        [scanner scanUpToString:@"<" intoString:&tempText];
        
        if (tempText != nil)
            [html appendString:tempText];
        
        [scanner scanUpToString:@">" intoString:NULL];
        
        if (![scanner isAtEnd])
            [scanner setScanLocation:[scanner scanLocation] + 1];
        
        tempText = nil;
    }
    
    return html;
}
- (IBAction)goNowPlaying:(id)sender {
    MyBookDetailViewController *godetail = [[MyBookDetailViewController alloc]initWithNibName:@"MyBookDetailViewController" bundle:nil];
    godetail.myBookDict = DELEGATE.playDict;
    FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
    item.title = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"title"];
    item.url = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"file"];
    item.number = DELEGATE.playingIndex;
    godetail.selectedPlaylistItem = item;
    godetail.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:godetail animated:YES];
}
@end
