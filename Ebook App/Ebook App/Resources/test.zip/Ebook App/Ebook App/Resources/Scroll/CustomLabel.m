//
//  CustomLabel.m
//  Ebook App
//
//  Created by macmini3 on 06/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "CustomLabel.h"

@implementation CustomLabel

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (void)drawTextInRect:(CGRect)rect {
    UIEdgeInsets insets = {0, 10, 0, 10};
    [[self layer]setCornerRadius:8];
    [super drawTextInRect:UIEdgeInsetsInsetRect(rect, insets)];
    
   
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
