//
//  BookItemFeatured.h
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomLabel.h"
#import "TQStarRatingView.h"

@protocol BookDelegate <NSObject>
@optional
-(void)didTouchBook:(NSMutableDictionary *)book;
-(void)didTouchAddBook:(NSMutableDictionary *)book;
-(void)didTouchRemovebook:(NSMutableDictionary *)book;
-(void)didTouchPlay:(NSMutableDictionary *)book;
-(void)didTouchAddRead:(NSMutableDictionary *)book;

@end


@interface BookCommon : UIView


@property(nonatomic,weak) id<BookDelegate>delgate;
@property (weak, nonatomic) IBOutlet UIImageView *imgview_book;
@property (weak, nonatomic) IBOutlet CustomLabel *lbl_genre;
@property (retain, nonatomic) NSMutableDictionary *Bookdatails;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UILabel *lbl_author;
@property (weak, nonatomic) IBOutlet UILabel *lbl_reviewcount;
@property (weak, nonatomic) IBOutlet UIButton *btn_addmybook;
@property (weak, nonatomic) IBOutlet UIButton *btn_play;
@property (weak, nonatomic) IBOutlet UIButton *btn_read;

- (IBAction)AddMyBook:(id)sender;
- (IBAction)Play:(id)sender;
- (IBAction)Read:(id)sender;


-(void)PopulateResult:(NSMutableDictionary *)dict showstar:(BOOL)showrating;

@end



