//
//  MyBookDetailViewController.h
//  Ebook App
//
//  Created by macmini3 on 23/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFDownloadRequestOperation.h"
#import <MediaPlayer/MediaPlayer.h>
#import "FSAudioStream.h"
#import "FSAudioController.h"
#import "AJNotificationView.h"
#import "MyBookChapterCell.h"
#import "SleepTimerTableViewCell.h"
#import "EpubReaderViewController.h"
#import "GADBannerView.h"

@interface MyBookDetailViewController : UIViewController<DownloadDelegate, UITableViewDataSource, UITableViewDelegate>{

    UIActivityIndicatorView *act;
    UISlider *sli_volume;
    FSPlaylistItem *_selectedPlaylistItem;
    
    //Streaming
    // State
    BOOL _paused;
    NSTimer *_progressUpdateTimer;
    NSTimer *_playbackSeekTimer;
   
    GADBannerView *admobBannerView;
    
}

@property(retain, nonatomic) NSMutableDictionary *myBookDict;
@property (weak, nonatomic) IBOutlet UIImageView *img_book;
- (IBAction)goReadfullText:(id)sender;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;
@property (weak, nonatomic) IBOutlet UISlider *sli_progress;
- (IBAction)progressUpdate:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_chapter;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;

- (IBAction)goRemoveAds:(id)sender;
- (IBAction)goSleepTimer:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *speedbtn;
- (IBAction)SpeedChange:(id)sender;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
- (IBAction)goback:(id)sender;
- (IBAction)goShare:(id)sender;
- (IBAction)goChapter:(id)sender;
- (IBAction)selectSegment:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_righttime;
@property (weak, nonatomic) IBOutlet UILabel *lbl_lefttime;
@property (weak, nonatomic) IBOutlet MPVolumeView *volumeview;
@property (weak, nonatomic) IBOutlet UIButton *btn_play;
@property (weak, nonatomic) IBOutlet UIButton *btn_pause;
- (IBAction)goPlay:(id)sender;
- (IBAction)goPause:(id)sender;


@property (nonatomic,assign) BOOL shouldStartPlaying;
@property (nonatomic,strong) FSPlaylistItem *selectedPlaylistItem;
- (IBAction)goNext:(id)sender;
- (IBAction)goPrevious:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_next;
@property (weak, nonatomic) IBOutlet UIButton *btn_previous;
@property (weak, nonatomic) IBOutlet UITableView *tableview_chapters;
- (IBAction)goDoneChap:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *view_chapters;
- (IBAction)goDoneSleep:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tableview_sleep;
@property (weak, nonatomic) IBOutlet UIView *view_sleep;
@property (weak, nonatomic) IBOutlet UIButton *btn_sleep;
@property (weak, nonatomic) IBOutlet UIButton *btn_backward;
- (IBAction)goBackWard:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_forward;
- (IBAction)goForward:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_readtext;

@property (nonatomic,strong) UIPopoverController *popover;
@property (retain, nonatomic)  UIViewController* popoverContent ;

@property (nonatomic,strong) UIPopoverController *popover1;
@property (retain, nonatomic)  UIViewController* popoverContent1 ;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *waitingindicator;
@end
