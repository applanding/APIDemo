//
//  GenreShowcaseViewController.h
//  Ebook App
//
//  Created by macmini3 on 08/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface GenreShowcaseViewController : UIViewController<BookDelegate>{

    
        NSMutableArray *resultArr;
        GADBannerView *admobBannerView;
    
}
@property (assign, nonatomic) bool is_language;
@property (retain, nonatomic) NSString *genreUrl;
@property (retain, nonatomic) NSString *languageUrl;
@property (retain, nonatomic) NSString *genreTitle;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
- (IBAction)goBack:(id)sender;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;

@property (weak, nonatomic) IBOutlet UIButton *btn_back;
@property (retain, nonatomic) NSString *backbtntitle;
@property (weak, nonatomic) IBOutlet UIButton *btn_nowplaying;
- (IBAction)goNowPlaying:(id)sender;
@end
