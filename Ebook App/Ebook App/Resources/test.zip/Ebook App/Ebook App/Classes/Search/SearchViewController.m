//
//  SearchViewController.m
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "SearchViewController.h"

@interface SearchViewController ()

@end

@implementation SearchViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[UITextField appearanceWhenContainedIn:[UISearchBar class], nil] setTextColor:[UIColor whiteColor]];
    [[UILabel appearanceWhenContainedIn:[UISearchBar class], nil] setTextColor:[UIColor whiteColor]];
    [_txt_search setImage:[UIImage imageNamed:@"searchbarsearch"] forSearchBarIcon:UISearchBarIconSearch state:UIControlStateNormal];
     [_txt_search setImage:[UIImage imageNamed:@"searcbarcross"] forSearchBarIcon:UISearchBarIconClear state:UIControlStateNormal];
    
    resultArr = [[NSMutableArray alloc]init];
    if (!DELEGATE.RemoveAllAds) {
       [self setupTableViewFooter];
    }
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    _tableview.hidden = YES;
    _collectionview.hidden = YES;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didTouchView:)];
    [self.view addGestureRecognizer:tap];
    
    
    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapOnTableView:)];
    [_tableview addGestureRecognizer:tap2];
    
    
    UITapGestureRecognizer *tap3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapOnCollection:)];
    [_collectionview addGestureRecognizer:tap3];
    
    
    [_collectionview registerNib:[UINib nibWithNibName:NSStringFromClass([AllBookCollectiionViewCell class]) bundle:nil]
      forCellWithReuseIdentifier:NSStringFromClass([AllBookCollectiionViewCell class])];
     [_collectionview registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"header"];
    
    // Do any additional setup after loading the view from its nib.
}
-(void)didTouchView:(UITapGestureRecognizer *)tap{
    [self.view endEditing:YES];
}
- (void)setupTableViewFooter
{
    // set up label
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 70)];
    footerView.backgroundColor = [UIColor whiteColor];
    
    UIImageView *img2 = [[UIImageView alloc]initWithFrame:CGRectMake(15, 0, 320, 1)];
    [img2 setImage:[UIImage imageNamed:@"seprator"]];
    [footerView addSubview:img2];
    
    
    UIButton *button =[UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(80, 2,160, 18);
    [button.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
    [button setTitle:@"Remove Ads" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(removeAdtap:) forControlEvents:UIControlEventTouchUpInside];
    [footerView addSubview:button];
    
    admobBannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeSmartBannerPortrait] ;
    [admobBannerView setFrame:CGRectMake(admobBannerView.frame.origin.x, 20, admobBannerView.frame.size.width, admobBannerView.frame.size.height)];
    admobBannerView.adUnitID = AdMob_ID_Search;
    admobBannerView.rootViewController = self;
    [footerView addSubview:admobBannerView];
    [admobBannerView loadRequest:[GADRequest request]];
    
   
       
    _tableview.tableFooterView = footerView;
}
-(void)removeAdtap:(UIButton *)sender{
    SettingsViewController *gosetting = [[SettingsViewController alloc]initWithNibName:@"SettingsViewController" bundle:nil];
    [self.navigationController pushViewController:gosetting animated:YES];
    
}
-(void)viewWillAppear:(BOOL)animated{
    if (DELEGATE.RemoveAllAds) {
    [_tableview.tableFooterView removeFromSuperview];
    }
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
    [resultArr removeAllObjects];
    ModelClass *mc = [[ModelClass alloc]init];
    [mc Getsearchresultfor:[NSString stringWithFormat:@"%@",_txt_search.text] success:^(id result) {
          if ([[result valueForKey:@"search"] isKindOfClass:[NSArray class]]) {
        [resultArr addObjectsFromArray:[result valueForKey:@"search"]];
        }
         _tableview.hidden = NO;
        _collectionview.hidden = NO;
         [_tableview reloadData];
        [_collectionview reloadData];
        
    } error:^(NSError *error) {
      //  NSLog(@"-->%@",error.description);
        
        
    }];
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if ([searchText length] == 0) {
        [resultArr removeAllObjects];
        [_tableview reloadData];
        [_collectionview reloadData];
        _tableview.hidden = YES;
        _collectionview.hidden = YES;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (DELEGATE.RemoveAllAds) {
        return 0;
    }
    return 0;
}
-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    if ([resultArr count] !=0) {
    return [resultArr count];
    }
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([resultArr count] !=0) {
        return 125;
    }
    return 44;
}
-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([resultArr count] !=0) {
    static NSString *CellIdentifier = @"AllBookTableViewCell";
    AllBookTableViewCell *cell = (AllBookTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell= (AllBookTableViewCell *)[arrNib objectAtIndex:0];
        //cell.backgroundColor =[UIColor clearColor];
        
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    [cell populateResult:[resultArr objectAtIndex:indexPath.row]];
    return cell;
    }else{
        static NSString *CellIdentifier = @"Cell";
        // add a placeholder cell while waiting on table data
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] ;
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.text = @"No Results";
        return cell;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
   
    
    
}
-(void) didTapOnTableView:(UIGestureRecognizer*) recognizer {
    [self.view endEditing:YES];
    CGPoint tapLocation = [recognizer locationInView:_tableview];
    NSIndexPath *indexPath = [_tableview indexPathForRowAtPoint:tapLocation];
    
    if (indexPath) { //we are in a tableview cell, let the gesture be handled by the view
        recognizer.cancelsTouchesInView = NO;
        if ([resultArr count] !=0) {
            BookDetailViewController *detail = [[BookDetailViewController alloc]initWithNibName:@"BookDetailViewController" bundle:nil];
            detail.booksarray = [NSMutableArray arrayWithArray:resultArr];
            detail.pageindex = indexPath.row;
            detail.backbtntitle = @"Search";
            [self.navigationController pushViewController:detail animated:YES];
            
        }
    } else { // anywhere else, do what is needed for your case
       // [self.navigationController popViewControllerAnimated:YES];
        
    }
}
-(void) didTapOnCollection:(UIGestureRecognizer*) recognizer {
    [self.view endEditing:YES];
    CGPoint tapLocation = [recognizer locationInView:_collectionview];
    NSIndexPath *indexPath = [_collectionview indexPathForItemAtPoint:tapLocation];
    
    if (indexPath) { //we are in a tableview cell, let the gesture be handled by the view
        recognizer.cancelsTouchesInView = NO;
        
            BookDetailViewController *detail = [[BookDetailViewController alloc]initWithNibName:@"BookDetailViewController" bundle:nil];
            detail.booksarray = [NSMutableArray arrayWithArray:resultArr];
            detail.pageindex = indexPath.row;
            detail.backbtntitle = @"Search";
            [self addChildViewController: detail];
            [self.view addSubview: detail.view];
            
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(removeChild:)];
            [detail.tapableview addGestureRecognizer:tap];
        
    } else { // anywhere else, do what is needed for your case
        // [self.navigationController popViewControllerAnimated:YES];
        
    }
}
-(void)removeChild:(UITapGestureRecognizer *)sender{
    UIViewController *vc = [self.childViewControllers lastObject];
    [vc willMoveToParentViewController:nil];
    [vc.view removeFromSuperview];
    [vc removeFromParentViewController];
    
}

#pragma mark - UICollectionView Datasource
// 1
- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section {
    
        return [resultArr count];
   
}
// 2
- (NSInteger)numberOfSectionsInCollectionView: (UICollectionView *)collectionView {
    return 1;
}
// 3
- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
    AllBookCollectiionViewCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"AllBookCollectiionViewCell" forIndexPath:indexPath];
    cell.layer.shouldRasterize = YES;
    cell.layer.rasterizationScale = [UIScreen mainScreen].scale;
    [cell populateResult:[resultArr objectAtIndex:indexPath.row]];
    
    return cell;
    
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
        
    
}
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *reusableview = nil;
    
    if (kind == UICollectionElementKindSectionFooter) {
        reusableview = [_collectionview dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"header" forIndexPath:indexPath];
        
        if (reusableview==nil) {
            reusableview=[[UICollectionReusableView alloc] initWithFrame:CGRectMake(0, 0, _collectionview.frame.size.width, 110)];
        }
        
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _collectionview.frame.size.width, 110)];
        footerView.backgroundColor = [UIColor whiteColor];
        
        UIImageView *img2 = [[UIImageView alloc]initWithFrame:CGRectMake(15, 0, _collectionview.frame.size.width, 1)];
        [img2 setImage:[UIImage imageNamed:@"seprator"]];
        [footerView addSubview:img2];
        
        
        UIButton *button =[UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(304, 2,160, 18);
        [button.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
        [button setTitle:@"Remove Ads" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(removeAdtap:) forControlEvents:UIControlEventTouchUpInside];
        [footerView addSubview:button];
        
        admobBannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeSmartBannerPortrait] ;
        [admobBannerView setFrame:CGRectMake(admobBannerView.frame.origin.x, 20, admobBannerView.frame.size.width, admobBannerView.frame.size.height)];
        admobBannerView.adUnitID = AdMob_ID_Search;
        admobBannerView.rootViewController = self;
        [footerView addSubview:admobBannerView];
        [admobBannerView loadRequest:[GADRequest request]];
        
        
        [reusableview addSubview:footerView];
    }
    return reusableview;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
