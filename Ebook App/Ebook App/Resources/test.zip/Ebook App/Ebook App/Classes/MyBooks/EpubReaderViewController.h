//
//  EpubReaderViewController.h
//  Ebook App
//
//  Created by macmini3 on 04/10/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ReflowableViewController.h"
#import "BookInformation.h"
#import "ReaderSearchCell.h"

@class ArrowView;
@class Setting;
@interface EpubReaderViewController : UIViewController<ReflowableViewControllerDataSource,ReflowableViewControllerDelegate,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UITextViewDelegate,UISearchBarDelegate>{
    ReflowableViewController *rv;
    
    BOOL isDoublePaged;
   
    UIView *piBox;
    ArrowView* piArrow;
    UILabel* piLabel;
    
    NSMutableArray* bookmarks;
    NSMutableArray* searchResults;
    int lastNumberOfSearched;
   
    NSMutableArray* highlightsInPage;
    NSMutableArray* highlights;
     Highlight* currentHighlight;
    
    NSMutableArray *fontsArr;
    int fontsize;
}
@property (nonatomic, retain) BookInformation* bookInformation;
//@property (nonatomic, retain) Setting* setting;
@property BOOL isRTL;
- (IBAction)goBack:(id)sender;
- (IBAction)fontChange:(id)sender;
- (IBAction)goSearch:(id)sender;
@property (weak, nonatomic) IBOutlet UISlider *sli_pages;
@property (weak, nonatomic) IBOutlet UILabel *lbl_pages;
@property (weak, nonatomic) IBOutlet UILabel *lbl_pagesleft;
- (IBAction)sliderDragStarted:(id)sender;
- (IBAction)sliderValueChanged:(id)sender;
- (IBAction)sliderDragEnded:(id)sender;
- (IBAction)hitBookmark:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_bookmark;
@property (weak, nonatomic) IBOutlet UISearchBar *txt_search;
@property (weak, nonatomic) IBOutlet UIView *view_search;
@property (weak, nonatomic) IBOutlet UITableView *table_search;
@property (weak, nonatomic) IBOutlet UITableView *table_font;
@property (weak, nonatomic) IBOutlet UIView *view_font;
@property (weak, nonatomic) IBOutlet UISlider *sli_brightness;
- (IBAction)change_brightness:(id)sender;
- (IBAction)decreaseFontSize:(id)sender;
- (IBAction)increaseFontSize:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_fontname;
- (IBAction)goWhile:(id)sender;
- (IBAction)goSepia:(id)sender;
- (IBAction)goNight:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *view_fonttable;
- (IBAction)goCancelFont:(id)sender;
- (IBAction)changeFont:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_whitecolor;
@property (weak, nonatomic) IBOutlet UIButton *btn_sepiacolor;
@property (weak, nonatomic) IBOutlet UIButton *btn_nightcolor;
- (IBAction)goList:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *table_chapterbookmark;
- (IBAction)chapterORbookmark:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *view_chapterlist;
@property (weak, nonatomic) IBOutlet UISegmentedControl *seg_chpbmark;
@property (weak, nonatomic) IBOutlet UIView *bgview;


@end
