//
//  SettingsViewController.m
//  Ebook App
//
//  Created by macmini3 on 23/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "SettingsViewController.h"

@interface SettingsViewController ()

@end

@implementation SettingsViewController
#define feedback_email @"ios-app@loyalbooks.com"
#define feedback_subject @"Comment"
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    [DELEGATE.inApp setDeleget:self];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    if (!DELEGATE.playDict) {
        _btn_nowplaying.hidden = YES;
    }else{
        _btn_nowplaying.hidden = NO;
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 4;
}
-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 2;
            break;
            case 3:
            return 2;
            break;
        default:
            return 1;
            break;
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case 0:
            switch (indexPath.row) {
                case 0:
                    if (IPHONE) {
                       return 74;
                    }
                    return 60;
                    break;
                default:
                    return 60;
                    break;
            }
            break;
        case 3:
            return 60;
            break;
        default:
            return 44;
            break;
    }

}
-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
        static NSString *CellIdentifier = @"Cell";
        // add a placeholder cell while waiting on table data
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] ;
        }
        cell.selectionStyle=UITableViewCellSelectionStyleGray;
    
    switch (indexPath.section) {
        case 0:{
            UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, 240,30 )];
            if (!IPHONE) {
                [title setFrame:CGRectMake(title.frame.origin.x,6, title.frame.size.width, title.frame.size.height)];
            }
            title.textColor = [UIColor blackColor];
            title.backgroundColor=[UIColor clearColor];
            [title setFont:[UIFont systemFontOfSize:16]];
            title.numberOfLines = 0;
            
            UILabel *desc = [[UILabel alloc] initWithFrame:CGRectMake(15, 30, _tableview.frame.size.width - 100,40 )];
            if (!IPHONE) {
                [desc setFrame:CGRectMake(desc.frame.origin.x,26, desc.frame.size.width, desc.frame.size.height-15)];
            }
            desc.textColor = [UIColor blackColor];
            desc.backgroundColor=[UIColor clearColor];
            [desc setFont:[UIFont systemFontOfSize:11]];
            desc.numberOfLines = 0;
            
            UILabel *price = [[UILabel alloc] initWithFrame:CGRectMake(_tableview.frame.size.width - 70, 25,55,25 )];
            if (!IPHONE) {
                [price setFrame:CGRectMake(price.frame.origin.x,16, price.frame.size.width, price.frame.size.height)];
            }
            price.textColor = [UIColor colorWithRed:0.0 green:122.0/255.0 blue:1.0 alpha:1.0];
            price.backgroundColor=[UIColor clearColor];
            [price setFont:[UIFont boldSystemFontOfSize:13]];
            price.textAlignment = NSTextAlignmentCenter;
            price.layer.borderWidth = 1.0;
            price.layer.borderColor = price.textColor.CGColor;
            price.layer.cornerRadius = 3.0;
            
            switch (indexPath.row) {
                case 0:
                    title.text= @"Remove All Banner Ads";
                    desc.text=@"Enjoy browsing and listening without banner ads";
                    [price setText:@"$2.99"];
                    for (int i =0 ; i < [DELEGATE.inApp.products count]; i++) {
                        if ([[[DELEGATE.inApp.products objectAtIndex:i]productIdentifier]isEqualToString:RemoveALLAds]) {
                            SKProduct *product =  [DELEGATE.inApp.products objectAtIndex:i];
                            NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
                            [numberFormatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
                            [numberFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
                            [numberFormatter setLocale:product.priceLocale];
                            NSString *formattedString = [numberFormatter stringFromNumber:product.price];
                            [price setText:formattedString];
                            break;
                        }
                    }
                    if(DELEGATE.RemoveAllAds){
                        cell.userInteractionEnabled = NO;
                        price.hidden = YES;
                    }
                    break;
                case 1:
                    [title setFrame:CGRectMake(15, 6, 240,30 )];
                    title.text= @"Remove Playback Banner Ads";
                    [desc setFrame:CGRectMake(15, 26, _tableview.frame.size.width - 90,25 )];
                    desc.text=@"Enjoy listening without banner ads";
                     [price setFrame:CGRectMake(_tableview.frame.size.width-70, 16,55,25 )];
                    [price setText:@"$0.99"];
                    for (int i =0 ; i < [DELEGATE.inApp.products count]; i++) {
                        if ([[[DELEGATE.inApp.products objectAtIndex:i]productIdentifier]isEqualToString:RemovePLAYBACKAds]) {
                            SKProduct *product =  [DELEGATE.inApp.products objectAtIndex:i];
                            NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
                            [numberFormatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
                            [numberFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
                            [numberFormatter setLocale:product.priceLocale];
                            NSString *formattedString = [numberFormatter stringFromNumber:product.price];
                            [price setText:formattedString];
                            
                            
                            break;
                        }
                    }
                    if(DELEGATE.RemoveAllAds || DELEGATE.RemovePlaybackAds){
                        cell.userInteractionEnabled = NO;
                        price.hidden = YES;
                    }

                    break;
                default:
                    break;
            }
            [cell.contentView addSubview:title];
            [cell.contentView addSubview:desc];
            [cell.contentView addSubview:price];
            break;
        }
        case 1:{
            UILabel *centerlbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _tableview.frame.size.width,44 )];
            centerlbl.textColor = [UIColor colorWithRed:0.0 green:122.0/255.0 blue:1.0 alpha:1.0];
            centerlbl.backgroundColor=[UIColor clearColor];
            [centerlbl setFont:[UIFont systemFontOfSize:16]];
            centerlbl.textAlignment = NSTextAlignmentCenter;
            [centerlbl setText:@"Restore Purchases"];
            [cell.contentView addSubview:centerlbl];
            
            if (DELEGATE.RemoveAllAds && DELEGATE.RemovePlaybackAds) {
                cell.userInteractionEnabled = NO;
            }

            break;
        }
        case 2:{
            UILabel *centerlbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _tableview.frame.size.width,44 )];
            centerlbl.textColor = [UIColor colorWithRed:0.0 green:122.0/255.0 blue:1.0 alpha:1.0];
            centerlbl.backgroundColor=[UIColor clearColor];
            [centerlbl setFont:[UIFont systemFontOfSize:16]];
            centerlbl.textAlignment = NSTextAlignmentCenter;
            [centerlbl setText:@"Manage My Books"];
            [cell.contentView addSubview:centerlbl];
        }
            break;
        case 3:{
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            
            UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(15, 6, 240,30 )];
            title.textColor = [UIColor blackColor];
            title.backgroundColor=[UIColor clearColor];
            [title setFont:[UIFont systemFontOfSize:16]];
            title.numberOfLines = 0;
            
            UILabel *desc = [[UILabel alloc] initWithFrame:CGRectMake(15, 26, 220,25 )];
            desc.textColor = [UIColor blackColor];
            desc.backgroundColor=[UIColor clearColor];
            [desc setFont:[UIFont systemFontOfSize:11]];
            desc.numberOfLines = 0;
            
            
            switch (indexPath.row) {
                case 0:
                    title.text= @"Send Feedback";
                    desc.text=@"Please let us know what can be improved";
                    break;
                case 1:
                    title.text= @"Rate App";
                    desc.text=@"We hope you enjoy the free books!";
                    break;
                default:
                    break;
            }
            [cell.contentView addSubview:title];
            [cell.contentView addSubview:desc];
            break;
        }
        default:
            
            break;
    }
    
    
    
    
        return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.section) {
        case 0:{
            
            
            switch (indexPath.row) {
                case 0:
                    [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
                    for (int i =0 ; i < [DELEGATE.inApp.products count]; i++) {
                        if ([[[DELEGATE.inApp.products objectAtIndex:i]productIdentifier]isEqualToString:RemoveALLAds]) {
                            SKProduct *product =  [DELEGATE.inApp.products objectAtIndex:i];
                            [DELEGATE.inApp buyProductIdentifier:product];
                            break;
                        }
                    }
                    break;
                case 1:
                    [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
                    [self performSelector:@selector(hideindicator) withObject:nil afterDelay:120];
                    for (int i =0 ; i < [DELEGATE.inApp.products count]; i++) {
                        if ([[[DELEGATE.inApp.products objectAtIndex:i]productIdentifier]isEqualToString:RemovePLAYBACKAds]) {
                            SKProduct *product =  [DELEGATE.inApp.products objectAtIndex:i];
                            [DELEGATE.inApp buyProductIdentifier:product];
                            break;
                        }
                    }
                    break;
                default:
                    break;
            }
          
            break;
        }
        case 1:{
             [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
            [DELEGATE.inApp restoreAllTransactions];
            
            break;
        }
        case 2:{
            MyBooksViewController *gomybook = [[MyBooksViewController alloc]initWithNibName:@"MyBooksViewController" bundle:nil];
            gomybook.is_edit = YES;
            [self.navigationController pushViewController:gomybook animated:YES];
        }
            break;
        case 3:{
            
            
            switch (indexPath.row) {
                case 0:{
                    Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
                    if (mailClass != nil)
                    {
                        // We must always check whether the current device is configured for sending emails
                        if ([mailClass canSendMail])
                        {
                            [self displayComposerSheet];
                        }
                        else
                        {
                            [self launchMailAppOnDevice];
                        }
                    }
                    else
                    {
                        [self launchMailAppOnDevice];
                    }
            
                    break;
                }
                case 1:
                    [[iRate sharedInstance]promptForRating];
                    break;
                default:
                    break;
            }
            break;
        }
        default:
            
            break;
    }

    
}
- (void)productsRequestdelegete:(NSArray*)product{
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    for (NSString *product in DELEGATE.inApp.purchasedProducts){
        if ([product isEqualToString:RemoveALLAds]) {
            DELEGATE.RemoveAllAds = YES;
            DELEGATE.RemovePlaybackAds = YES;
        }
        if ([product isEqualToString:RemovePLAYBACKAds]) {
            DELEGATE.RemovePlaybackAds = YES;
        }
    }
    [_tableview reloadData];
    
 //   NSLog(@"-->%@  %@", _inApp.productIdentifiers ,_inApp.purchasedProducts);
    
    
}
-(void)hideindicator{
    [MBProgressHUD hideHUDForView:self.navigationController.view animated:YES];
}
- (void)provideContentdelegete:(NSString *)productIdentifier{
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [MBProgressHUD hideHUDForView:self.navigationController.view animated:YES];
    
    //  NSString *productIdentifier = (NSString *) notification.object;
    //  NSLog(@"Purchased: %@", productIdentifier);
    
    
}
- (void)failedTransactiondelegete:(SKPaymentTransaction *)transaction{
    NSLog(@"productPurchaseFailed");
    [MBProgressHUD hideHUDForView:self.navigationController.view animated:YES];
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    
    
    if (transaction) {
        
    
    if (transaction.error.code != SKErrorPaymentCancelled) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!"
                                                         message:transaction.error.localizedDescription
                                                        delegate:nil
                                               cancelButtonTitle:nil
                                               otherButtonTitles:@"OK", nil] ;
        
        [alert show];
    }
    }
}
- (void)completeTransaction:(SKPaymentTransaction *)transaction{
    
    //    NSLog(@"Source_transaction_id %@", transaction.transactionIdentifier);
    //    NSLog(@"source_product_id %@", transaction.payment.productIdentifier);
    //    NSLog(@"amount_type %@",[[NSLocale currentLocale] objectForKey:NSLocaleCurrencySymbol]);
    //    NSLog(@"amount %@", amount);
    //    NSLog(@"amount %@", coin);
    //    NSLog(@"amount %@", coinid);
    
    for (NSString *product in DELEGATE.inApp.purchasedProducts){
        if ([product isEqualToString:RemoveALLAds]) {
            DELEGATE.RemoveAllAds = YES;
            DELEGATE.RemovePlaybackAds = YES;
        }
        if ([product isEqualToString:RemovePLAYBACKAds]) {
            DELEGATE.RemovePlaybackAds = YES;
        }
    }
    
    [_tableview reloadData];
    
    
}
-(void)displayComposerSheet
{
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    picker.mailComposeDelegate = self;
    
    [picker setSubject:feedback_subject];
    
    
    // Set up recipients
    NSArray *toRecipients = [NSArray arrayWithObject:[NSString stringWithFormat:@"%@",feedback_email]];
    //    NSArray *ccRecipients = [NSArray arrayWithObjects:@"second@example.com", @"third@example.com", nil];
    //    NSArray *bccRecipients = [NSArray arrayWithObject:@"fourth@example.com"];
    
    [picker setToRecipients:toRecipients];
    //    [picker setCcRecipients:ccRecipients];
    //    [picker setBccRecipients:bccRecipients];
    
    // Attach an image to the email
    // NSString *path = [[NSBundle mainBundle] pathForResource:@"rainy" ofType:@"png"];
    // NSData *myData = [NSData dataWithContentsOfFile:path];
    // [picker addAttachmentData:myData mimeType:@"image/png" fileName:@"rainy"];
    
    // Fill out the email body text
    NSString *emailBody = [NSString stringWithFormat:@"%@",@""];
    [picker setMessageBody:emailBody isHTML:YES];
    
    [self presentViewController:picker animated:YES completion:nil];
   
}
// Dismisses the email composition interface when users tap Cancel or Send. Proceeds to update the message field with the result of the operation.
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    
    // Notifies users about errors associated with the interface
    switch (result)
    {
        case MFMailComposeResultCancelled:
            break;
        case MFMailComposeResultSaved:
            
            break;
        case MFMailComposeResultSent:
            [[[UIAlertView alloc] initWithTitle:@"" message:@"Mail sent successfully." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
            break;
        case MFMailComposeResultFailed:
            
            break;
        default:
            
            break;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Launches the Mail application on the device.
-(void)launchMailAppOnDevice
{
    NSString *recipients =[NSString stringWithFormat:@"mailto:%@&subject=%@",feedback_email,feedback_subject];
    NSString *body = [NSString stringWithFormat:@"&body=%@",@""];
    
    NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
    email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)goDone:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)goNowPlaying:(id)sender {
    MyBookDetailViewController *godetail = [[MyBookDetailViewController alloc]initWithNibName:@"MyBookDetailViewController" bundle:nil];
    godetail.myBookDict = DELEGATE.playDict;
    FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
    item.title = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"title"];
    item.url = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"file"];
    item.number = DELEGATE.playingIndex;
    godetail.selectedPlaylistItem = item;
    godetail.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:godetail animated:YES];
}
@end
