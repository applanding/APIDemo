//
//  ReviewTableViewCell.m
//  Ebook App
//
//  Created by macmini3 on 17/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "ReviewTableViewCell.h"

@implementation ReviewTableViewCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)populateResult:(NSMutableDictionary *)dict{
    
    if(dict){
        
        if (![[dict valueForKey:@"title"]isEqual:[NSNull null]]) {
            _lbl_title.text = [NSString stringWithFormat:@"%ld. %@",(long)self.tag,[dict valueForKey:@"title"]];
        }else{
            _lbl_title.text = [NSString stringWithFormat:@"%ld. %@",(long)self.tag,@""];

        }
       
        
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:[[dict valueForKey:@"time"]intValue]];
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MMM dd, yyyy"];
        
        if (![[dict valueForKey:@"reviewer"]isEqual:[NSNull null]]) {
        
            _lbl_time.text = [NSString stringWithFormat:@"by %@ - %@",[dict valueForKey:@"reviewer"],[dateFormatter stringFromDate:date]];
        }else{
            
            _lbl_time.text = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:date]];
        
        }
        if (![[dict valueForKey:@"review"]isEqual:[NSNull null]]) {
            _txt_review.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"review"]];
        }
        [_txt_review sizeToFit];
        
        if (![[dict valueForKey:@"star"]isEqual:[NSNull null]]) {
        TQStarRatingView   *starRatingView = [[TQStarRatingView alloc] initWithCustomeFrame:CGRectMake(_lbl_title.frame.origin.x, _lbl_title.frame.origin.y + _lbl_title.frame.size.height +3, 70, 14)
                                                                        numberOfStar:kNUMBER_OF_STAR];
        
        starRatingView.userInteractionEnabled = NO;
        [starRatingView setScore:[[dict valueForKey:@"star"]floatValue]/5.0 withAnimation:NO];
        [self addSubview:starRatingView];
        }else{
            [_lbl_time setFrame:CGRectMake(_lbl_title.frame.origin.x, _lbl_time.frame.origin.y, _lbl_title.frame.size.width, _lbl_time.frame.size.height)];
        }
        
        [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width,_txt_review.frame.size.height + 60)];
        
    }
}
@end
