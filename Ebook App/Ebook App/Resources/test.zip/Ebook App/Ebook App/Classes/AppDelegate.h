//
//  AppDelegate.h
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//


@protocol DownloadDelegate <NSObject>
@optional
-(void)downloadprogress:(float)value forURL:(NSString *)url;
-(void)DownloadCompletedforURL:(NSString *)url;

@end

#import <UIKit/UIKit.h>
#import "AFNetworkActivityIndicatorManager.h"
#import "MyBooksViewController.h"
#import "DiscoverViewController.h"
#import "GenresViewController.h"
#import "TopChartsViewController.h"
#import "SearchViewController.h"
#import "iRate.h"
#import "FSAudioController.h"
#import "IAPHelper.h"
#import "Flurry.h"

#import <SystemConfiguration/SystemConfiguration.h>
#import "Book.h"
#import "sqlite3.h"
#import "BookInformation.h"
#import "ZipArchive.h"
#import "FileProvider.h"
#import "Highlight.h"

#define PageTransitionNone  0
#define PageTransitionSlide 1
#define PageTransitionCurl  2

@class PageInformation;
@interface Setting : NSObject {
    int bookCode;
    NSString *fontName;
    int fontSize;
    int lineSpacing;
    int foreground;
    int background;
    int theme;
    double brightness;
    int transitionType;
    BOOL lockRotation;
    BOOL doublePaged;
    BOOL allow3G;
    BOOL globalPagination;
}
@property (nonatomic,retain) NSString* fontName;
@property int foreground;
@property int background;
@property int transitionType;
@property int bookCode,fontSize,lineSpace,theme;
@property BOOL lockRotation,doublePaged,allow3G,globalPagination;
@property double brightness;

@end

@class Highlight;
@class Setting;
@class PageInformation;
@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate>{
    
        sqlite3 *database;
    
}
@property (retain, nonatomic)  IAPHelper *inApp;
@property (assign, nonatomic) BOOL RemoveAllAds;
@property (assign, nonatomic) BOOL RemovePlaybackAds;
@property(nonatomic,weak) id<DownloadDelegate>delgate;

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, retain) UITabBarController *tabBarController;
-(void)downloadBookwithUrl:(NSString *)UrlStr;
- (NSString *)applicationDocumentsDirectory;

@property (nonatomic,strong) FSAudioController *audioController;
@property (retain, nonatomic) NSMutableDictionary *playDict;
@property (assign, nonatomic) NSInteger playingIndex;
@property (assign, nonatomic) float playingRate;
@property (assign, nonatomic) NSInteger sleepindex;
@property(retain, nonatomic) UIImage *playingImage;


//=======================//
-(NSString*)getinstalledEPubDirectory:(NSString*)fileName;
-(BOOL)installEPub:(NSString*)fileName;
-(BookInformation *)fetchBookInformations:(NSString *)title;
-(NSString*)getBooksDirectory;
//@property (nonatomic, retain) Setting* setting;
-(NSMutableArray *)fetchAllBookmarks:(int)bookCode;
-(void)toggleBookmark:(PageInformation*)pi;
-(BOOL)isBookmarked:(PageInformation*)pageInformation;
-(void)deleteBookmark:(PageInformation*)pi;

-(void)deleteHighlight:(Highlight*)highlight;
-(NSMutableArray *)fetchAllHighlights:(int)bookCode;
-(NSMutableArray *)fetchHighlights:(int)bookCode chapterIndex:(int)chapterIndex;
-(void)insertHighlight:(Highlight*)highlight;
-(void)updateHighlight:(Highlight*)highlight;
-(PagingInformation*)fetchPagingInformation:(PagingInformation*)pgi;
-(void)insertPagingInformation:(PagingInformation *)pgi;
//-(Setting*)fetchSetting;
//----------------------//







@property (retain, nonatomic) NSTimer *sleeptimer;
-(void)setSleepTime:(NSInteger)time;
-(void)invalidateTimer;
-(void)StopPlayer;
-(NSString *)getDurationForSeconds:(int)duration;
-(int)getminuteForTotalSeconds:(int)duration;
-(int)getsecondForTotalSeconds:(int)duration;
- (float)minuteToSecondConvert:(NSString *)string;
@end




