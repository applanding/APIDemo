//
//  GenreShowcaseViewController.m
//  Ebook App
//
//  Created by macmini3 on 08/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "GenreShowcaseViewController.h"

@interface GenreShowcaseViewController ()

@end

@implementation GenreShowcaseViewController
#define topheight 260
#define topsecondheight 210
#define botttomheight 210


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [_btn_back setTitle:_backbtntitle forState:UIControlStateNormal];
    _lbl_title.text = _genreTitle;
    ModelClass *mc = [[ModelClass alloc]init];
    
    
    if (_is_language == NO) {
        [mc Getgenrebooks:_genreUrl page:@"0" success:^(id result) {
            if ([[result valueForKey:@"genre"] isKindOfClass:[NSArray class]]) {
        resultArr = [[NSMutableArray alloc]initWithArray:[result valueForKey:@"genre"]];
            }
     //   NSLog(@"-->%@",resultArr);
        
        for (int i = 0; i < [resultArr count] ; i++) {
            
            switch (i) {
                case 0:
                    [self setupFetured:[resultArr objectAtIndex:i] yaxis:0 tag:i];
                    [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, topheight+85)];
                    break;
                    
                case 1:
                    [self setupSecondTop:[resultArr objectAtIndex:i] yaxis:(i*(topheight+35)) tag:i];
                    [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, (i*(topheight+35))+topheight+35)];
                    break;
                    
                default:
                    [self setupNormal:[resultArr objectAtIndex:i] yaxis:((i-2)*(botttomheight+35)+(topheight + topsecondheight+70)) tag:i];
                    [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, ((i-2)*(botttomheight+35)+(topheight + topsecondheight+70))+botttomheight+85)];
                    break;
            }
        }
            if (!DELEGATE.RemoveAllAds) {
                
                [self setupAds];
            }
            
            
    } error:^(NSError *error) {
      //  NSLog(@"-->%@",error.description);
        
        
    }];
    }else{
        [mc Getbooksforlanguage:_languageUrl page:@"0" success:^(id result) {
            if ([[result valueForKey:@"language"] isKindOfClass:[NSArray class]]) {
            resultArr = [[NSMutableArray alloc]initWithArray:[result valueForKey:@"language"]];
            }
           //  NSLog(@"-->%@",resultArr);
            for (int i = 0; i < [resultArr count] ; i++) {
                
                switch (i) {
                    case 0:
                       [self setupFetured:[resultArr objectAtIndex:i] yaxis:0 tag:i];
                        [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, topheight+85)];
                        break;
                        
                    case 1:
                        [self setupSecondTop:[resultArr objectAtIndex:i] yaxis:(i*(topheight+35)) tag:i];
                        [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, (i*(topheight+35))+topheight+35)];
                        break;
                        
                    default:
                        [self setupNormal:[resultArr objectAtIndex:i] yaxis:((i-2)*(botttomheight+35)+(topheight + topsecondheight+70)) tag:i];
                        [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, ((i-2)*(botttomheight+35)+(topheight + topsecondheight+70))+botttomheight+85)];
                        break;
                }
            }
            if (!DELEGATE.RemoveAllAds) {
                
                [self setupAds];
            }
        } error:^(NSError *error) {
          //  NSLog(@"-->%@",error.description);
            
            
        }];
    
    }
    
    
    
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    if (!DELEGATE.playDict) {
        _btn_nowplaying.hidden = YES;
    }else{
        _btn_nowplaying.hidden = NO;
    }
    
    if (DELEGATE.RemoveAllAds) {
        for (UIView *view in _scrollview.subviews) {
            if ([view isKindOfClass:[UIView class]]){
                if ([view.accessibilityIdentifier isEqualToString:@"ads"]) {
                    [view removeFromSuperview];
                }
            }
        }
    }
}

-(void)setupAds{

    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, _scrollview.contentSize.height-50, _scrollview.frame.size.width, 70)];
    footerView.backgroundColor = [UIColor whiteColor];
     footerView.accessibilityIdentifier = @"ads";
    
    UIButton *button =[UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(80, 2,160, 18);
    [button setCenter:CGPointMake(footerView.frame.size.width/2, button.center.y)];
    [button.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
    [button setTitle:@"Remove Ads" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(removeAdtap:) forControlEvents:UIControlEventTouchUpInside];
    [footerView addSubview:button];
    
    UIImageView *img2 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, footerView.frame.size.width, 1)];
    [img2 setImage:[UIImage imageNamed:@"seprator"]];
    [footerView addSubview:img2];
    
//    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 20, 320, 50)];
//    [img setImage:[UIImage imageNamed:@"banner"]];
//    [footerView addSubview:img];
    
    admobBannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeSmartBannerPortrait] ;
    [admobBannerView setFrame:CGRectMake(admobBannerView.frame.origin.x, 20, admobBannerView.frame.size.width, admobBannerView.frame.size.height)];
    admobBannerView.adUnitID = AdMob_ID_Genre;
    admobBannerView.rootViewController = self;
    [footerView addSubview:admobBannerView];
    [admobBannerView loadRequest:[GADRequest request]];
    
    [footerView setFrame:CGRectMake(0, _scrollview.contentSize.height-50, _scrollview.frame.size.width, admobBannerView.frame.size.height + 20)];

    
    [_scrollview addSubview:footerView];
    [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, _scrollview.contentSize.height + footerView.frame.size.height)];
}
-(void)removeAdtap:(UIButton *)sender{
    
    SettingsViewController *gosetting = [[SettingsViewController alloc]initWithNibName:@"SettingsViewController" bundle:nil];
    [self.navigationController pushViewController:gosetting animated:YES];
}

#pragma mark - Setup Scrollers

- (void)setupFetured:(NSMutableDictionary *)result yaxis:(float)y tag:(int)tag{
    NSMutableArray *items = [NSMutableArray array];
    
    for (int i = 0; i<[[result valueForKey:@"books" ]count]; i++) {
        BookCommon *item = [[[NSBundle mainBundle] loadNibNamed:@"BookItemFeatured" owner:self options:nil] lastObject];
        [item setDelgate:self];
        [item setAccessibilityIdentifier:@"BookItemFeatured"];
        item.tag = tag;
        [item setAccessibilityHint:[NSString stringWithFormat:@"%d",i]];
        [item PopulateResult:[[result valueForKey:@"books" ]objectAtIndex:i] showstar:YES];
        [items addObject:item];
    }
    
    
    
    ILSideScrollView *scroller1 = [[ILSideScrollView alloc] initWithFrame:
                                   CGRectMake(0,
                                              y,
                                              _scrollview.frame.size.width,
                                              topheight)];
    
    [scroller1 setBackgroundColor:[UIColor colorWithRed:51.0/255.0 green:51.0/255.0 blue:51.0/255.0 alpha:1.0]];
    
    [scroller1 populateSideScrollViewWithItems:items];
    
    [_scrollview addSubview:scroller1];
    
    UILabel *lblName = [[UILabel alloc]initWithFrame:CGRectMake(10, y+ 8, 250, 20)];
    lblName.text = [NSString stringWithFormat:@"%@",[result valueForKey:@"title"]] ;
    [lblName setBackgroundColor:[UIColor clearColor]];
   [lblName setTextColor:[UIColor whiteColor]];
    lblName.font =[UIFont systemFontOfSize:16];
    [_scrollview addSubview:lblName];
    
    UILabel *seeall = [[UILabel alloc]initWithFrame:CGRectMake(_scrollview.frame.size.width - 60, y+ 8, 100, 20)];
    seeall.text = @"See All >" ;
    [seeall setBackgroundColor:[UIColor clearColor]];
    [seeall setTextColor:[UIColor lightGrayColor]];
    seeall.font =[UIFont systemFontOfSize:12];
    seeall.userInteractionEnabled = YES;
    [_scrollview addSubview:seeall];
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didTouchseeall:)];
    [seeall addGestureRecognizer:tap];
    
    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, scroller1.frame.origin.y+ scroller1.frame.size.height, _scrollview.frame.size.width, 1)];
    [img setImage:[UIImage imageNamed:@"seprator"]];
    [_scrollview addSubview:img];
    
}

-(void)setupSecondTop:(NSMutableDictionary *)result yaxis:(float)y tag:(int)tag{
    NSMutableArray *items = [NSMutableArray array];
    
    for (int i = 0; i<[[result valueForKey:@"books" ]count]; i++) {
        BookCommon *item = [[[NSBundle mainBundle] loadNibNamed:@"BookItemTopSecond" owner:self options:nil] lastObject];
        [item setDelgate:self];
        [item setAccessibilityIdentifier:@"BookItemTopSecond"];
        item.tag = tag;
        [item setAccessibilityHint:[NSString stringWithFormat:@"%d",i]];
        [item PopulateResult:[[result valueForKey:@"books" ]objectAtIndex:i] showstar:NO];
        
        [items addObject:item];
    }
    
    
    
    ILSideScrollView *scroller1 = [[ILSideScrollView alloc] initWithFrame:
                                   CGRectMake(0,
                                              y,
                                              _scrollview.frame.size.width,
                                              topsecondheight)];
   
    [scroller1 setBackgroundColor:[UIColor colorWithRed:237.0/255.0 green:237.0/255.0 blue:237.0/255.0 alpha:1.0]];
    
    [scroller1 populateSideScrollViewWithItems:items];
    
    [_scrollview addSubview:scroller1];
    
    UILabel *lblName = [[UILabel alloc]initWithFrame:CGRectMake(10, y+ 20, 250, 20)];
    lblName.text = [NSString stringWithFormat:@"%@",[result valueForKey:@"title"]] ;
    [lblName setBackgroundColor:[UIColor clearColor]];
   
    [lblName setTextColor:[UIColor blackColor]];
    lblName.font =[UIFont systemFontOfSize:16];
    [_scrollview addSubview:lblName];
    
    UILabel *seeall = [[UILabel alloc]initWithFrame:CGRectMake(_scrollview.frame.size.width - 60, y+20, 100, 20)];
    seeall.text = @"See All >" ;
    [seeall setBackgroundColor:[UIColor clearColor]];
    [seeall setTextColor:[UIColor lightGrayColor]];
    seeall.font =[UIFont systemFontOfSize:12];
    seeall.userInteractionEnabled = YES;
    [_scrollview addSubview:seeall];
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didTouchseeall:)];
    [seeall addGestureRecognizer:tap];
    
    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, scroller1.frame.origin.y+ scroller1.frame.size.height, _scrollview.frame.size.width, 1)];
    [img setImage:[UIImage imageNamed:@"seprator"]];
    [_scrollview addSubview:img];
    
    
    
}
- (void)setupNormal:(NSMutableDictionary *)result yaxis:(float)y tag:(int)tag {
    NSMutableArray *items = [NSMutableArray array];
    
    for (int i = 0; i<[[result valueForKey:@"books" ]count]; i++) {
        BookCommon *item = [[[NSBundle mainBundle] loadNibNamed:@"BookNormal" owner:self options:nil] lastObject];
        [item setDelgate:self];
        [item setAccessibilityIdentifier:@"BookNormal"];
        item.tag = tag;
        [item setAccessibilityHint:[NSString stringWithFormat:@"%d",i]];
        [item PopulateResult:[[result valueForKey:@"books" ]objectAtIndex:i] showstar:YES];
        [items addObject:item];
    }
    
    
    
    ILSideScrollView *scroller1 = [[ILSideScrollView alloc] initWithFrame:
                                   CGRectMake(0,
                                              y,
                                              _scrollview.frame.size.width,
                                              botttomheight)];
    [scroller1 setBackgroundColor:[UIColor clearColor]];
    [scroller1 populateSideScrollViewWithItems:items];
    
    [_scrollview addSubview:scroller1];
    
    UILabel *lblName = [[UILabel alloc]initWithFrame:CGRectMake(10, y+ 20, 250, 20)];
    lblName.text = [NSString stringWithFormat:@"%@",[result valueForKey:@"title"]] ;
    [lblName setBackgroundColor:[UIColor clearColor]];
    [lblName setTextColor:[UIColor blackColor]];
    lblName.font =[UIFont systemFontOfSize:16];
    [_scrollview addSubview:lblName];
    
    UILabel *seeall = [[UILabel alloc]initWithFrame:CGRectMake(_scrollview.frame.size.width - 60, y + 20, 100, 20)];
    seeall.text = @"See All >" ;
    [seeall setBackgroundColor:[UIColor clearColor]];
    [seeall setTextColor:[UIColor lightGrayColor]];
    seeall.font =[UIFont systemFontOfSize:12];
    seeall.userInteractionEnabled = YES;
    [_scrollview addSubview:seeall];
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didTouchseeall:)];
    [seeall addGestureRecognizer:tap];
    
    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, scroller1.frame.origin.y+ scroller1.frame.size.height, _scrollview.frame.size.width, 1)];
    [img setImage:[UIImage imageNamed:@"seprator"]];
    [_scrollview addSubview:img];
    
    
    
}

-(void)didTouchBook:(NSMutableDictionary *)book{
    
    
 //   NSLog(@"--->%@",book);
    BookDetailViewController *detail = [[BookDetailViewController alloc]initWithNibName:@"BookDetailViewController" bundle:nil];
    detail.booksarray = [NSMutableArray arrayWithArray:[[resultArr objectAtIndex:[[book valueForKey:@"tag"]intValue]]valueForKey:@"books"]];
    detail.pageindex = [[book valueForKey:@"index"]intValue];
    detail.backbtntitle = _lbl_title.text;
    if (IPHONE) {
    
    [self.navigationController pushViewController:detail animated:YES];
    }
    else{
    
        
        [self addChildViewController: detail];
        [self.view addSubview: detail.view];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(removeChild:)];
        [detail.tapableview addGestureRecognizer:tap];
    }
    
    
    
}
-(void)removeChild:(UITapGestureRecognizer *)sender{
    UIViewController *vc = [self.childViewControllers lastObject];
    [vc willMoveToParentViewController:nil];
    [vc.view removeFromSuperview];
    [vc removeFromParentViewController];
    
}

-(void)didTouchseeall:(UITapGestureRecognizer *)sender{
    
    if (_is_language == YES) {
        AllBookListViewController *goseall = [[AllBookListViewController alloc]initWithNibName:@"AllBookListViewController" bundle:nil];
        goseall.identifier = [NSString stringWithFormat:@"%@",_languageUrl];
        goseall.is_language = YES;
        goseall.backbtntitle = _lbl_title.text;
        [self.navigationController pushViewController:goseall animated:YES];
        
        
    }else{
       
        AllBookListViewController *goseall = [[AllBookListViewController alloc]initWithNibName:@"AllBookListViewController" bundle:nil];
        goseall.identifier = [NSString stringWithFormat:@"%@",_genreUrl];
        goseall.is_genre = YES;
        goseall.backbtntitle = _lbl_title.text;
        [self.navigationController pushViewController:goseall animated:YES];
           
       
        
    }
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)goNowPlaying:(id)sender {
    MyBookDetailViewController *godetail = [[MyBookDetailViewController alloc]initWithNibName:@"MyBookDetailViewController" bundle:nil];
    godetail.myBookDict = DELEGATE.playDict;
    FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
    item.title = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"title"];
    item.url = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"file"];
    item.number = DELEGATE.playingIndex;
    godetail.selectedPlaylistItem = item;
    godetail.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:godetail animated:YES];
}
@end
