//
//  AllBookTableViewCell.h
//  Ebook App
//
//  Created by macmini3 on 08/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AllBookTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UILabel *lbl_author;

@property (weak, nonatomic) IBOutlet CustomLabel *lbl_genre;
@property (weak, nonatomic) IBOutlet UIImageView *imgview;
-(void)populateResult:(NSMutableDictionary *)results;
@property (weak, nonatomic) IBOutlet UILabel *lbl_index;
@end
