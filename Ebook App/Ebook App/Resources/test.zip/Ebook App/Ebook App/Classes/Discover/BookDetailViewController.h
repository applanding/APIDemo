//
//  BookDetailViewController.h
//  Ebook App
//
//  Created by macmini3 on 15/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SwipeView.h"
#import "ModelClass.h"
#import "DWTagList.h"
#import "SectionReview.h"
#import "ReviewTableViewCell.h"
#import "ChapterTableViewCell.h"
#import "FSPlaylistItem.h"

@interface BookDetailViewController : UIViewController<SwipeViewDataSource, SwipeViewDelegate,UITableViewDataSource, UITableViewDelegate,BookDelegate, DWTagListDelegate, DownloadDelegate>{
    
    NSMutableDictionary *bookdetaildict;
    BOOL is_displayed;
    GADBannerView *admobBannerView;
}

@property (retain, nonatomic) NSMutableArray *booksarray;
@property (weak, nonatomic) IBOutlet SwipeView *swipeview;
@property (assign, nonatomic) NSInteger pageindex;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
- (IBAction)goBack:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *view_middle;
@property (weak, nonatomic) IBOutlet UIView *view_description;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;
- (IBAction)selectOption:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *txt_description;
@property (weak, nonatomic) IBOutlet UIView *view_bottom1;
@property (weak, nonatomic) IBOutlet UIView *view_bottomrelated;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (weak, nonatomic) IBOutlet UIButton *btn_back;
@property (retain, nonatomic) NSString *backbtntitle;
@property (weak, nonatomic) IBOutlet UIButton *btn_nowplaying;
- (IBAction)goNowPlaying:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *tapableview;
@end
