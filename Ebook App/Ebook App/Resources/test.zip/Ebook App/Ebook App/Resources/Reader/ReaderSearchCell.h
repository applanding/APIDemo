//
//  ReaderSearchCell.h
//  Ebook App
//
//  Created by macmini3 on 16/10/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReaderSearchCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lbl_chapter;
@property (weak, nonatomic) IBOutlet UITextView *lbl_desc;
@end
