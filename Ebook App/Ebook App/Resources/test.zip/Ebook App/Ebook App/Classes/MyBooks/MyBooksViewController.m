//
//  MyBooksViewController.m
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "MyBooksViewController.h"

@interface MyBooksViewController ()

@end

@implementation MyBooksViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    [_collectionview registerNib:[UINib nibWithNibName:NSStringFromClass([MybookCell class]) bundle:nil]
           forCellWithReuseIdentifier:NSStringFromClass([MybookCell class])];
    [_collectionview registerNib:[UINib nibWithNibName:@"MybookDiscoverCell" bundle:nil]
      forCellWithReuseIdentifier:@"MybookDiscoverCell"];
    
    if (_is_edit) {
        _btn_done.hidden = NO;
        _btn_settings.hidden = YES;
    }
    
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [_collectionview reloadData];
    if (!DELEGATE.playDict) {
        _btn_nowplaying.hidden = YES;
    }else{
        _btn_nowplaying.hidden = NO;
    }
}

#pragma mark - UICollectionView Datasource
// 1
- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section {
    if(!_is_edit && [MyBooks count] == 0 ){
        return [MyBooks count] + 1;
    }
        return [MyBooks count];
}
// 2
- (NSInteger)numberOfSectionsInCollectionView: (UICollectionView *)collectionView {
    return 1;
}
// 3
- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == [MyBooks count]) {
        MybookCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"MybookDiscoverCell" forIndexPath:indexPath];
        cell.layer.shouldRasterize = YES;
        cell.layer.rasterizationScale = [UIScreen mainScreen].scale;
        cell.backgroundColor =[UIColor clearColor];
        return cell;
    }else{
        MybookCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"MybookCell" forIndexPath:indexPath];
        cell.backgroundColor =[UIColor clearColor];
        cell.layer.shouldRasterize = YES;
        cell.layer.rasterizationScale = [UIScreen mainScreen].scale;
        cell.is_edit = _is_edit;
        cell.btn_delete.tag = indexPath.row;
        cell.delgate = self;
        [cell PopulateResult:[MyBooks objectAtIndex:indexPath.row]];
    
    return cell;
    }
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
     
    if (indexPath.row == [MyBooks count]) {
        [DELEGATE.tabBarController setSelectedIndex:1];
    }else{
        MyBookDetailViewController *godetail = [[MyBookDetailViewController alloc]initWithNibName:@"MyBookDetailViewController" bundle:nil];
        godetail.myBookDict = [MyBooks objectAtIndex:indexPath.row];
     
        if ([[DELEGATE.playDict valueForKeyPath:@"details.bookUrl"] isEqualToString:[[MyBooks objectAtIndex:indexPath.row]valueForKeyPath:@"details.bookUrl"]]) {
            FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
            item.title = [[[[MyBooks objectAtIndex:indexPath.row] valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"title"];
            item.url = [[[[MyBooks objectAtIndex:indexPath.row] valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"file"];
            item.number = DELEGATE.playingIndex;
            godetail.selectedPlaylistItem = item;
        }
      else if ([[[MyBooks objectAtIndex:indexPath.row] valueForKey:@"mp3"]count]> 0) {
            FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
            item.title = [[[[MyBooks objectAtIndex:indexPath.row] valueForKey:@"mp3"]objectAtIndex:0]valueForKey:@"title"];
            item.url = [[[[MyBooks objectAtIndex:indexPath.row] valueForKey:@"mp3"]objectAtIndex:0]valueForKey:@"file"];
            item.number = 0;
            godetail.selectedPlaylistItem = item;
        }
       godetail.hidesBottomBarWhenPushed = YES;
     //   godetail.shouldStartPlaying = YES;
        [self.navigationController pushViewController:godetail animated:YES];
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)goSettings:(id)sender {
    SettingsViewController *gosetting = [[SettingsViewController alloc]initWithNibName:@"SettingsViewController" bundle:nil];
    [self.navigationController pushViewController:gosetting animated:YES];
}

- (IBAction)goDone:(id)sender {
    _is_edit = NO;
    _btn_done.hidden = YES;
    _btn_settings.hidden = NO;
    [_collectionview reloadData];
}
-(void)didTouchDelete:(NSInteger)tag{
    
    NSMutableArray *temp = [NSMutableArray arrayWithArray:MyBooks];
    [[NSFileManager defaultManager]removeItemAtPath:[DELEGATE getinstalledEPubDirectory:[[[MyBooks objectAtIndex:tag]valueForKeyPath:@"details.ePub"] lastPathComponent]] error:nil];
    
    [temp removeObjectAtIndex:tag];
    NSData *personEncodedObject = [NSKeyedArchiver archivedDataWithRootObject:temp];
    [[NSUserDefaults standardUserDefaults]setObject:personEncodedObject  forKey:@"MyBooks"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    [_collectionview reloadData];
    if ([MyBooks count] == 0) {
        [self goDone:nil];
    }
    
}
- (IBAction)goNowplaying:(id)sender {
        MyBookDetailViewController *godetail = [[MyBookDetailViewController alloc]initWithNibName:@"MyBookDetailViewController" bundle:nil];
        godetail.myBookDict = DELEGATE.playDict;
        FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
        item.title = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"title"];
        item.url = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"file"];
        item.number = DELEGATE.playingIndex;
        godetail.selectedPlaylistItem = item;
    godetail.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:godetail animated:YES];
    
}
@end
