//
//  AllBookCollectiionViewCell.m
//  Ebook App
//
//  Created by macmini3 on 19/10/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "AllBookCollectiionViewCell.h"

@implementation AllBookCollectiionViewCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)populateResult:(NSMutableDictionary *)dict{
    
    if(dict){
        
        if (![[dict valueForKey:@"title"]isEqual:[NSNull null]]) {
            _lbl_title.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"title"]];
        }
        [_lbl_title sizeToFit];
        
        [_lbl_title setFrame:CGRectMake(_lbl_title.frame.origin.x, 14, 230, MIN(40, _lbl_title.frame.size.height))];
        
        _lbl_title.frame = CGRectMake(_lbl_title.frame.origin.x,
                                      _lbl_title.frame.origin.y + (40 - _lbl_title.frame.size.height),
                                      230,
                                      _lbl_title.frame.size.height);
        
        if (![[dict valueForKey:@"author"]isEqual:[NSNull null]]) {
            _lbl_author.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"author"]];
        }
        
        if ([dict valueForKey:@"genre"]) {
            _lbl_genre.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"genre"]];
            CGSize textSize = [[_lbl_genre text] sizeWithFont:_lbl_genre.font forWidth:_lbl_genre.bounds.size.width lineBreakMode:_lbl_genre.lineBreakMode];
            
            _lbl_genre.layer.borderWidth = 1.0;
            _lbl_genre.layer.borderColor = [UIColor colorWithRed:190.0/255.0 green:190.0/255.0 blue:190.0/255.0 alpha:1.0].CGColor;
            [_lbl_genre setFrame:CGRectMake(_lbl_genre.frame.origin.x, _lbl_genre.frame.origin.y, MIN(textSize.width +20, _lbl_genre.frame.size.width), _lbl_genre.frame.size.height)];
        }
        else{
            _lbl_genre.hidden = YES;
        }
        
        _lbl_index.text = [NSString stringWithFormat:@"%ld",(long)self.tag];
        [_imgview setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dict valueForKey:@"image"]]] placeholderImage:[UIImage imageNamed:@"Book_placeholder"]];
        
        if (![[dict valueForKey:@"rating"]isEqual:[NSNull null]]) {
            TQStarRatingView   *starRatingView = [[TQStarRatingView alloc] initWithCustomeFrame:CGRectMake(_lbl_author.frame.origin.x, _lbl_author.frame.origin.y + _lbl_author.frame.size.height, 70, 14)
                                                                                   numberOfStar:kNUMBER_OF_STAR];
            starRatingView.userInteractionEnabled = NO;
            [starRatingView setScore:[[dict valueForKey:@"rating"]floatValue]/5.0 withAnimation:NO];
            [self addSubview:starRatingView];
        }
        
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
