//
//  ModelClass.m
//  APITest
//
//  Created by Evgeny Kalashnikov on 03.12.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ModelClass.h"

@implementation ModelClass


- (id)init
{
    self = [super init];
    if (self) {
       drkSignUp = [[DarckWaitView alloc] initWithDelegate:nil andInterval:0.1 andMathod:nil];
    }
    
    return self;
}

- (void)GetViewOf:(NSString *)view page:(NSString *)page success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    NSMutableDictionary *requestDictionary = [NSMutableDictionary new];
    [requestDictionary setObject:API_KEY forKey:@"key"];
    [requestDictionary setObject:view forKey:@"view"];
    [requestDictionary setObject:page forKey:@"page"];
    [self getURL:@"" parameters:requestDictionary success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
    
    
    
    
}
- (void)Getmenuofgenre:(NSString *)menu success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    NSMutableDictionary *requestDictionary = [NSMutableDictionary new];
    [requestDictionary setObject:API_KEY forKey:@"key"];
    [requestDictionary setObject:menu forKey:@"menu"];
    [self getURL:@"" parameters:requestDictionary success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}

- (void)Getgenrebooks:(NSString *)genre page:(NSString *)page success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    NSMutableDictionary *requestDictionary = [NSMutableDictionary new];
    [requestDictionary setObject:API_KEY forKey:@"key"];
    [requestDictionary setObject:genre forKey:@"genre"];
    [requestDictionary setObject:page forKey:@"page"];
    
    
    [self getURL:@"" parameters:requestDictionary success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void)Getbooksforlanguage:(NSString *)language page:(NSString *)page success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    NSMutableDictionary *requestDictionary = [NSMutableDictionary new];
    [requestDictionary setObject:API_KEY forKey:@"key"];
    [requestDictionary setObject:language forKey:@"language"];
    [requestDictionary setObject:page forKey:@"page"];
    
    
    [self getURL:@"" parameters:requestDictionary success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}

- (void)Getsearchresultfor:(NSString *)text  success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    NSMutableDictionary *requestDictionary = [NSMutableDictionary new];
    [requestDictionary setObject:API_KEY forKey:@"key"];
    [requestDictionary setObject:text forKey:@"search"];
    
    
    
    [self getURL:@"" parameters:requestDictionary success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}

- (void)GetbookDetail:(NSString *)bookUrl success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    NSMutableDictionary *requestDictionary = [NSMutableDictionary new];
    [requestDictionary setObject:API_KEY forKey:@"key"];
    [requestDictionary setObject:bookUrl forKey:@"book"];
    [self getURL:@"" parameters:requestDictionary success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}

-(void)postURL:(NSString *)URL parameters:(NSDictionary *)parameters success: (void (^) (id result)) successBlock failure: (void (^) (NSError * error)) failureBlock{

    if ([AFNetworkReachabilityManager sharedManager].reachable) {
        [drkSignUp showWithMessage:nil];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
    [manager POST:[[NSString stringWithFormat:@"%@%@",API_PATH,URL]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
    //    NSLog(@"JSON: %@", responseObject);
        [drkSignUp hide];
        successBlock(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        [drkSignUp hide];
        failureBlock(error);
    }];
    }else{
    
    
    }
    
}
-(void)getURL:(NSString *)URL parameters:(NSDictionary *)parameters success: (void (^) (id result)) successBlock failure: (void (^) (NSError * error)) failureBlock{
    
   
    
    if ([AFNetworkReachabilityManager sharedManager].reachable) {
        
        [drkSignUp showWithMessage:nil];
        if ([parameters valueForKey:@"page"]) {
            if([[parameters valueForKey:@"page"]intValue] > 1){
                [drkSignUp hide];
            }
        }
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        [manager.requestSerializer setCachePolicy:NSURLRequestReturnCacheDataElseLoad];
        manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
        [manager GET:[[NSString stringWithFormat:@"%@%@",API_PATH,URL]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            //NSLog(@"JSON: %@", operation.responseString);
            [drkSignUp hide];
            successBlock(responseObject);
            
         //   NSLog(@"--->%@",[[operation response] allHeaderFields]);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", error);
            NSLog(@"Error: %@", operation.responseString);
            [drkSignUp hide];
            failureBlock(error);
        }];
    }else{
        // Offline mode
        
        [drkSignUp showWithMessage:nil];
        if ([parameters valueForKey:@"page"]) {
            if([[parameters valueForKey:@"page"]intValue] > 1){
                [drkSignUp hide];
            }
        }
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        [manager.requestSerializer setCachePolicy:NSURLRequestReturnCacheDataDontLoad];
        manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
        [manager GET:[[NSString stringWithFormat:@"%@%@",API_PATH,URL]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            //NSLog(@"JSON: %@", operation.responseString);
            [drkSignUp hide];
            successBlock(responseObject);
            
            //   NSLog(@"--->%@",[[operation response] allHeaderFields]);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", error);
            NSLog(@"Error: %@", operation.responseString);
            [drkSignUp hide];
            failureBlock(error);
        }];
        
        
       
    }
    
    
    
    
}
@end