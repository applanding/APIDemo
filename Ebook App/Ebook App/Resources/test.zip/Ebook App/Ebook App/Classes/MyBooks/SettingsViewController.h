//
//  SettingsViewController.h
//  Ebook App
//
//  Created by macmini3 on 23/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MFMailComposeViewController.h>
@interface SettingsViewController : UIViewController<UITableViewDataSource,UITableViewDataSource,MFMailComposeViewControllerDelegate>

- (IBAction)goDone:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (weak, nonatomic) IBOutlet UIButton *btn_nowplaying;
- (IBAction)goNowPlaying:(id)sender;
@end
