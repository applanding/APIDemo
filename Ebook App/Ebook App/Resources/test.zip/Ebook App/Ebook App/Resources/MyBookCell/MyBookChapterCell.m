//
//  MyBookChapterCell.m
//  Ebook App
//
//  Created by macmini3 on 04/10/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "MyBookChapterCell.h"

@implementation MyBookChapterCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)populateResult:(NSMutableDictionary *)dict{
    
    if(dict){
        
        if (![[dict valueForKey:@"title"]isEqual:[NSNull null]]) {
            _lbl_title.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"title"]];
        }
        [_lbl_title sizeToFit];
        
        [_lbl_title setFrame:CGRectMake(_lbl_title.frame.origin.x, _lbl_title.frame.origin.y, _lbl_title.frame.size.width, MIN(30, _lbl_title.frame.size.height))];
        
        _lbl_title.frame = CGRectMake(_lbl_title.frame.origin.x,
                                      15 + (30 - _lbl_title.frame.size.height),
                                      _lbl_title.frame.size.width,
                                      _lbl_title.frame.size.height);
        if (![[dict valueForKey:@"length"]isEqual:[NSNull null]]) {
            _lbl_description.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"length"]];
        }
        
        
        
        
    }
}
@end
