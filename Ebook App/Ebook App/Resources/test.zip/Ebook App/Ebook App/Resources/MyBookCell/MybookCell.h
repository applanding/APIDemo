//
//  MybookCell.h
//  Ebook App
//
//  Created by macmini3 on 19/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MyBookDelegate <NSObject>
@optional
-(void)didTouchDelete:(NSInteger)tag;
@end

@interface MybookCell : UICollectionViewCell

@property(nonatomic,weak) id<MyBookDelegate>delgate;
@property (weak, nonatomic) IBOutlet UIImageView *imgview;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UILabel *lbl_author;
-(void)PopulateResult:(NSMutableDictionary *)dict;
@property(assign,nonatomic) bool is_edit;
@property (weak, nonatomic) IBOutlet UIButton *btn_delete;
- (IBAction)goDelete:(id)sender;
@end
