//
//  AllListPaginator.m
//  Ebook App
//
//  Created by macmini3 on 11/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "AllListPaginator.h"

@implementation AllListPaginator
- (void)fetchResultWithPage:(NSInteger)page pageSize:(NSInteger)pageSize identifier:(NSString *)str is_genre:(BOOL)is_genre is_featured:(BOOL)is_featured is_language:(BOOL)is_language
{
    
    if (is_genre) {
        ModelClass *mc = [[ModelClass alloc]init];
        [mc Getgenrebooks:[NSString stringWithFormat:@"%@",str] page:[NSString stringWithFormat:@"%ld",(long)page] success:^(id result) {
            if ([[result valueForKey:@"books"] isKindOfClass:[NSArray class]]) {
                [self receivedResults:[result valueForKey:@"books"] total:[[result valueForKey:@"totalRecords"]intValue] title:[NSString stringWithFormat:@"%@",[result valueForKey:@"title"]]];
            }
        //    NSLog(@"-->%@",result );
            
        } error:^(NSError *error) {
          //  NSLog(@"-->%@",error.description);
            
            
        }];
        
    }
    if (is_featured) {
        
    ModelClass *mc = [[ModelClass alloc]init];
    [mc GetViewOf:str page:[NSString stringWithFormat:@"%ld",(long)page] success:^(id result) {
        
        if ([[result valueForKey:@"books"] isKindOfClass:[NSArray class]]) {
            [self receivedResults:[result valueForKey:@"books"] total:[[result valueForKey:@"totalRecords"]intValue] title:[NSString stringWithFormat:@"%@",[result valueForKey:@"title"]]];
        }
   //     NSLog(@"-->%@",result);
        
    } error:^(NSError *error) {
      //  NSLog(@"-->%@",error.description);
        
    }];
    }
    if (is_language) {
        ModelClass *mc = [[ModelClass alloc]init];
        
        
        [mc Getbooksforlanguage:[NSString stringWithFormat:@"%@",str] page:[NSString stringWithFormat:@"%ld",(long)page] success:^(id result) {
            if ([[result valueForKey:@"books"] isKindOfClass:[NSArray class]]) {
                [self receivedResults:[result valueForKey:@"books"] total:[[result valueForKey:@"totalRecords"]intValue] title:[NSString stringWithFormat:@"%@",[result valueForKey:@"title"]]];
            }
       //     NSLog(@"-->%@",result );
            
        } error:^(NSError *error) {
          //  NSLog(@"-->%@",error.description);
            
            
        }];
        
    }
}


@end
