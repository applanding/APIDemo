//
//  GenresViewController.m
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "GenresViewController.h"

@interface GenresViewController ()

@end

@implementation GenresViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    ModelClass *mc = [[ModelClass alloc]init];
    
    [mc Getmenuofgenre:@"all" success:^(id result) {
        resultdict = [[NSMutableDictionary alloc]initWithDictionary:result];
    //    NSLog(@"-->%@",[resultdict allKeys]);
    //    NSLog(@"-->%@",resultdict );
        [_tableview reloadData];
        
        
        if (!IPHONE) {
            leftdict = [[NSMutableDictionary alloc]init];
            rightdict = [[NSMutableDictionary alloc]init];
            
            NSMutableArray *leftmenu = [NSMutableArray array];
             NSMutableArray *rightmenu = [NSMutableArray array];
            for (int i = 0; i < [[resultdict valueForKey:@"menu"]count]; i++) {
                
                if ([[[[resultdict valueForKey:@"menu"]objectAtIndex:i]valueForKey:@"title"]isEqualToString:@"Languages"]) {
                    [rightmenu addObject:[[resultdict valueForKey:@"menu"]objectAtIndex:i]];
                }else{
                
                    [leftmenu addObject:[[resultdict valueForKey:@"menu"]objectAtIndex:i]];
                }
            }
            [leftdict setObject:leftmenu forKey:@"menu"];
            [rightdict setObject:rightmenu forKey:@"menu"];
            [_table_left reloadData];
            [_table_right reloadData];
        }
        
    } error:^(NSError *error) {
     //   NSLog(@"-->%@",error.description);
        
        
    }];
    
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    if (!DELEGATE.playDict) {
        _btn_nowplaying.hidden = YES;
    }else{
        _btn_nowplaying.hidden = NO;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if ([tableView isEqual:_tableview]) {
    return [[resultdict valueForKey:@"menu"]count];
    }else if([tableView isEqual:_table_left]){
        return [[leftdict valueForKey:@"menu"]count];
    }else if([tableView isEqual:_table_right]){
        return [[rightdict valueForKey:@"menu"]count];
    
    }
    return 0;
}

-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    if ([tableView isEqual:_tableview]) {
        return [[[[resultdict valueForKey:@"menu"]objectAtIndex:section]valueForKey:@"items"]count];
    }else if([tableView isEqual:_table_left]){
        return [[[[leftdict valueForKey:@"menu"]objectAtIndex:section]valueForKey:@"items"]count];
    }else if([tableView isEqual:_table_right]){
        return [[[[rightdict valueForKey:@"menu"]objectAtIndex:section]valueForKey:@"items"]count];
    }
    return 0;
    
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    
    UIView * uview= [[UIView alloc]initWithFrame:CGRectMake(0,0,tableView.frame.size.width,44)];
    uview.layer.masksToBounds=YES;
    uview.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
   
    
    UILabel *seclbl = [[UILabel alloc]initWithFrame:CGRectMake(15,0,300,44)];
    [seclbl setTextColor:[UIColor blackColor]];
    [seclbl setBackgroundColor:[UIColor clearColor]];
    [seclbl setFont:[UIFont boldSystemFontOfSize:16]];
    
    if ([tableView isEqual:_tableview]) {
        [seclbl setText:[NSString stringWithFormat:@"%@",[[[resultdict valueForKey:@"menu"] objectAtIndex:section]valueForKey:@"title"]]];
    }else if([tableView isEqual:_table_left]){
        [seclbl setText:[NSString stringWithFormat:@"%@",[[[leftdict valueForKey:@"menu"] objectAtIndex:section]valueForKey:@"title"]]];
    }else if([tableView isEqual:_table_right]){
        
        [seclbl setText:[NSString stringWithFormat:@"%@",[[[rightdict valueForKey:@"menu"] objectAtIndex:section]valueForKey:@"title"]]];
    }
    
   [uview addSubview:seclbl];
    if (section !=0) {
    UIImageView *img1 = [[UIImageView alloc]initWithFrame:CGRectMake(15, 0, tableView.frame.size.width, 0.5)];
    [img1 setBackgroundColor:[UIColor colorWithRed:170.0/255.0 green:170.0/255.0 blue:170.0/255.0 alpha:0.5]];
  //  [uview addSubview:img1];
    }
   
    
    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(15, 43, tableView.frame.size.width, 0.5)];
    [img setBackgroundColor:[UIColor colorWithRed:170.0/255.0 green:170.0/255.0 blue:170.0/255.0 alpha:0.5]];
 //   [uview addSubview:img];
    
    return uview;
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    // add a placeholder cell while waiting on table data
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] ;
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    
    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(15, 10, 24, 24)];
    [img setContentMode:UIViewContentModeScaleAspectFit];
    
    if ([tableView isEqual:_tableview]) {
         [img setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[[[[resultdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"image"]]]];
    }else if([tableView isEqual:_table_left]){
         [img setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[[[[leftdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"image"]]]];
    }else if([tableView isEqual:_table_right]){
         [img setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[[[[rightdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"image"]]]];
    }
    
   
    [cell addSubview:img];

    
    UILabel *mainlb = [[UILabel alloc]initWithFrame:CGRectMake(55,0,200,44)];
    [mainlb setTextColor:[UIColor blackColor]];
    [mainlb setBackgroundColor:[UIColor clearColor]];
    
    if ([tableView isEqual:_tableview]) {
         mainlb.text = [NSString stringWithFormat:@"%@",[[[[[resultdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"title"]];
    }else if([tableView isEqual:_table_left]){
         mainlb.text = [NSString stringWithFormat:@"%@",[[[[[leftdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"title"]];
    }else if([tableView isEqual:_table_right]){
         mainlb.text = [NSString stringWithFormat:@"%@",[[[[[rightdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"title"]];
    }
    
   
    [cell addSubview:mainlb];

    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if ([tableView isEqual:_tableview]) {
        if ([[NSString stringWithFormat:@"%@",[[[resultdict valueForKey:@"menu"] objectAtIndex:indexPath.section]valueForKey:@"title"]]isEqualToString:@"Languages"]) {
            GenreShowcaseViewController *genre = [[GenreShowcaseViewController alloc]initWithNibName:@"GenreShowcaseViewController" bundle:nil];
                genre.languageUrl = [NSString stringWithFormat:@"%@",[[[[[resultdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"languageUrl"]];
                genre.genreTitle = [NSString stringWithFormat:@"%@",[[[[[resultdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"title"]];
            genre.is_language = YES;
            genre.backbtntitle  = @"Genres";
            [self.navigationController pushViewController:genre animated:YES];
        }else{
            GenreShowcaseViewController *genre = [[GenreShowcaseViewController alloc]initWithNibName:@"GenreShowcaseViewController" bundle:nil];
                genre.genreUrl = [NSString stringWithFormat:@"%@",[[[[[resultdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"genreUrl"]];
                genre.genreTitle = [NSString stringWithFormat:@"%@",[[[[[resultdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"title"]];
            genre.backbtntitle  = @"Genres";
            [self.navigationController pushViewController:genre animated:YES];
        }
    }
    if ([tableView isEqual:_table_left]) {
        
        
            GenreShowcaseViewController *genre = [[GenreShowcaseViewController alloc]initWithNibName:@"GenreShowcaseViewController" bundle:nil];
            genre.genreUrl = [NSString stringWithFormat:@"%@",[[[[[leftdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"genreUrl"]];
            genre.genreTitle = [NSString stringWithFormat:@"%@",[[[[[leftdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"title"]];
            genre.backbtntitle  = @"Genres";
            [self.navigationController pushViewController:genre animated:YES];
        
    }
    if ([tableView isEqual:_table_right]) {
       
            GenreShowcaseViewController *genre = [[GenreShowcaseViewController alloc]initWithNibName:@"GenreShowcaseViewController" bundle:nil];
            genre.languageUrl = [NSString stringWithFormat:@"%@",[[[[[rightdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"languageUrl"]];
            genre.genreTitle = [NSString stringWithFormat:@"%@",[[[[[rightdict valueForKey:@"menu"]objectAtIndex:indexPath.section]valueForKey:@"items"]objectAtIndex:indexPath.row ]valueForKey:@"title"]];
            genre.is_language = YES;
            genre.backbtntitle  = @"Genres";
            [self.navigationController pushViewController:genre animated:YES];
       
    }
    
    
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)goNowPlaying:(id)sender {
    MyBookDetailViewController *godetail = [[MyBookDetailViewController alloc]initWithNibName:@"MyBookDetailViewController" bundle:nil];
    godetail.myBookDict = DELEGATE.playDict;
    FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
    item.title = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"title"];
    item.url = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"file"];
    item.number = DELEGATE.playingIndex;
    godetail.selectedPlaylistItem = item;
    godetail.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:godetail animated:YES];
}
@end
