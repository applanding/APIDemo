//
//  MyBooksViewController.h
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MybookCell.h"
#import "SettingsViewController.h"
#import "MyBookDetailViewController.h"
#import "FSPlaylistItem.h"
@interface MyBooksViewController : UIViewController<UICollectionViewDataSource, UICollectionViewDelegateFlowLayout,MyBookDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *collectionview;
@property (weak, nonatomic) IBOutlet UIButton *btn_done;
@property (weak, nonatomic) IBOutlet UIButton *btn_settings;
- (IBAction)goSettings:(id)sender;
- (IBAction)goDone:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_nowplaying;
@property(assign, nonatomic) bool is_edit;
- (IBAction)goNowplaying:(id)sender;
@end
