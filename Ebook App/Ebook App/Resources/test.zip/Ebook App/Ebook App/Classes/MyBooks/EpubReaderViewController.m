//
//  EpubReaderViewController.m
//  Ebook App
//
//  Created by macmini3 on 04/10/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "EpubReaderViewController.h"

// Utility Code
@interface ArrowView : UIView {
    UIColor *color;
    BOOL upSide;
}

@property BOOL upSide;

@end

@implementation ArrowView
@synthesize upSide;
#define SEARCHRESULT    0
#define SEARCHMORE      1
#define SEARCHFINISHED  2
#define MAX_NUM_SEARCH = 100
#define UIColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

-(void)setColor:(UIColor*)newColor {
    color = newColor;
    [self setNeedsDisplay];
}

-(void)drawRect:(CGRect)rect {
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    if (upSide) {
        CGContextBeginPath(ctx);
        CGContextMoveToPoint   (ctx, CGRectGetMaxX(rect)/2, CGRectGetMinY(rect));  // top left
        CGContextAddLineToPoint(ctx, CGRectGetMinX(rect), CGRectGetMaxY(rect));  // mid right
        CGContextAddLineToPoint(ctx, CGRectGetMaxX(rect), CGRectGetMaxY(rect));  // bottom left
        CGContextClosePath(ctx);
    }else {
        CGContextBeginPath(ctx);
        CGContextMoveToPoint   (ctx, CGRectGetMinX(rect), CGRectGetMinY(rect));  // top left
        CGContextAddLineToPoint(ctx, CGRectGetMaxX(rect), CGRectGetMinY(rect));  // mid right
        CGContextAddLineToPoint(ctx, CGRectGetMaxX(rect)/2, CGRectGetMaxY(rect));  // bottom left
        CGContextClosePath(ctx);
    }
    CGContextSetFillColorWithColor(ctx, [color CGColor]);
    CGContextFillPath(ctx);
}

@end


@interface EpubReaderViewController ()

@end

@implementation EpubReaderViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    bookmarks = [[NSMutableArray alloc]init];
    searchResults = [[NSMutableArray alloc]init];
    highlightsInPage = [[NSMutableArray alloc]init];
    highlights = [[NSMutableArray alloc]init];
    
    fontsArr = [[NSMutableArray alloc]initWithObjects:@"AmericanTypewriter",@"Arial",@"Courier",@"Cochin",@"Damascus",@"GeezaPro",@"Helvetica",@"MarkerFelt",@"Marion",@"Papyrus",@"SnellRoundhand",@"Times New Roman",@"Thonburi",@"Verdana",@"Zapfino", nil];
    _view_fonttable.layer.cornerRadius = 10;
    
    @autoreleasepool {
        
        [self becomeFirstResponder];
        self.view.backgroundColor = [UIColor clearColor];
        rv = [[ReflowableViewController alloc]initWithStartPagePositionInBook:self.bookInformation.position];
        rv.book.isFixedLayout = NO;
       
            rv.book.fontName = @"";
            _lbl_fontname.text = [NSString stringWithFormat:@"%@",@"Default"];
        
        fontsize = 14;
        rv.book.fontSize = fontsize;
        rv.book.fileName = _bookInformation.fileName;
        rv.book.bookCode = _bookInformation.bookCode;
        rv.baseDirectory = [DELEGATE getBooksDirectory];
        rv.transitionType = 1;
        self.isRTL = _bookInformation.isRTL;
        isDoublePaged = NO;
        
        [rv useDOMHighlight:NO];
        [rv setVerticalGapRatio:0.05];
        [rv setHorizontalGapRatio:0.1];
        [rv setGlobalPaging:YES];
        [rv showIndicatorWhileLoadingChapter:YES];
        [rv showIndicatorWhilePaging:NO];
        [rv showIndicatorWhileRotating:YES];
        [rv allowPageTransitionFast:YES];
        [rv setCustomDrawHighlight:YES];
        [rv changeForegroundColor:[UIColor blackColor]];
        [rv changeBackgroundColor:[UIColor clearColor]];
        [rv setMarkerImage:[UIImage imageNamed:@"markeryellow.png"]];
        
        rv.dataSource = self;
        rv.delegate =self;
        [rv setContentProviderClass:[FileProvider self]];
        [rv setLicenseKey:@"68c1-8273-213f-19f8"];
        [self addChildViewController:rv];
        if (Is_IOS7) {
            rv.view.frame = CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height - 125);
        }else{
            rv.view.frame = CGRectMake(0, 44, self.view.frame.size.width, self.view.frame.size.height - 75);
        }
    
        rv.view.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        [self.view addSubview:rv.view];
   
    }
    [self.view bringSubviewToFront:_view_search];
    [self.view bringSubviewToFront:_view_font];
    [self.view bringSubviewToFront:_view_chapterlist];
   // [_sli_pages bringSubviewToFront:self.view];
    [self makePIBox];
   
    _sli_brightness.value = [UIScreen mainScreen].brightness;
    
    [_sli_pages setThumbImage:[UIImage imageNamed:@"bluethumbround"] forState:UIControlStateNormal];
    [[UITextField appearanceWhenContainedIn:[UISearchBar class], nil] setTextColor:[UIColor whiteColor]];
  //  [[UIBarButtonItem appearanceWhenContainedIn: [UISearchBar class], nil] setTintColor:[UIColor whiteColor]];
    [[UILabel appearanceWhenContainedIn:[UISearchBar class], nil] setTextColor:[UIColor whiteColor]];
    
    [[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],UITextAttributeTextColor,[NSValue valueWithUIOffset:UIOffsetMake(0, 1)],UITextAttributeTextShadowOffset,nil] forState:UIControlStateNormal];
    [_txt_search setImage:[UIImage imageNamed:@"searchbarsearch"] forSearchBarIcon:UISearchBarIconSearch state:UIControlStateNormal];
    [_txt_search setImage:[UIImage imageNamed:@"searcbarcross"] forSearchBarIcon:UISearchBarIconClear state:UIControlStateNormal];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(fontChange:)];
    [_bgview addGestureRecognizer:tap];
    
    [[UIApplication sharedApplication]setStatusBarHidden:NO];
}
-(void)doNothing{

}
-(void)reflowableViewController:(ReflowableViewController*)rvc pageMoved:(PageInformation*)pageInformation{
  
    [rvc unselect];
    
    double ppb = pageInformation.pagePositionInBook;
    double pageDelta = ((1.0f/pageInformation.numberOfChaptersInBook)/pageInformation.numberOfPagesInChapter);
    if ([rv isRTL]) {
        ppb +=pageDelta;
    }
    _sli_pages.value = ppb;
    
    if (rvc.book.creator.length > 15) {
        rvc.book.creator = [rvc.book.creator substringToIndex:15];
        rvc.book.creator = [rvc.book.creator stringByAppendingString:@".."];
    }
    if (rvc.book.title.length > 15) {
        rvc.book.title = [rvc.book.title substringToIndex:15];
        rvc.book.title = [rvc.book.title stringByAppendingString:@".."];
    }
    
    
    
    [self changePageLabels:pageInformation];
    [self performSelector:@selector(processNoteIcons) withObject:nil afterDelay:0.0];
  
    self.bookInformation.position = pageInformation.pagePositionInBook;
    
    
 //   NSLog(@"chapter Index  %d %d",pageInformation.chapterIndex,pageInformation.pageIndexInBook);
    
    
}

-(BOOL)reflowableViewController:(ReflowableViewController*)rvc isBookmarked:(PageInformation*)pageInformation {
    BOOL ret = [DELEGATE isBookmarked:pageInformation];
    if (ret == YES) {
        [_btn_bookmark setImage:[UIImage imageNamed:@"bookmark_fill"] forState:UIControlStateNormal];
    }else{
        [_btn_bookmark setImage:[UIImage imageNamed:@"bookmark_empty"] forState:UIControlStateNormal];
    }
    return ret;
}
-(UIImage*)bookmarkImage:(ReflowableViewController*)rvc isBookmarked:(BOOL)isBookmarked{
    if (isBookmarked) {
        return [UIImage imageNamed:@""];
    }
   return [UIImage imageNamed:@""];
    
}
-(CGRect)bookmarkRect:(ReflowableViewController*)rvc isBookmarked:(BOOL)isBookmarked{
    return _btn_bookmark.frame;
}

-(void)changePageLabels:(PageInformation*)pageInformation{
    int pi,pn;
    
        pi = pageInformation.pageIndex;
        pn = pageInformation.numberOfPagesInChapter;
    
    
        _lbl_pages.text = [NSString stringWithFormat:@"%d/%d",   pi+1,pn];
         _lbl_pagesleft.text = [NSString stringWithFormat:@"%d pages left",pn-(pi+1)];
    
}

-(NSMutableArray*)reflowableViewController:(ReflowableViewController*)rvc highlightsForChapter:(NSInteger)chapterIndex {
    highlights = [DELEGATE fetchHighlights:_bookInformation.bookCode chapterIndex:chapterIndex];
    return highlights;
}

-(NSString*)reflowableViewController:(ReflowableViewController*)rvc scriptForChapter:(NSInteger)chapterIndex {
    return [self script];
}
-(NSString*)script {
    NSString *scriptPath = [[NSBundle mainBundle] pathForResource:@"/script" ofType:@"js"];
    NSString *script = [NSString stringWithContentsOfFile:scriptPath encoding:NSUTF8StringEncoding error:NULL];
    return script;
}

-(void)reflowableViewController:(ReflowableViewController*)rvc insertHighlight:(Highlight*)highlight {
    NSLog(@"insert color %d",highlight.highlightColor);
    [DELEGATE insertHighlight:highlight];
    currentHighlight = highlight;
   
}
-(void)reflowableViewController:(ReflowableViewController*)rvc deleteHighlight:(Highlight*)highlight {
    [DELEGATE deleteHighlight:highlight];
    [self processNoteIcons];
    [rvc refresh];
}

-(void)reflowableViewController:(ReflowableViewController*)rvc updateHighlight:(Highlight*)highlight {
    [DELEGATE updateHighlight:highlight];
    NSLog(@"update color %d",highlight.highlightColor);
    [self processNoteIcons];
    [rvc refresh];
}

-(void)reflowableViewController:(ReflowableViewController*)rvc didSelectRange:(Highlight*)highlight startRect:(CGRect)startRect endRect:(CGRect)endRect{
    currentHighlight = highlight;
   
    
}


-(void)reflowableViewController:(ReflowableViewController*)rvc didSelectionCanceled:(NSString*)lastSelectedText {

}

-(void)reflowableViewController:(ReflowableViewController*)rvc didSelectionChanged:(NSString*)selectedText {
    
}


-(void)reflowableViewController:(ReflowableViewController*)rvc didDetectTapAtPosition:(CGPoint)position{
    NSLog(@"tap detected");
    
}


-(void)reflowableViewController:(ReflowableViewController*)rvc didDetectDoubleTapAtPosition:(CGPoint)position{
}

-(void)reflowableViewController:(ReflowableViewController*)rvc didHitHighlight:(Highlight*)highlight atPosition:(CGPoint)position startRect:(CGRect)startRect endRect:(CGRect)endRect{
    currentHighlight = highlight;
   
}

// if [rv setCustomDrawHighlight:YES] then you can draw the highlight.
// since 4.0
-(void)reflowableViewController:(ReflowableViewController*)rvc drawHighlightRect:(CGRect)highlightRect context:(CGContextRef)context highlightColor:(UIColor*)highlightColor highlight:(Highlight*)highlight {
    
    // If you want to draw a just rectangle, uncomment belows
    //    CGRect rectangle = highlightRect;
    //    CGContextSetFillColorWithColor(context, [highlightColor CGColor]);
    //    CGContextFillRect(context, rectangle);
    
    // If you want to draw brush mark, use below.
    
    CGRect rect = highlightRect;
    if(IPHONE){
        rect.origin.x = highlightRect.origin.x + 15;
    }else{
    rect.origin.x = highlightRect.origin.x + 35;
    }
    
    
    
    UIImage* markerImage = [self getMarkerByColor:UIColorFromRGB(highlight.highlightColor)];
    CGContextDrawImage(context, rect, markerImage.CGImage);
}
-(UIImage*)getMarkerByColor:(UIColor*)color {
    
    return [UIImage imageNamed:@"markeryellow.png"];
}

-(void)reflowableViewController:(ReflowableViewController*)rvc didPaging:(PagingInformation *)pagingInformation {
  //  int ci = pagingInformation.chapterIndex;
  //  int cn = [rvc getNumberOfChaptersInBook];
 //   double value = (double)ci/(double)cn;
  //  [_sli_pages setValue:value];
    if (pagingInformation.fontName==nil) pagingInformation.fontName = @"Default";
    
    [DELEGATE insertPagingInformation:pagingInformation];
    
}

-(NSInteger)reflowableViewController:(ReflowableViewController*)rvc numberOfPagesForPagingInformation:(PagingInformation *)pagingInformation{
    if (pagingInformation.fontName==nil) pagingInformation.fontName = @"Default";
    PagingInformation* pgi = [DELEGATE fetchPagingInformation:pagingInformation];
    int nc = 0;
    if (pgi==NULL) nc=0;
    else nc=pgi.numberOfPagesInChapter;
    return nc;
}

-(void)reflowableViewController:(ReflowableViewController*)rvc didFinishPaging:(int)code {
    PageInformation* pg = [[PageInformation alloc]init];
    pg.pageIndexInBook = [rvc getPageIndexInBook];
    pg.numberOfPagesInBook = [rvc getNumberOfPagesInBook];
    [self changePageLabels:pg];
    
}
-(void)reflowableViewController:(ReflowableViewController*)rvc didStartPaging:(int)code {
    
}
-(void)processNoteIcons {
    [self removeNoteIcons];
    PageInformation*pi = [rv getPageInformation];
    highlightsInPage = pi.highlightsInPage;
    for (int i=0; i<[highlightsInPage count]; i++) {
        Highlight* highlight = [highlightsInPage objectAtIndex:i];
        if (highlight.isNote && highlight.note.length!=0) {
           
        }
    }
    if ([highlightsInPage count]!=0) [rv refresh];
}
-(void)removeNoteIcons {
    [highlightsInPage removeAllObjects];
    for (UIView*view in [self.view subviews]) {
        if (view.tag>=10000) {
            [view removeFromSuperview];
        }
    }
    for (UIView*view in [rv.customView subviews]) {
        if (view.tag>=20000) {
            [view removeFromSuperview];
        }
    }
}

-(void)showPIBox {
    piBox.hidden = NO;
    piArrow.hidden = NO;
    
}
-(void)hidePIBox {
    piBox.hidden = YES;
    piArrow.hidden = YES;
}
-(void)makePIBox {
    piBox = [[UIView alloc]init];
    piBox.frame = CGRectMake(0,0,220,57);
    UIView* guideView = [[UIView alloc]initWithFrame: CGRectMake(0,0,piBox.frame.size.width,37)];
    guideView.backgroundColor = [UIColor darkGrayColor];
    guideView.layer.cornerRadius = 10;
    guideView.layer.masksToBounds = YES;
    
    guideView.layer.borderColor = [[UIColor darkGrayColor]CGColor];
    guideView.layer.borderWidth = 0.5f;
    
    piLabel = [[UILabel alloc]init];
    piLabel.textColor = [UIColor whiteColor];
    piLabel.frame = CGRectMake(5,0,piBox.frame.size.width-10,37);
    piLabel.font = [UIFont systemFontOfSize:13.0];
    piLabel.backgroundColor = [UIColor clearColor];
    piLabel.textAlignment = NSTextAlignmentCenter;
    
    
    piArrow = [[ArrowView alloc]init];
    piArrow.backgroundColor = [UIColor clearColor];
    piArrow.upSide = NO;
    piArrow.frame = CGRectMake(piBox.frame.origin.x+guideView.frame.size.width/2,piBox.frame.origin.y+guideView.frame.size.height,20,20);
    [piArrow setColor:[UIColor darkGrayColor]];
    piArrow.hidden = YES;
    [piBox addSubview:guideView];
    [self.view addSubview:piBox];
    [self.view addSubview:piArrow];
    [piBox addSubview:piLabel];
    piBox.hidden = YES;
}
-(void)movePIBox {
    PageInformation* pi = [rv getPageInformationAtPagePositionInBook:_sli_pages.value];
    int ci = pi.chapterIndex;
    NSString *caption;
    if ([rv isRTL]) {
        ci = pi.numberOfChaptersInBook-ci-1;
        caption = [rv.book getChapterTitle:ci];
    }else {
        caption = [NSString stringWithFormat:@"%@",pi.chapterTitle];
    }
    if (_sli_pages.value==1.0f && ![rv isRTL]) {
        piLabel.text = @"The End";
    }else if (_sli_pages.value==0.0f && [rv isRTL]) {
        piLabel.text = @"The End";
    }else if (pi.chapterTitle==nil) {
        piLabel.text = [NSString stringWithFormat:@"Chapter %dth",ci];
    }else {
        piLabel.text = caption;
    }
    int tx,delta;
    int px,py,pw,ph;
    int sx = [self xPositionFromSlider:_sli_pages];
    pw = piBox.frame.size.width;
    ph = piBox.frame.size.height;
    py = _sli_pages.frame.origin.y-50;
    px = (sx-pw/2);
    tx = px;
    
    
    if (px<self.view.bounds.size.width*0.01) {
        px = self.view.bounds.size.width*.01;
        piArrow.frame = CGRectMake(tx,piArrow.frame.origin.y,piArrow.frame.size.width,piArrow.frame.size.height);
    }
    
    if (px+pw>self.view.bounds.size.width*.99) {
        px = self.view.bounds.size.width*.99 - pw;
        delta = tx-px;
    }
    
    piBox.frame = CGRectMake(px, py, pw, ph);
    piArrow.frame = CGRectMake(sx-10,py+30,20,20);
    
}
-(float)xPositionFromSlider:(UISlider *)aSlider; {
    float sliderRange = aSlider.frame.size.width - aSlider.currentThumbImage.size.width;
    float sliderOrigin = aSlider.frame.origin.x + (aSlider.currentThumbImage.size.width / 2.0);
    
    float sliderValueToPixels = (((aSlider.value-aSlider.minimumValue)/(aSlider.maximumValue-aSlider.minimumValue)) * sliderRange) + sliderOrigin;
    
    return sliderValueToPixels;
}

-(void)reloadBookmarks {
    bookmarks = [DELEGATE fetchAllBookmarks:self.bookInformation.bookCode];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)fontChange:(id)sender {
      _view_fonttable.hidden = YES;
    _view_font.hidden = !_view_font.isHidden;
    [self.view bringSubviewToFront:_view_font];
    _view_chapterlist.hidden = YES;
}

- (IBAction)goSearch:(id)sender {
    
    _view_font.hidden = YES;
    _view_search.hidden = NO;
    _view_chapterlist.hidden = YES;
   
    
    
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
    [MBProgressHUD showHUDAddedTo:_view_search animated:YES];
    lastNumberOfSearched = 0;
    [self startSearch:searchBar.text];
    
	

}
-(void)startSearch:(NSString*)key {
    [searchResults removeAllObjects];
    // remove all previous results
    [_table_search reloadData];
    [rv searchKey:key];
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    
}
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
    _view_search.hidden = YES;
}
-(void)searchMore {
    [MBProgressHUD showHUDAddedTo:_view_search animated:YES];
    [rv searchMore];
}

-(void)stopSearch {
    [MBProgressHUD hideAllHUDsForView:_view_search animated:YES];
    [rv stopSearch];
}

-(void)reflowableViewController:(ReflowableViewController *)rvc didSearchKey:(SearchResult *)searchResult {
    
    [self addSearchResult:searchResult mode:SEARCHRESULT];
}

int lastNumberOfSearched = 0;

-(void)reflowableViewController:(ReflowableViewController *)rvc didFinishSearchForChapter:(SearchResult *)searchResult {
    [rvc pauseSearch];
    int cn = searchResult.numberOfSearched - lastNumberOfSearched;
    if (cn > 150) {
        [self addSearchResult:searchResult mode:SEARCHMORE];
        lastNumberOfSearched = searchResult.numberOfSearched;
    }else {
        [rv searchMore];
    }
    
}

-(void)reflowableViewController:(ReflowableViewController *)rvc didFinishSearchAll:(SearchResult *)searchResult {
    [self addSearchResult:searchResult mode:SEARCHFINISHED];
}
- (IBAction)sliderDragStarted:(id)sender {
    [self showPIBox];
    [self movePIBox];
}
-(void)addSearchResult:(SearchResult*)searchResult mode:(int)mode{
    NSString *headerText = @"";
   
    
    if (mode==SEARCHRESULT) {
        int ci = searchResult.chapterIndex;
        if ([rv isRTL]) {
            ci = [rv getNumberOfChaptersInBook]-ci-1;
        }
        [searchResults addObject:searchResult];
        [_table_search.tableFooterView removeFromSuperview];
    }else if (mode==SEARCHMORE){
        headerText = @"Search More...";
       
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _table_search.frame.size.width, 44)];
        footerView.backgroundColor = [UIColor clearColor];
        
        UIImageView *img2 = [[UIImageView alloc]initWithFrame:CGRectMake(15, 0, _table_search.frame.size.width, 1)];
        [img2 setImage:[UIImage imageNamed:@"seprator"]];
        [footerView addSubview:img2];
        
        UIButton *button =[UIButton buttonWithType:UIButtonTypeSystem];
        
        if(IPHONE){
            button.frame = CGRectMake(80, 0,160, 44);
        }else{
            button.frame = CGRectMake(304, 0,160, 44);
        }
        [button.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
        [button setTitle:@"Search More" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(searchMore) forControlEvents:UIControlEventTouchUpInside];
        [footerView addSubview:button];
        
        _table_search.tableFooterView = footerView;
        [_table_search reloadData];
        [MBProgressHUD hideAllHUDsForView:_view_search animated:YES];
    }else if (mode==SEARCHFINISHED) {
        headerText = @"Search Finished";
       
        
      
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _table_search.frame.size.width, 70)];
        footerView.backgroundColor = [UIColor clearColor];
        
        UIImageView *img2 = [[UIImageView alloc]initWithFrame:CGRectMake(15, 0, _table_search.frame.size.width, 1)];
        [img2 setImage:[UIImage imageNamed:@"seprator"]];
        [footerView addSubview:img2];
        
        UILabel *_titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 0, 150, 25)];
        _titleLabel.textColor = [UIColor blackColor];
        //   _titleLabel.font = [self titleFont];
        _titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        _titleLabel.numberOfLines = 0;
        _titleLabel.alpha = 0.0;
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.text = headerText;
        [footerView addSubview:_titleLabel];
        
         _table_search.tableFooterView = footerView;
        [_table_search reloadData];
        [MBProgressHUD hideAllHUDsForView:_view_search animated:YES];
    }
    
    // set up label
    
    
    
    
 //   NSLog(@"-->%d",[searchResults count]);
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    // If you're serving data from an array, return the length of the array:
    if ([tableView isEqual:_table_search]) {
        return [searchResults count];
    }
    else if ([tableView isEqual:_table_font]){
        return [fontsArr count];
    }
    else if ([tableView isEqual:_table_chapterbookmark]){
        if ([_seg_chpbmark selectedSegmentIndex] == 0) {
            return [rv.book.NavMap count];
        }else{
            return  [bookmarks count];
        }
    }
    return 0;
}

-(void)reloadHighlights {
    highlights = [DELEGATE fetchAllHighlights:self.bookInformation.bookCode];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
 
    
   
    if([tableView isEqual:_table_search]){
    static NSString *CellIdentifier = @"ReaderSearchCell";
    ReaderSearchCell *cell = (ReaderSearchCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell= (ReaderSearchCell *)[arrNib objectAtIndex:0];
        //cell.backgroundColor =[UIColor clearColor];
        
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.lbl_chapter.text = @"";
    
    SearchResult *searchResult = [searchResults objectAtIndex:indexPath.row];
    int ci = searchResult.chapterIndex;
    NSString* chapterTitle = [rv.book getChapterTitle:ci];
    if (chapterTitle==NULL || chapterTitle.length==0) {
        cell.lbl_chapter.text = [NSString stringWithFormat:@"Chapter %d Page %d/%d",ci,searchResult.pageIndex+1,searchResult.numberOfPagesInChapter];
    }else {
        cell.lbl_chapter.text = [NSString stringWithFormat:@"%@ Page %d/%d",chapterTitle,searchResult.pageIndex+1,searchResult.numberOfPagesInChapter];
    }
    cell.lbl_desc.text = searchResult.text;
    
    return cell;
    }else if([tableView isEqual:_table_font]){
       
        static NSString *CellIdentifier = @"Cell";
        // add a placeholder cell while waiting on table data
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] ;
        }
        cell.textLabel.font = [UIFont fontWithName:[fontsArr objectAtIndex:indexPath.row] size:13];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.text = [fontsArr objectAtIndex:indexPath.row];
        return cell;

    
    }else if ([tableView isEqual:_table_chapterbookmark]){
        if ([_seg_chpbmark selectedSegmentIndex] == 0) {
            static NSString *CellIdentifier = @"Cell";
            // add a placeholder cell while waiting on table data
            
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] ;
            }
            cell.textLabel.font = [UIFont systemFontOfSize:13.0];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            cell.textLabel.textAlignment = NSTextAlignmentLeft;
            NavPoint* np = [rv.book.NavMap objectAtIndex:indexPath.row];
            cell.textLabel.text = np.text;
            return cell;

        }else{
            static NSString *CellIdentifier = @"Cell";
            // add a placeholder cell while waiting on table data
            
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil] ;
            }
            cell.textLabel.font = [UIFont systemFontOfSize:13.0];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            cell.textLabel.textAlignment = NSTextAlignmentLeft;
            PageInformation* pi = [bookmarks objectAtIndex:[indexPath row]];
            
            int ci = pi.chapterIndex;
            if ([rv isRTL]) {
                ci = [rv getNumberOfChaptersInBook]-ci-1;
            }
            
            NSString* title = [rv.book getChapterTitle:ci];
            cell.textLabel.text = [NSString stringWithFormat:@"%@",title];
            cell.detailTextLabel.text = pi.pageDescription;
            
            return cell;

        }
    }
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([tableView isEqual:_table_search]) {
    
    [rv stopSearch];
    SearchResult* sr = [searchResults objectAtIndex:indexPath.row];
    [rv performSelector:@selector(gotoPageBySearchResult:) withObject:sr afterDelay:0.6f];
    _view_search.hidden = YES;
    [_table_search.tableFooterView removeFromSuperview];
    [_table_search reloadData];
    }else if([tableView isEqual:_table_font]){
         _view_fonttable.hidden = YES;
        [rv changeFontName:[fontsArr objectAtIndex:indexPath.row] fontSize:fontsize];
         _lbl_fontname.text = [NSString stringWithFormat:@"%@",[fontsArr objectAtIndex:indexPath.row]];
    }else if ([tableView isEqual:_table_chapterbookmark]){
    
        if ([_seg_chpbmark selectedSegmentIndex] == 0) {
           
            NavPoint* np = NULL;
            np = [rv getNavPoint:indexPath.row];
            if (np!=NULL) {
                [rv gotoPageByNavPoint:np];
                
            }
            
        }else{
            PageInformation* pi = [bookmarks objectAtIndex:indexPath.row];
            [rv gotoPageByPagePositionInBook:pi.pagePositionInBook animated:NO];
        
        }
        _view_chapterlist.hidden = YES;
    }
    
}

-(UIColor *)darkerColorForColor:(UIColor *)color {
    float r, g, b, a;
    if ([color getRed:&r green:&g blue:&b alpha:&a])
        return [UIColor colorWithRed:MAX(r - 0.4, 0.0)
                               green:MAX(g - 0.4, 0.0)
                                blue:MAX(b - 0.4, 0.0)
                               alpha:a];
    return nil;
}

- (IBAction)sliderValueChanged:(id)sender {
    [self movePIBox];
}

- (IBAction)sliderDragEnded:(id)sender {
    [self hidePIBox];
    [rv gotoPageByPagePositionInBook:_sli_pages.value animated:NO];
}

- (IBAction)hitBookmark:(id)sender {
    _view_font.hidden = YES;
    [DELEGATE toggleBookmark:[rv getPageInformationAtPagePositionInBook:_sli_pages.value]];
    [rv refresh];
}

- (IBAction)goBack:(id)sender {
    [[UIApplication sharedApplication]setStatusBarHidden:NO];
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)change_brightness:(UISlider *)sender {
    
    [[UIScreen mainScreen] setBrightness: sender.value];
    
}

- (IBAction)decreaseFontSize:(id)sender {
    NSString* fontName = _lbl_fontname.text;
    if ([fontName isEqualToString:@"Default"]) fontName = @"";
    if (fontsize != 12) {
        fontsize--;
        [rv changeFontName:fontName fontSize:fontsize];
    }
}

- (IBAction)increaseFontSize:(id)sender {
    NSString* fontName = _lbl_fontname.text;
    if ([fontName isEqualToString:@"Default"]) fontName = @"";
    if (fontsize!=54) {
        fontsize++;
        [rv changeFontName:fontName fontSize:fontsize];
    }
}
- (IBAction)goWhile:(UIButton *)sender {
    if(!sender.isSelected){
    sender.selected = !sender.isSelected;
        _btn_sepiacolor.selected = NO;
        _btn_nightcolor.selected = NO;
     [rv changeForegroundColor:[UIColor blackColor]];
    [rv changeBackgroundColor:[UIColor whiteColor]];
    [self.view setBackgroundColor:[UIColor whiteColor]];
        [_lbl_pages setTextColor:[UIColor blackColor]];
        [_lbl_pagesleft setTextColor:[UIColor blackColor]];
        
        
    }
}

- (IBAction)goSepia:(UIButton *)sender {
    if(!sender.isSelected){
        sender.selected = !sender.isSelected;
        _btn_whitecolor.selected = NO;
        _btn_nightcolor.selected = NO;
        [rv changeForegroundColor:[UIColor blackColor]];
        [rv changeBackgroundColor:[UIColor colorWithRed:245.0/255.0 green:240.0/255.0 blue:222.0/255.0 alpha:1.0]];
        [self.view setBackgroundColor:[UIColor colorWithRed:245.0/255.0 green:240.0/255.0 blue:222.0/255.0 alpha:1.0]];
        [_lbl_pages setTextColor:[UIColor blackColor]];
        [_lbl_pagesleft setTextColor:[UIColor blackColor]];
    }
}

- (IBAction)goNight:(UIButton *)sender {
    if(!sender.isSelected){
        sender.selected = !sender.isSelected;
        _btn_sepiacolor.selected = NO;
         _btn_whitecolor.selected = NO;
        [rv changeForegroundColor:[UIColor whiteColor]];
        [rv changeBackgroundColor:[UIColor darkGrayColor]];
        [self.view setBackgroundColor:[UIColor darkGrayColor]];
        [_lbl_pages setTextColor:[UIColor whiteColor]];
        [_lbl_pagesleft setTextColor:[UIColor whiteColor]];
        
    }
}
- (IBAction)goCancelFont:(id)sender {
     _view_fonttable.hidden = YES;
}

- (IBAction)changeFont:(id)sender {
    _view_fonttable.hidden = NO;
}
- (IBAction)goList:(id)sender {
      [self reloadBookmarks];
    [_table_chapterbookmark reloadData];
    [self.view bringSubviewToFront:_view_chapterlist];
    _view_chapterlist.hidden = !_view_chapterlist.isHidden;
}
- (IBAction)chapterORbookmark:(UISegmentedControl *)sender {
    if (sender.selectedSegmentIndex == 1) {
         [self reloadBookmarks];
    
    }else{
    
    }
    [_table_chapterbookmark reloadData];
}
- (BOOL) hidesBottomBarWhenPushed
{
    return (self.navigationController.topViewController == self);
}
@end
