//
//  BookItemFeatured.m
//  Ebook App
//
//  Created by macmini3 on 05/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "BookCommon.h"

@implementation BookCommon


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
       
    }
    return self;
}

-(void)PopulateResult:(NSMutableDictionary *)dict showstar:(BOOL)showrating{
    if (![dict isEqual:[NSNull null]]) {
        
    
    _Bookdatails = [NSMutableDictionary dictionaryWithDictionary:dict];
        [_Bookdatails setObject:[NSNumber numberWithInt:(int)self.tag] forKey:@"tag"];
        [_Bookdatails setObject:[NSString stringWithFormat:@"%@",self.accessibilityHint] forKey:@"index"];
       
        _btn_addmybook.selected = NO;
        if ([[MyBooks valueForKeyPath:@"details.bookUrl"]containsObject:[NSString stringWithFormat:@"%@",[_Bookdatails valueForKey:@"bookUrl"]]]) {
            _btn_addmybook.selected = YES;
        }
        
    if (![[dict valueForKey:@"genre"]isEqual:[NSNull null]]) {
        
       _lbl_genre.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"genre"]];
    }
    
    CGSize textSize = [[_lbl_genre text] sizeWithFont:_lbl_genre.font forWidth:_lbl_genre.bounds.size.width lineBreakMode:_lbl_genre.lineBreakMode];
    [_lbl_genre setFrame:CGRectMake(_lbl_genre.frame.origin.x, _lbl_genre.frame.origin.y, MIN(textSize.width + 20, _lbl_genre.frame.size.width), _lbl_genre.frame.size.height)];

    
        // Book_placeholderdark
     if([[NSString stringWithFormat:@"%@",[self accessibilityIdentifier]]isEqualToString:@"BookItemFeatured"] ||[[NSString stringWithFormat:@"%@",[self accessibilityIdentifier]]isEqualToString:@"BookDetail"] ){
          [_imgview_book setImageWithURL:[NSURL URLWithString:[dict valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"Book_placeholderdark"]];
  
         }else{
           [_imgview_book setImageWithURL:[NSURL URLWithString:[dict valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"Book_placeholder"]];
         }
        
        if (![[dict valueForKey:@"author"]isEqual:[NSNull null]]) {
            
            _lbl_author.text = [NSString stringWithFormat:@"By: %@",[dict valueForKey:@"author"]];
        }
        if (![[dict valueForKey:@"title"]isEqual:[NSNull null]]) {
            
            _lbl_title.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"title"]];
        }

        for(UIView *view in self.subviews){
            if ([view isKindOfClass:[TQStarRatingView class]]) {
                [view removeFromSuperview];
            }
        }
        if(showrating){
             if (![[dict valueForKey:@"rating"]isEqual:[NSNull null]]) {
        
                 TQStarRatingView   *  starRatingView;
        if([[NSString stringWithFormat:@"%@",[self accessibilityIdentifier]]isEqualToString:@"BookItemFeatured"]){
          starRatingView = [[TQStarRatingView alloc] initWithFeaturedFrame:CGRectMake(3, _imgview_book.frame.origin.y + _imgview_book.frame.size.height + 10, 60, 12) numberOfStar:kNUMBER_OF_STAR];
         
            
        }
        
       else if([[NSString stringWithFormat:@"%@",[self accessibilityIdentifier]]isEqualToString:@"BookNormal"]){
       starRatingView =   [[TQStarRatingView alloc] initWithCustomeFrame:CGRectMake(2, _lbl_title.frame.origin.y + _lbl_title.frame.size.height + 3, 60, 12)  numberOfStar:kNUMBER_OF_STAR];
           
            
        }
       else if([[NSString stringWithFormat:@"%@",[self accessibilityIdentifier]]isEqualToString:@"BookDetail"]){
            
           starRatingView = [[TQStarRatingView alloc] initWithFeaturedFrame:CGRectMake(_lbl_author.frame.origin.x, _lbl_author.frame.origin.y + _lbl_author.frame.size.height , 80, 16) numberOfStar:kNUMBER_OF_STAR];
           
          
           
        //    NSLog(@"-->%@",_lbl_title.text);
            [_lbl_title sizeToFit];
           
           if (IPHONE) {
               [_lbl_title setFrame:CGRectMake(_lbl_title.frame.origin.x, _lbl_title.frame.origin.y, 146, MIN(38, _lbl_title.frame.size.height))];
               
               _lbl_title.frame = CGRectMake(_lbl_title.frame.origin.x,
                                             15 + (38 - _lbl_title.frame.size.height),
                                             146,
                                             _lbl_title.frame.size.height);
           }else{
           
               [_lbl_title setFrame:CGRectMake(_lbl_title.frame.origin.x, _lbl_title.frame.origin.y, 422, MIN(38, _lbl_title.frame.size.height))];
               
               _lbl_title.frame = CGRectMake(_lbl_title.frame.origin.x,
                                             15 + (38 - _lbl_title.frame.size.height),
                                             422,
                                             _lbl_title.frame.size.height);
           }
           
            
            
        }
    
                 [starRatingView setScore:[[dict valueForKey:@"rating"]floatValue]/5.0 withAnimation:NO];
                 starRatingView.userInteractionEnabled = NO;
                 [self addSubview:starRatingView];
             }
        }
      
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didTouchBook:)];
    [self addGestureRecognizer:tap];
    }
}
-(void)didTouchBook:(NSMutableDictionary *)sender{
    if ([self.delgate respondsToSelector:@selector(didTouchBook:)]) {
        [self.delgate didTouchBook:_Bookdatails];
    }
}
- (IBAction)AddMyBook:(UIButton *)sender {
    if (sender.isSelected) {
        if ([self.delgate respondsToSelector:@selector(didTouchRemovebook:)]) {
            [self.delgate didTouchRemovebook:_Bookdatails];
            sender.selected = NO;
        }
    }else{
    if ([self.delgate respondsToSelector:@selector(didTouchAddBook:)]) {
        [self.delgate didTouchAddBook:_Bookdatails];
        sender.selected = YES;
    }
    }
}

- (IBAction)Play:(id)sender {
    if ([self.delgate respondsToSelector:@selector(didTouchPlay:)]) {
        [self.delgate didTouchPlay:_Bookdatails];
    }

}

- (IBAction)Read:(id)sender {
    if ([self.delgate respondsToSelector:@selector(didTouchAddRead:)]) {
        [self.delgate didTouchAddRead:_Bookdatails];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
