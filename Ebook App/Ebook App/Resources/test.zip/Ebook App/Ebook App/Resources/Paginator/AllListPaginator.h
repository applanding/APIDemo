//
//  AllListPaginator.h
//  Ebook App
//
//  Created by macmini3 on 11/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "NMPaginator.h"

@interface AllListPaginator : NMPaginator

@end
