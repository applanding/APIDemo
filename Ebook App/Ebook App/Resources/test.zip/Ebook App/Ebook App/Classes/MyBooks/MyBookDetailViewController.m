//
//  MyBookDetailViewController.m
//  Ebook App
//
//  Created by macmini3 on 23/09/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import "MyBookDetailViewController.h"

@interface MyBookDetailViewController ()

@end

@implementation MyBookDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (!DELEGATE.RemoveAllAds && !DELEGATE.RemovePlaybackAds) {
        [self setupAds];
    }else{
        [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, _speedbtn.frame.origin.y + _speedbtn.frame.size.height)];
        
    }
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(goDetails)];
    [_img_book addGestureRecognizer:tap];
    
    for (UIView *view in [_volumeview subviews]){
		if ([[[view class] description] isEqualToString:@"MPVolumeSlider"]) {
			sli_volume = (UISlider *) view;
		}
	}
    
  
   
    
    [_sli_progress setThumbImage:[UIImage imageNamed:@"bluethumb"] forState:UIControlStateNormal];
    
    
    [_sli_progress setMinimumTrackImage:[[UIImage imageNamed:@"gray_left"]
                                  stretchableImageWithLeftCapWidth:5.0 topCapHeight:0.0] forState:UIControlStateNormal];
    
    [_sli_progress setMaximumTrackImage:[[UIImage imageNamed:@"gray_right"]
                                  stretchableImageWithLeftCapWidth:1.0 topCapHeight:0.0] forState:UIControlStateNormal];
    
    [sli_volume setMinimumTrackImage:[[UIImage imageNamed:@"black_filled"]
                                         stretchableImageWithLeftCapWidth:5.0 topCapHeight:0.0] forState:UIControlStateNormal];
    
    [sli_volume setMaximumTrackImage:[[UIImage imageNamed:@"gray_empty"]
                                         stretchableImageWithLeftCapWidth:1.0 topCapHeight:0.0] forState:UIControlStateNormal];
    [sli_volume setMinimumValueImage:[UIImage imageNamed:@"lowsound"]];
	[sli_volume setMaximumValueImage:[UIImage imageNamed:@"fullsound"]];
    
    [_segment setTitle:[NSString stringWithFormat:@"Download (%@)",[_myBookDict valueForKeyPath:@"details.size"] ] forSegmentAtIndex:1];
    
    [self settitleofSpeedbtn];
    
    
 //   NSLog(@"-->%@",_myBookDict);
    
 //   [self GetFileSizeof:[[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.ePub"]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    DELEGATE.delgate = self;
    act = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    [act setFrame:CGRectMake(150, 2, 25, 25)];
    act.hidesWhenStopped = YES;
    [_segment addSubview:act];
    
    
    [_img_book setImageWithURL:[NSURL URLWithString:[_myBookDict valueForKeyPath:@"details.image"]] placeholderImage:[UIImage imageNamed:@"Book_placeholder"]];

    if ([NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.ePub"]].length > 5) {
        _btn_readtext.enabled = YES;
    }
    
    _lbl_title.text = [NSString stringWithFormat:@"%@ by %@",[_myBookDict valueForKeyPath:@"details.title"],[_myBookDict valueForKeyPath:@"details.author"]];
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioStreamStateDidChange:)
                                                 name:FSAudioStreamStateChangeNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioStreamErrorOccurred:)
                                                 name:FSAudioStreamErrorNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(applicationDidEnterBackgroundNotification:)
                                                 name:UIApplicationDidEnterBackgroundNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(applicationWillEnterForegroundNotification:)
                                                 name:UIApplicationWillEnterForegroundNotification
                                               object:nil];
    
    
   
    
    
      [DELEGATE.audioController setVolume:sli_volume.value];
      //  [DELEGATE.audioController setVolume:10];
    [self setbuttonswithDefaults:YES];
    
    
    
    if (!IPHONE) {
         _popoverContent = [[UIViewController alloc]
                                            init];
        // [_view_sleep setFrame:CGRectMake(0, 0, _view_sleep.frame.size.width, _view_sleep.frame.size.height)];
        _popoverContent.view = _view_sleep;
        
        //resize the popover view shown
        //in the current view to the view's size
        _popoverContent.contentSizeForViewInPopover =
        CGSizeMake(_view_sleep.frame.size.width, _view_sleep.frame.size.height);
        
        //create a popover controller
        _popover = [[UIPopoverController alloc]
                    initWithContentViewController:_popoverContent];
        
        
        
        _popoverContent1 = [[UIViewController alloc]
                           init];
        // [_view_sleep setFrame:CGRectMake(0, 0, _view_sleep.frame.size.width, _view_sleep.frame.size.height)];
        _popoverContent1.view = _view_chapters;
        
        //resize the popover view shown
        //in the current view to the view's size
        _popoverContent.contentSizeForViewInPopover =
        CGSizeMake(_view_chapters.frame.size.width, _view_chapters.frame.size.height);
        
        //create a popover controller
        _popover1= [[UIPopoverController alloc]
                    initWithContentViewController:_popoverContent1];
        
        
    }
    
    
       // Do any additional setup after loading the view from its nib.
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if (DELEGATE.RemoveAllAds && DELEGATE.RemovePlaybackAds) {
        for (UIView *view in _scrollview.subviews) {
            if ([view isKindOfClass:[UIView class]]){
                if ([view.accessibilityIdentifier isEqualToString:@"ads"]) {
                    [view removeFromSuperview];
                }
            }
        }
    }
    
    
    if (_shouldStartPlaying) {
        _shouldStartPlaying = NO;
        [DELEGATE.audioController playFromURL:[NSURL URLWithString:_selectedPlaylistItem.url]];
        
    }
    
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    
    [self becomeFirstResponder];
    
    _progressUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                            target:self
                                                          selector:@selector(updatePlaybackProgress)
                                                          userInfo:nil
                                                           repeats:YES];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
    
    [self resignFirstResponder];
    
    
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    // Free the resources (audio queue, etc.)
   
    if (_progressUpdateTimer) {
        [_progressUpdateTimer invalidate], _progressUpdateTimer = nil;
    }
}
/*
 * =======================================
 * Observers
 * =======================================
 */

- (void)audioStreamStateDidChange:(NSNotification *)notification
{
    NSDictionary *dict = [notification userInfo];
    int state = [[dict valueForKey:FSAudioStreamNotificationKey_State] intValue];
    
    switch (state) {
        case kFsAudioStreamRetrievingURL:
           
            
            [self showStatus:@"Retrieving URL..."];
            
            _sli_progress.enabled = NO;
            
            _btn_play.hidden = YES;
             _btn_pause.hidden = NO;
            
           
            break;
            
        case kFsAudioStreamStopped:{
            
            FSStreamPosition end = DELEGATE.audioController.stream.duration;
            
            
            if ([DELEGATE minuteToSecondConvert:[NSString stringWithFormat:@"%i:%02i",end.minute, end.second]]-_sli_progress.value <=2 && (DELEGATE.playingIndex != [[_myBookDict valueForKey:@"mp3"]count]-1) && DELEGATE.sleepindex !=7 ) {
                _sli_progress.value = 0;
                [self goNextTrack];
            }
            
            _sli_progress.enabled = NO;
            _btn_play.hidden = NO;
            _btn_pause.hidden = YES;
            [self setbuttonswithDefaults:NO];
            
           
            
            
            break;
        }
        case kFsAudioStreamBuffering:
            [self showStatus:@"Buffering..."];
            if([[NSString stringWithFormat:@"%.1f",DELEGATE.playingRate]isEqualToString:@"1.0"]){
                DELEGATE.playingRate = 1.005;
            }
            
           _sli_progress.enabled = NO;
            _btn_play.hidden = YES;
            _btn_pause.hidden = NO;
            
            break;
            
        case kFsAudioStreamSeeking:
            [self showStatus:@"Seeking..."];
            
            
            _sli_progress.enabled = NO;
            _btn_play.hidden = YES;
            _btn_pause.hidden = NO;
            
            break;
            
        case kFsAudioStreamPlaying:
            
            [self clearStatus];
       
            [DELEGATE.audioController.stream setPlayRate:DELEGATE.playingRate];
            if([[NSString stringWithFormat:@"%3f",DELEGATE.playingRate]isEqualToString:@"1.005"]){
                DELEGATE.playingRate = 1;
            }
    
            if([[DELEGATE.playDict valueForKeyPath:@"details.bookUrl"] isEqual:[_myBookDict valueForKeyPath:@"details.bookUrl"]]){
                _sli_progress.enabled = YES;
                _btn_play.hidden = YES;
                _btn_pause.hidden = NO;
            }else {
                _sli_progress.enabled = NO;
                _btn_play.hidden = NO;
                _btn_pause.hidden = YES;
            }
            
            if (!_progressUpdateTimer) {
                _progressUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                                        target:self
                                                                      selector:@selector(updatePlaybackProgress)
                                                                      userInfo:nil
                                                                       repeats:YES];
            }
            
            
            
            
            break;
            
        case kFsAudioStreamFailed:
           
            _sli_progress.enabled = NO;
            _btn_play.hidden = NO;
            _btn_pause.hidden = YES;
            
            break;
    }
}

- (void)remoteControlReceivedWithEvent:(UIEvent *)receivedEvent
{
    if (receivedEvent.type == UIEventTypeRemoteControl) {
        switch (receivedEvent.subtype) {
            case UIEventSubtypeRemoteControlPause: /* FALLTHROUGH */
            case UIEventSubtypeRemoteControlPlay:  /* FALLTHROUGH */
            case UIEventSubtypeRemoteControlTogglePlayPause:
                if (![DELEGATE.audioController isPlaying]) {
                    [self goPlay:self];
                } else {
                    [self goPause:self];
                }
                break;
            case UIEventSubtypeRemoteControlPreviousTrack:
                
                if (DELEGATE.playingIndex != 0)
                    [self goPrevious:nil];
                break;
                
                
                
            case UIEventSubtypeRemoteControlNextTrack:
                if ((DELEGATE.playingIndex != [[DELEGATE.playDict valueForKey:@"mp3"]count]-1)) {
                    [self goNextTrack];
                }
                
                
                break;
            default:
                break;
        }
    }
    FSStreamPosition cur = DELEGATE.audioController.stream.currentTimePlayed;
    
    MPMediaItemArtwork *artwork = [[MPMediaItemArtwork alloc]initWithImage:DELEGATE.playingImage];
    [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = [NSDictionary dictionaryWithObjectsAndKeys:[[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"title"], MPMediaItemPropertyTitle, [DELEGATE.playDict valueForKeyPath:@"details.author"], MPMediaItemPropertyArtist, artwork, MPMediaItemPropertyArtwork,  [NSNumber numberWithInt:1], MPNowPlayingInfoPropertyPlaybackRate,[NSNumber numberWithInt:[DELEGATE minuteToSecondConvert:[[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex]valueForKey:@"length"]]],MPMediaItemPropertyPlaybackDuration,[NSNumber numberWithInt:[DELEGATE minuteToSecondConvert:[NSString stringWithFormat:@"%i:%02i",cur.minute, cur.second]]],MPNowPlayingInfoPropertyElapsedPlaybackTime, nil];
}

- (void)applicationDidEnterBackgroundNotification:(NSNotification *)notification
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:NULL];
 //   [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
   
}

- (void)applicationWillEnterForegroundNotification:(NSNotification *)notification
{

}

- (void)audioStreamErrorOccurred:(NSNotification *)notification
{
    NSDictionary *dict = [notification userInfo];
    int errorCode = [[dict valueForKey:FSAudioStreamNotificationKey_Error] intValue];
    
    NSString *errorDescription;
    
    switch (errorCode) {
        case kFsAudioStreamErrorOpen:
            errorDescription = @"Cannot open the audio stream";
            break;
        case kFsAudioStreamErrorStreamParse:
            errorDescription = @"Cannot read the audio stream";
            break;
        case kFsAudioStreamErrorNetwork:
            errorDescription = @"Network failed: cannot play the audio stream";
            break;
        case kFsAudioStreamErrorUnsupportedFormat:
            errorDescription = @"Unsupported format";
            break;
        case kFsAudioStreamErrorStreamBouncing:
            errorDescription = @"Network failed: cannot get enough data to play";
            break;
        default:
            errorDescription = @"Unknown error occurred";
            break;
    }
    
    [self showErrorStatus:errorDescription];
}


/*
 * =======================================
 * Properties
 * =======================================
 */


- (IBAction)goPlay:(id)sender {
   
    if (_paused) {
        /*
         * If we are paused, call pause again to unpause so
         * that the stream playback will continue.
         */
        _paused = NO;
        [DELEGATE.audioController pause];
        
    } else {
        /*
         * Not paused, just directly call play.
         */
        DELEGATE.audioController.url = self.selectedPlaylistItem.nsURL;
        [DELEGATE.audioController play];
        DELEGATE.playDict = [NSMutableDictionary dictionaryWithDictionary:_myBookDict];
        DELEGATE.playingImage = _img_book.image;
           [self setbuttonswithDefaults:YES];
       
    }
    
    _btn_play.hidden = YES;
    _btn_pause.hidden = NO;
}

- (IBAction)goPause:(id)sender {
    
    [DELEGATE.audioController pause];
    _paused = YES;
    _btn_play.hidden = NO;
    _btn_pause.hidden = YES;
    
}

/*
 * =======================================
 * Properties
 * =======================================
 */

- (void)setSelectedPlaylistItem:(FSPlaylistItem *)selectedPlaylistItem
{
    _selectedPlaylistItem = selectedPlaylistItem;
    
   // self.audioController.url = self.selectedPlaylistItem.nsURL;
}

- (FSPlaylistItem *)selectedPlaylistItem
{
    return _selectedPlaylistItem;
}
-(void)goDetails{
    BookDetailViewController *detail = [[BookDetailViewController alloc]initWithNibName:@"BookDetailViewController" bundle:nil];
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict setObject:[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.author"]] forKey:@"author"];
    [dict setObject:[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.bookUrl"]] forKey:@"bookUrl"];
    [dict setObject:[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.genre"]] forKey:@"genre"];
    [dict setObject:[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.image"]] forKey:@"image"];
    [dict setObject:[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.rating"]] forKey:@"rating"];
    [dict setObject:[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.title"]] forKey:@"title"];
    detail.booksarray = [NSMutableArray arrayWithObject:dict];
    detail.pageindex = 0;
    detail.backbtntitle = @"";
    if (IPHONE) {
        detail.hidesBottomBarWhenPushed = NO;
    [self.navigationController pushViewController:detail animated:YES];
    }else{
        [self addChildViewController: detail];
        [self.view addSubview: detail.view];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(removeChild:)];
        [detail.tapableview addGestureRecognizer:tap];
    }
}
-(void)removeChild:(UITapGestureRecognizer *)sender{
    UIViewController *vc = [self.childViewControllers lastObject];
    [vc willMoveToParentViewController:nil];
    [vc.view removeFromSuperview];
    [vc removeFromParentViewController];
    
}
- (IBAction)goNext:(id)sender {
    
    
    FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
    item.title = [NSString stringWithFormat:@"%@",[[[_myBookDict valueForKey:@"mp3"]objectAtIndex:_selectedPlaylistItem.number+1]valueForKey:@"title"]];
    item.url = [[[_myBookDict valueForKey:@"mp3"]objectAtIndex:_selectedPlaylistItem.number+1]valueForKey:@"file"];
    item.number = _selectedPlaylistItem.number+1;
    _selectedPlaylistItem = item;
    
    [DELEGATE.audioController playFromURL:[NSURL URLWithString:_selectedPlaylistItem.url]];
    
    
    [self setbuttonswithDefaults:YES];
    
}
- (IBAction)goNextTrack{
    
    
    FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
    item.title = [NSString stringWithFormat:@"%@",[[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex+1]valueForKey:@"title"]];
    item.url = [[[DELEGATE.playDict valueForKey:@"mp3"]objectAtIndex:DELEGATE.playingIndex+1]valueForKey:@"file"];
    item.number = DELEGATE.playingIndex+1;
    _selectedPlaylistItem = item;
    
    [DELEGATE.audioController playFromURL:[NSURL URLWithString:_selectedPlaylistItem.url]];
    DELEGATE.playingIndex = DELEGATE.playingIndex+1;
    [self setbuttonswithDefaults:YES];
    
    
}

- (IBAction)goPrevious:(id)sender {
    
    
    FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
    item.title = [NSString stringWithFormat:@"%@",[[[_myBookDict valueForKey:@"mp3"]objectAtIndex:_selectedPlaylistItem.number-1]valueForKey:@"title"]];
    item.url = [[[_myBookDict valueForKey:@"mp3"]objectAtIndex:_selectedPlaylistItem.number-1]valueForKey:@"file"];
    item.number = _selectedPlaylistItem.number-1;
    _selectedPlaylistItem = item;
    
    [DELEGATE.audioController playFromURL:[NSURL URLWithString:_selectedPlaylistItem.url]];
    
    [self setbuttonswithDefaults:YES];
}

-(void)setbuttonswithDefaults:(BOOL)defaults{
    
    if ([[DELEGATE.playDict valueForKeyPath:@"details.bookUrl"] isEqual:[_myBookDict valueForKeyPath:@"details.bookUrl"]]) {
        DELEGATE.playingIndex = _selectedPlaylistItem.number;
        _speedbtn.userInteractionEnabled = YES;
        _btn_sleep.userInteractionEnabled = YES;
    }
    else{
        _speedbtn.userInteractionEnabled = NO;
        _sli_progress.enabled = NO;
        _btn_sleep.userInteractionEnabled = NO;
    }
    if (defaults) {
        _lbl_lefttime.text = @"0:00";
        _lbl_righttime.text = [NSString stringWithFormat:@"-%@",[[[_myBookDict valueForKey:@"mp3"]objectAtIndex:_selectedPlaylistItem.number]valueForKey:@"length"]];
    }
    if(_selectedPlaylistItem){
    _lbl_chapter.text = [NSString stringWithFormat:@"%@",_selectedPlaylistItem.title];
    }else{
        _btn_pause.enabled = NO;
        _btn_play.enabled = NO;
        _btn_previous.enabled = NO;
        _btn_forward.enabled = NO;
        _btn_backward.enabled = NO;
        _btn_next.enabled = NO;
        _btn_sleep.enabled = NO;
        _speedbtn.enabled = NO;
        _lbl_righttime.text = @"0:00";
    }
    
    
    [_sli_progress setMaximumValue:[DELEGATE minuteToSecondConvert:[[[_myBookDict valueForKey:@"mp3"]objectAtIndex:_selectedPlaylistItem.number]valueForKey:@"length"]]];
    
    _btn_previous.enabled = YES;
    _btn_next.enabled = YES;
    _btn_backward.enabled = YES;
    _btn_forward.enabled = YES;
    
    if (_selectedPlaylistItem.number == 0) {
        _btn_previous.enabled = NO;
        _btn_next.enabled = YES;
    }else if (_selectedPlaylistItem.number == [[_myBookDict valueForKey:@"mp3"]count]-1){
        _btn_previous.enabled = YES;
        _btn_next.enabled = NO;
    }
    if (![[DELEGATE.playDict valueForKeyPath:@"details.bookUrl"] isEqual:[_myBookDict valueForKeyPath:@"details.bookUrl"]]) {
        _btn_next.enabled = NO;
        _btn_previous.enabled = NO;
        _btn_backward.enabled = NO;
        _btn_forward.enabled = NO;
    }
}
//- (FSAudioController *)audioController
//{
//    if (!DELEGATE.audioController) {
//        DELEGATE.audioController = [[FSAudioController alloc] init];
//    }
//    return DELEGATE.audioController;
//}

/*
 * =======================================
 * Private
 * =======================================
 */

- (void)clearStatus
{
  //  [AJNotificationView hideCurrentNotificationViewAndClearQueue];
    [_waitingindicator stopAnimating];
}

- (void)showStatus:(NSString *)status
{
    [self clearStatus];
    
//    [AJNotificationView showNoticeInView:[[[UIApplication sharedApplication] delegate] window]
//                                    type:AJNotificationTypeDefault
//                                   title:status
//                         linedBackground:AJLinedBackgroundTypeAnimated
//                               hideAfter:0];
    [_waitingindicator startAnimating];
}

- (void)showErrorStatus:(NSString *)status
{
    [self clearStatus];
    
//    [AJNotificationView showNoticeInView:[[[UIApplication sharedApplication] delegate] window]
//                                    type:AJNotificationTypeRed
//                                   title:status
//                               hideAfter:10];
    [_waitingindicator stopAnimating];
}

- (void)updatePlaybackProgress
{
    if (DELEGATE.audioController.stream.continuous) {
        _sli_progress.enabled = NO;
        _sli_progress.value = 0;
        
    } else {
       
         if ([DELEGATE.audioController.url isEqual:[NSURL URLWithString:_selectedPlaylistItem.url]] && DELEGATE.audioController.isPlaying) {
             _sli_progress.enabled = YES;
             _btn_play.hidden = YES;
             _btn_pause.hidden = NO;
             
        FSStreamPosition cur = DELEGATE.audioController.stream.currentTimePlayed;
        FSStreamPosition end = DELEGATE.audioController.stream.duration;
        _sli_progress.value = [DELEGATE minuteToSecondConvert:[NSString stringWithFormat:@"%i:%02i",
                                                           cur.minute, cur.second
                                                           ]];
         _lbl_lefttime.text = [NSString stringWithFormat:@"%@",[DELEGATE getDurationForSeconds:_sli_progress.value]];
        _lbl_righttime.text = [NSString stringWithFormat:@"-%@",[DELEGATE getDurationForSeconds:[DELEGATE minuteToSecondConvert:[NSString stringWithFormat:@"%i:%02i",end.minute, end.second]]-_sli_progress.value]];
        
     //   NSLog(@"-->%@",[NSString stringWithFormat:@"%i:%02i / %i:%02i",
     //                   cur.minute, cur.second,
     //                   end.minute, end.second]);
         }
    }
    
    
}

- (void)seekToNewTime
{
    _sli_progress.enabled = NO;
    
    FSStreamPosition pos;
    pos.minute = [DELEGATE getminuteForTotalSeconds:_sli_progress.value];
    pos.second = [DELEGATE getsecondForTotalSeconds:_sli_progress.value];
    
    [DELEGATE.audioController.stream seekToPosition:pos];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)goReadfullText:(id)sender {
  
    
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:[DELEGATE getinstalledEPubDirectory:[[[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.ePub"]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] lastPathComponent]]];
    if (fileExists){
        EpubReaderViewController *bvc = [[EpubReaderViewController alloc]initWithNibName:@"EpubReaderViewController" bundle:nil];
        bvc.bookInformation = [DELEGATE fetchBookInformations:[_myBookDict valueForKeyPath:@"details.title"]];
        bvc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:bvc animated:NO];;
    
    }else{

     [DELEGATE downloadBookwithUrl:[[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.ePub"]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    }
    
    
    
}
- (IBAction)progressUpdate:(UISlider *)sender {
  
//    _lbl_lefttime.text = [NSString stringWithFormat:@"%@",[self getDurationForSeconds:_sli_progress.value]];
//    _lbl_lefttime.text = [NSString stringWithFormat:@"%@",[self getDurationForSeconds:_sli_progress.value]];
//    _lbl_righttime.text = [NSString stringWithFormat:@"-%@",[self getDurationForSeconds:[self minuteToSecondConvert:[NSString stringWithFormat:@"%i:%02i",end.minute, end.second]]-_sli_progress.value]];
    
    [_progressUpdateTimer invalidate], _progressUpdateTimer = nil;
    
    [_playbackSeekTimer invalidate], _playbackSeekTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                                                           target:self
                                                                                         selector:@selector(seekToNewTime)
                                                                                         userInfo:nil
                                                                                          repeats:NO];
    
    
}
- (BOOL) hidesBottomBarWhenPushed
{
    return (self.navigationController.topViewController == self);
}
- (IBAction)goRemoveAds:(id)sender {
    
    SettingsViewController *gosetting = [[SettingsViewController alloc]initWithNibName:@"SettingsViewController" bundle:nil];
    gosetting.hidesBottomBarWhenPushed = NO;
    [self.navigationController pushViewController:gosetting animated:YES];
}

- (IBAction)goSleepTimer:(UIButton *)sender {
    if (IPHONE) {
         _view_sleep.hidden = NO;
    }else{
        
       
        [_popover presentPopoverFromRect:sender.frame
                                  inView:_scrollview
                permittedArrowDirections:UIPopoverArrowDirectionDown
                                animated:YES];
        
        
    }
   
}
-(void)setupAds{
    
    // set up label
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, _speedbtn.frame.origin.y + _speedbtn.frame.size.height, _scrollview.frame.size.width, 50)];
    footerView.backgroundColor = [UIColor whiteColor];
    footerView.accessibilityIdentifier = @"ads";

//    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 5, 320, 50)];
//    [img setImage:[UIImage imageNamed:@"banner"]];
//    [footerView addSubview:img];
    
    
    admobBannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeSmartBannerPortrait] ;
    admobBannerView.adUnitID = AdMob_ID_Playback;
    admobBannerView.rootViewController = self;
    [footerView addSubview:admobBannerView];
   [admobBannerView loadRequest:[GADRequest request]];
    
    [footerView setFrame:CGRectMake(0, _speedbtn.frame.origin.y + _speedbtn.frame.size.height, _scrollview.frame.size.width, admobBannerView.frame.size.height)];
    
    [_scrollview addSubview:footerView];
    [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, footerView.frame.origin.y + footerView.frame.size.height)];
   
    
    
    
    
    
    
}
-(void)removeAdtap:(UIButton *)sender{
    
    
}
- (IBAction)SpeedChange:(id)sender {
 
    

    if ( DELEGATE.playingRate  == 1 || [[NSString stringWithFormat:@"%.3f",DELEGATE.playingRate]isEqualToString:@"1.005"]) {
        DELEGATE.playingRate = 1.5;
        
    }
    else if (DELEGATE.playingRate  == 1.5) {
         DELEGATE.playingRate = 2;
        
    }
    else if (DELEGATE.playingRate  == 2) {
      DELEGATE.playingRate = 0.5;
        

        
    }else if (DELEGATE.playingRate  == 0.5) {
       DELEGATE.playingRate = 1;
     
  }
    if (DELEGATE.audioController.isPlaying) {
        [DELEGATE.audioController pause];
        [DELEGATE.audioController pause];
    }
    [self settitleofSpeedbtn];
    
}

-(void)settitleofSpeedbtn{
    
    _speedbtn.layer.cornerRadius = 3.0;
    if (DELEGATE.playingRate  == 1) {
       
        [_speedbtn setTitle:[NSString stringWithFormat:@" Speed %.fx ",DELEGATE.playingRate] forState:UIControlStateNormal];
        [_speedbtn setBackgroundColor:[UIColor clearColor]];
        
        
    }
    else if (DELEGATE.playingRate  == 1.5) {
        
        [_speedbtn setTitle:[NSString stringWithFormat:@" Speed %.1fx ",DELEGATE.playingRate] forState:UIControlStateNormal];
        [_speedbtn setBackgroundColor:[UIColor colorWithRed:0.0 green:122.0/255.0 blue:255.0/255.0 alpha:0.2]];
    }
    else if (DELEGATE.playingRate  == 2) {
      
        [_speedbtn setTitle:[NSString stringWithFormat:@" Speed %.fx ",DELEGATE.playingRate] forState:UIControlStateNormal];
        
        [_speedbtn setBackgroundColor:[UIColor colorWithRed:0.0 green:122.0/255.0 blue:255.0/255.0 alpha:0.2]];
    }else if (DELEGATE.playingRate  == 0.5) {
     
        [_speedbtn setTitle:[NSString stringWithFormat:@" Speed %.1fx ",DELEGATE.playingRate] forState:UIControlStateNormal];
        [_speedbtn setBackgroundColor:[UIColor colorWithRed:0.0 green:122.0/255.0 blue:255.0/255.0 alpha:0.2]];
    }
   [_speedbtn sizeToFit];

}
- (IBAction)goback:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)goShare:(id)sender {
    
    NSURL *myWebsite = [NSURL URLWithString:@"http://www.booksshouldbefree.com/"];
    NSString *textToShare = [NSString stringWithFormat:@"%@", [_myBookDict valueForKeyPath:@"details.title"]];
    UIImage *image = _img_book.image;
    NSArray *arrayOfActivityItems = [NSArray arrayWithObjects:textToShare,myWebsite,image, nil];
    
    // Display the view controller
    UIActivityViewController *activityVC = [[UIActivityViewController alloc]
                                             initWithActivityItems: arrayOfActivityItems applicationActivities:nil] ;
    activityVC.excludedActivityTypes = @[UIActivityTypeAssignToContact,
                                         UIActivityTypeSaveToCameraRoll, UIActivityTypePrint, UIActivityTypePostToWeibo,
                                         UIActivityTypeCopyToPasteboard,UIActivityTypeAirDrop,UIActivityTypeAddToReadingList];
    
    
   
    [self presentViewController:activityVC animated:YES completion:nil];
    [activityVC setCompletionHandler:^(NSString *activityType, BOOL completed)
     {
         NSLog(@"Activity = %@",activityType);
         NSLog(@"Completed Status = %d",completed);
         
         if (completed)
         {
//             UIAlertView *objalert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Posting was success" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             [objalert show];
//             objalert = nil;
         }else
         {
//             UIAlertView *objalert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Posting was not successful" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             [objalert show];
//             objalert = nil;
         }
     }];
}

- (IBAction)goChapter:(UIButton *)sender {
   
        
    [_tableview_chapters reloadData];
    if (IPHONE) {
      _view_chapters.hidden = NO;
    }else{
        [_popover1 presentPopoverFromRect:CGRectMake(715, 25, 32, 32)
                                  inView:self.view
                permittedArrowDirections:UIPopoverArrowDirectionUp
                                animated:YES];

    
    }
    
    
    
}

- (IBAction)selectSegment:(id)sender {
    
    switch (_segment.selectedSegmentIndex) {
        case 0:
            
            break;
        case 1:
            
            
   //     [DELEGATE downloadBookwithUrl:[[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.ePub"]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            
        default:
            break;
    }
    
    
    
}
//-(void)GetFileSizeof:(NSString *)urlString{
//    
//    NSURL *url = [NSURL URLWithString:urlString];
//    
//    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:[[DELEGATE applicationDocumentsDirectory]stringByAppendingPathComponent:[url lastPathComponent]]];
//    if (fileExists && [NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.ePub"]].length > 5) {
//        [_segment setTitle:@"Downloaded" forSegmentAtIndex:1];
//        [_segment setUserInteractionEnabled:NO ];
//       
//        return;
//    }
//    
//    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
//    [request setHTTPMethod:@"HEAD"];
//    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
//    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
//        
//   //     NSLog(@"RES: %@", [[operation response] allHeaderFields]);
//        if ([[[operation response] allHeaderFields] isKindOfClass:[NSDictionary class]]){
//        NSDictionary *fileAttributes = [[operation response] allHeaderFields];
//            NSNumber *fileSizeNumber = [fileAttributes objectForKey:@"Content-Length"];
//            long long fileSize = [fileSizeNumber longLongValue];
//            
//            [_segment setTitle:[NSString stringWithFormat:@"Download (%@)", [NSByteCountFormatter stringFromByteCount:fileSize countStyle:NSByteCountFormatterCountStyleFile]] forSegmentAtIndex:1];
//           
//        }
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"ERR: %@", [error description]);
//        [_segment setUserInteractionEnabled:NO ];
//       
//    }];
//    [operation start];
//}
-(void)downloadprogress:(float)value forURL:(NSString *)url{
  
    if ([url isEqualToString:[[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.ePub"]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]) {
//        [act startAnimating];
//        [_segment setTitle:[NSString stringWithFormat:@"       Downloading (%.f%%)",value] forSegmentAtIndex:1];
//        [_segment setUserInteractionEnabled:NO ];
//        [_segment setSelectedSegmentIndex:1];
    }

}
-(void)DownloadCompletedforURL:(NSString *)url{
//    if ([url isEqualToString:[[NSString stringWithFormat:@"%@",[_myBookDict valueForKeyPath:@"details.ePub"]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]) {
//        [act stopAnimating];
//        [_segment setTitle:@"Downloaded" forSegmentAtIndex:1];
//        [_segment setUserInteractionEnabled:NO ];
//        [_segment setSelectedSegmentIndex:0];
        
       
        
        [self goReadfullText:nil];
        
//    }
}

-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    if ([tableView isEqual: _tableview_chapters]) {
    return [[_myBookDict valueForKey:@"mp3"]count];
    }else{
        return 8;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([tableView isEqual: _tableview_chapters]) {
    
    
    static NSString *CellIdentifier = @"MyBookChapterCell";
    MyBookChapterCell *cell = (MyBookChapterCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell= (MyBookChapterCell *)[arrNib objectAtIndex:0];
        //cell.backgroundColor =[UIColor clearColor];
        
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    [cell populateResult:[[_myBookDict valueForKey:@"mp3"] objectAtIndex:indexPath.row]];
    if (_selectedPlaylistItem.number == indexPath.row) {
        cell.img_speaker.hidden = NO;
        [cell.lbl_title setTextColor:[UIColor colorWithRed:0.0 green:122.0/255.0 blue:1.0 alpha:1.0]];
    }
    return cell;
    }
    else{
        static NSString *CellIdentifier = @"SleepTimerTableViewCell";
        SleepTimerTableViewCell *cell = (SleepTimerTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell==nil) {
            NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell= (SleepTimerTableViewCell *)[arrNib objectAtIndex:0];
            //cell.backgroundColor =[UIColor clearColor];
            
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        switch (indexPath.row) {
            case 0:
                cell.lbl_title.text = @"Off";
                break;
            case 1:
                cell.lbl_title.text = @"In 5 Minutes";
                break;
            case 2:
                cell.lbl_title.text = @"In 10 Minutes";
                break;
            case 3:
                cell.lbl_title.text = @"In 15 Minutes";
                break;
            case 4:
                cell.lbl_title.text = @"In 30 Minutes";
                break;
            case 5:
                cell.lbl_title.text = @"In 45 Minutes";
                break;
            case 6:
                cell.lbl_title.text = @"In One Hour";
                break;
            case 7:
                cell.lbl_title.text = @"When Current Chapter Ends";
                break;
                
            default:
                break;
        }
        [cell.lbl_title setTextColor:[UIColor blackColor]];
        cell.accessoryType = UITableViewCellAccessoryNone;
        if (DELEGATE.sleepindex == indexPath.row){
            [cell.lbl_title setTextColor:[UIColor colorWithRed:0.0 green:122.0/255.0 blue:1.0 alpha:1.0]];
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        return cell;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if ([tableView isEqual: _tableview_chapters]) {
    
        DELEGATE.playingImage = _img_book.image;
        
    DELEGATE.playDict = [NSMutableDictionary dictionaryWithDictionary:_myBookDict];
    FSPlaylistItem *item = [[FSPlaylistItem alloc] init];
    item.title = [NSString stringWithFormat:@"%@",[[[_myBookDict valueForKey:@"mp3"]objectAtIndex:indexPath.row]valueForKey:@"title"]];
    item.url = [[[_myBookDict valueForKey:@"mp3"]objectAtIndex:indexPath.row]valueForKey:@"file"];
    item.number = indexPath.row;
    _selectedPlaylistItem = item;
    
    [DELEGATE.audioController playFromURL:[NSURL URLWithString:_selectedPlaylistItem.url]];
        if (IPHONE) {
          _view_chapters.hidden = YES;
        }else{
            [_popover1 dismissPopoverAnimated:YES];
        }
    
        
        
    [self setbuttonswithDefaults:YES];
    }else{
    
        DELEGATE.sleepindex = indexPath.row;
        [_tableview_sleep reloadData];
        
        switch (indexPath.row) {
            case 0:
                [DELEGATE invalidateTimer];
                break;
              case 1:
                [DELEGATE setSleepTime:5];
                break;
            case 2:
                [DELEGATE setSleepTime:10];
                break;
            case 3:
                [DELEGATE setSleepTime:15];
                break;
            case 4:
                [DELEGATE setSleepTime:30];
                break;
            case 5:
                [DELEGATE setSleepTime:45];
                break;
            case 6:
                [DELEGATE setSleepTime:60];
                break;
            case 7:
                [DELEGATE invalidateTimer];
                break;
            default:
                break;
        }
    }
    // NSLog(@"-->%@",[self.Paginator.results objectAtIndex:indexPath.row]);
    
}
- (IBAction)goDoneChap:(id)sender {
    _view_chapters.hidden = YES;
}
- (IBAction)goDoneSleep:(id)sender {
    _view_sleep.hidden = YES;
}
- (IBAction)goBackWard:(id)sender {
    _sli_progress.enabled = NO;
    
    FSStreamPosition pos;
    [_sli_progress setValue:_sli_progress.value-15 animated:NO];
    pos.minute = [DELEGATE getminuteForTotalSeconds:_sli_progress.value];
    pos.second = [DELEGATE getsecondForTotalSeconds:_sli_progress.value];
    
    [DELEGATE.audioController.stream seekToPosition:pos];
    
}
- (IBAction)goForward:(id)sender {
    _sli_progress.enabled = NO;
    
    FSStreamPosition pos;
    [_sli_progress setValue:_sli_progress.value+15 animated:NO];
    pos.minute = [DELEGATE getminuteForTotalSeconds:_sli_progress.value];
    pos.second = [DELEGATE getsecondForTotalSeconds:_sli_progress.value];
    
    [DELEGATE.audioController.stream seekToPosition:pos];
}
@end
