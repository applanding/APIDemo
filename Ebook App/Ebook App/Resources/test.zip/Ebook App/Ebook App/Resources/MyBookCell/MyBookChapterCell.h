//
//  MyBookChapterCell.h
//  Ebook App
//
//  Created by macmini3 on 04/10/14.
//  Copyright (c) 2014 peerbits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyBookChapterCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *img_speaker;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UILabel *lbl_description;

-(void)populateResult:(NSMutableDictionary *)dict;
@end
